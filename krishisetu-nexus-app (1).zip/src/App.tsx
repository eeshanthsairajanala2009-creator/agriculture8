import React, { useState } from 'react';
import { AppProvider, useApp, ScreenId } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { DemoTourBar } from './components/DemoTourBar';
import { ScreenPickerModal } from './components/ScreenPickerModal';
import { SystemDocumentationModal } from './components/SystemDocumentationModal';
import { SignInModal } from './components/SignInModal';
import { Sidebar } from './components/Sidebar';

// Screens
import { DashboardScreen } from './components/screens/DashboardScreen';
import { AskAiScreen } from './components/screens/AskAiScreen';
import { CameraUploadScreen } from './components/screens/CameraUploadScreen';
import { DiagnosisScreen } from './components/screens/DiagnosisScreen';
import { WeatherScreen } from './components/screens/WeatherScreen';
import { TreatmentScreen } from './components/screens/TreatmentScreen';
import { ProductMarketplaceScreen } from './components/screens/ProductMarketplaceScreen';
import { ProductDetailsScreen } from './components/screens/ProductDetailsScreen';
import { AuthenticityScannerScreen } from './components/screens/AuthenticityScannerScreen';
import { CartCheckoutScreen } from './components/screens/CartCheckoutScreen';
import { SoilDocumentScreen } from './components/screens/SoilDocumentScreen';
import { ServicesScreen } from './components/screens/ServicesScreen';
import { CostSustainabilityScreen } from './components/screens/CostSustainabilityScreen';
import { MandiMarketScreen } from './components/screens/MandiMarketScreen';
import { GovernmentSchemesScreen } from './components/screens/GovernmentSchemesScreen';
import { PestHotspotScreen } from './components/screens/PestHotspotScreen';
import { OrdersTasksScreen } from './components/screens/OrdersTasksScreen';
import { VerificationScreen } from './components/screens/VerificationScreen';
import { OfficerEscalationScreen } from './components/screens/OfficerEscalationScreen';
import { FpoDashboardScreen } from './components/screens/FpoDashboardScreen';
import { SellerDashboardScreen } from './components/screens/SellerDashboardScreen';
import { PrivacyAuditScreen } from './components/screens/PrivacyAuditScreen';
import { FarmProfileScreen } from './components/screens/FarmProfileScreen';

const MainLayout: React.FC = () => {
  const { activeScreen, isSignInModalOpen, setIsSignInModalOpen } = useApp();
  const [docsModalOpen, setDocsModalOpen] = useState(false);
  const [pickerModalOpen, setPickerModalOpen] = useState(false);
  const [sidebarMobileOpen, setSidebarMobileOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const renderActiveScreen = () => {
    switch (activeScreen) {
      case 'welcome':
      case 'consent':
      case 'profile':
        return <FarmProfileScreen />;
      case 'dashboard':
        return <DashboardScreen />;
      case 'ask':
      case 'voice':
        return <AskAiScreen />;
      case 'camera':
        return <CameraUploadScreen />;
      case 'diagnosis':
        return <DiagnosisScreen />;
      case 'weather':
      case 'irrigation':
        return <WeatherScreen />;
      case 'treatment':
        return <TreatmentScreen />;
      case 'products':
        return <ProductMarketplaceScreen />;
      case 'product_details':
        return <ProductDetailsScreen />;
      case 'authenticity':
        return <AuthenticityScannerScreen />;
      case 'cart':
        return <CartCheckoutScreen />;
      case 'soil':
      case 'soil_labs':
        return <SoilDocumentScreen />;
      case 'services':
      case 'machinery':
        return <ServicesScreen />;
      case 'sustainability':
        return <CostSustainabilityScreen />;
      case 'mandi':
        return <MandiMarketScreen />;
      case 'schemes':
        return <GovernmentSchemesScreen />;
      case 'pest_map':
        return <PestHotspotScreen />;
      case 'orders':
      case 'tasks':
        return <OrdersTasksScreen />;
      case 'verification':
        return <VerificationScreen />;
      case 'officer_escalation':
        return <OfficerEscalationScreen />;
      case 'fpo_dashboard':
        return <FpoDashboardScreen />;
      case 'seller_dashboard':
        return <SellerDashboardScreen />;
      case 'audit':
        return <PrivacyAuditScreen />;
      default:
        return <DashboardScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex font-sans">
      {/* Left-Side Feature Navigation (Top to bottom, Home first) */}
      <Sidebar
        isMobileOpen={sidebarMobileOpen}
        onCloseMobile={() => setSidebarMobileOpen(false)}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Viewport Content Area */}
      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ease-in-out ${
          sidebarCollapsed ? 'lg:pl-20' : 'lg:pl-72 sm:lg:pl-80'
        }`}
      >
        {/* Top Navbar */}
        <Navbar
          onOpenDocs={() => setDocsModalOpen(true)}
          onOpenScreenPicker={() => setPickerModalOpen(true)}
          onToggleSidebar={() => {
            if (window.innerWidth >= 1024) {
              setSidebarCollapsed(!sidebarCollapsed);
            } else {
              setSidebarMobileOpen(!sidebarMobileOpen);
            }
          }}
        />

        {/* 5-Minute Guided Demo Walkthrough Stepper */}
        <DemoTourBar />

        {/* Main Screen Content Body */}
        <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 pb-20 sm:pb-8">
          {renderActiveScreen()}
        </main>

        {/* Mobile Bottom Navigation Bar */}
        <BottomNav />

        {/* Modals */}
        <ScreenPickerModal
          isOpen={pickerModalOpen}
          onClose={() => setPickerModalOpen(false)}
        />

        <SystemDocumentationModal
          isOpen={docsModalOpen}
          onClose={() => setDocsModalOpen(false)}
        />

        <SignInModal
          isOpen={isSignInModalOpen}
          onClose={() => setIsSignInModalOpen(false)}
        />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
