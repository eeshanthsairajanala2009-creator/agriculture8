import React from 'react';
import { useApp, ScreenId } from '../context/AppContext';
import { triggerHaptic } from '../utils/haptics';
import {
  Home,
  Stethoscope,
  ShoppingBag,
  CheckSquare,
  Sparkles,
  CloudRain,
  ShieldCheck,
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeScreen, setActiveScreen, cart, tasks, language } = useApp();

  const pendingTasksCount = tasks.filter((t) => t.status !== 'completed').length;
  const cartItemsCount = cart.reduce((sum, i) => sum + i.quantity, 0);

  const tabLabels: Record<string, Record<ScreenId, string>> = {
    en: {
      dashboard: 'Home',
      ask: 'Ask AI',
      diagnosis: 'Doctor',
      weather: 'Weather',
      products: 'Market',
      tasks: 'Tasks',
    } as Record<ScreenId, string>,
    hi: {
      dashboard: 'होम',
      ask: 'सहायक',
      diagnosis: 'डॉक्टर',
      weather: 'मौसम',
      products: 'बाजार',
      tasks: 'कार्य',
    } as Record<ScreenId, string>,
    te: {
      dashboard: 'హోమ్',
      ask: 'సహాయకుడు',
      diagnosis: 'వైద్యుడు',
      weather: 'వాతావరణం',
      products: 'మార్కెట్',
      tasks: 'పనులు',
    } as Record<ScreenId, string>,
  };

  const currentLabels = tabLabels[language] || tabLabels.en;

  const tabs: { id: ScreenId; label: string; icon: React.ElementType; badge?: number }[] = [
    { id: 'dashboard', label: currentLabels.dashboard, icon: Home },
    { id: 'ask', label: currentLabels.ask, icon: Sparkles },
    { id: 'diagnosis', label: currentLabels.diagnosis, icon: Stethoscope },
    { id: 'weather', label: currentLabels.weather, icon: CloudRain },
    { id: 'products', label: currentLabels.products, icon: ShoppingBag, badge: cartItemsCount },
    { id: 'tasks', label: currentLabels.tasks, icon: CheckSquare, badge: pendingTasksCount },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1 shadow-lg sm:hidden">
      <div className="flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeScreen === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                triggerHaptic('light');
                setActiveScreen(tab.id);
              }}
              className={`relative flex flex-col items-center py-1 px-2 min-w-12 rounded-lg transition-colors ${
                isActive ? 'text-blue-900 font-bold' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px] scale-110 text-blue-700 transition-transform' : ''}`} />
                {Boolean(tab.badge && tab.badge > 0) && (
                  <span className="absolute -top-1 -right-2 bg-gradient-to-tr from-blue-900 to-blue-600 text-white text-[10px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
