import React, { useState } from 'react';
import { useApp, ScreenId } from '../context/AppContext';
import { triggerHaptic } from '../utils/haptics';
import {
  Home,
  MessageSquare,
  Camera,
  Stethoscope,
  CloudSun,
  Scale,
  ShoppingBag,
  FileSearch,
  QrCode,
  ShoppingCart,
  FileSpreadsheet,
  Plane,
  Calculator,
  TrendingUp,
  Landmark,
  Map,
  Package,
  CalendarCheck,
  CheckCircle,
  ShieldAlert,
  Users,
  Store,
  Lock,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Search,
  X,
  LogIn,
  LogOut,
  User as UserIcon,
  Sprout,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

interface SidebarProps {
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

interface NavItem {
  id: ScreenId;
  label: string;
  badge?: string | number;
  category: string;
  icon: React.ElementType;
  tag?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isMobileOpen,
  onCloseMobile,
  collapsed,
  onToggleCollapse,
}) => {
  const {
    activeScreen,
    setActiveScreen,
    cart,
    tasks,
    currentUser,
    currentRole,
    isAuthenticated,
    setIsSignInModalOpen,
    signOut,
    language,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const pendingTasksCount = tasks.filter((t) => t.status !== 'completed').length;

  // Features arranged top-to-bottom with Home / Dashboard FIRST
  const navSections: { title: string; items: NavItem[] }[] = [
    {
      title: 'Main & Field Intelligence',
      items: [
        {
          id: 'dashboard',
          label: language === 'hi' ? 'होम डैशबोर्ड' : language === 'te' ? 'హోమ్ డాష్‌బోర్డ్' : 'Home Dashboard',
          category: 'Core Hub',
          icon: Home,
          tag: 'Primary',
        },
        {
          id: 'ask',
          label: language === 'hi' ? 'सहायक से पूछें' : language === 'te' ? 'AI సహాయకుడు' : 'Ask AI Assistant',
          category: 'Intake',
          icon: MessageSquare,
        },
        {
          id: 'camera',
          label: language === 'hi' ? 'फसल डॉक्टर स्कैनर' : language === 'te' ? 'పంట డాక్టర్ స్కానర్' : 'Crop Doctor Scanner',
          category: 'Diagnostics',
          icon: Camera,
        },
        {
          id: 'diagnosis',
          label: language === 'hi' ? 'निदान व साक्ष्य' : language === 'te' ? 'వ్యాధి నిర్ధారణ' : 'AI Diagnosis Results',
          category: 'Diagnostics',
          icon: Stethoscope,
        },
        {
          id: 'weather',
          label: language === 'hi' ? 'मौसम व छिड़काव' : language === 'te' ? 'వాతావరణం & స్ప్రే' : 'Weather & Spray Safety',
          category: 'Weather',
          icon: CloudSun,
          badge: 'Rain Alert',
        },
        {
          id: 'treatment',
          label: language === 'hi' ? 'उपचार तुलना' : language === 'te' ? 'చికిత్స పోలిక' : 'Treatment Comparison',
          category: 'Planning',
          icon: Scale,
        },
      ],
    },
    {
      title: 'Marketplace & Booking',
      items: [
        {
          id: 'products',
          label: language === 'hi' ? 'प्रमाणित दवाइयां' : language === 'te' ? 'ధృవీకరించిన మందులు' : 'Product Marketplace',
          category: 'Commerce',
          icon: ShoppingBag,
        },
        {
          id: 'product_details',
          label: language === 'hi' ? 'उत्पाद विवरण व लेबल' : language === 'te' ? 'ఉత్పత్తి వివరాలు' : 'Product Details & Label',
          category: 'Commerce',
          icon: FileSearch,
        },
        {
          id: 'authenticity',
          label: language === 'hi' ? 'असली दवाई स्कैनर' : language === 'te' ? 'అసలైన మందు స్కానర్' : 'QR Authenticity Scanner',
          category: 'Safety',
          icon: QrCode,
        },
        {
          id: 'cart',
          label: language === 'hi' ? 'खरीदारी कार्ट' : language === 'te' ? 'షాపింగ్ కార్ట్' : 'Cart & Checkout',
          category: 'Commerce',
          icon: ShoppingCart,
          badge: cartCount > 0 ? cartCount : undefined,
        },
        {
          id: 'services',
          label: language === 'hi' ? 'ड्रोन व कृषि यंत्र' : language === 'te' ? 'డ్రోన్ & యంత్రాలు' : 'Drone & Machinery Service',
          category: 'Services',
          icon: Plane,
        },
        {
          id: 'soil',
          label: language === 'hi' ? 'मृदा स्वास्थ्य कार्ड' : language === 'te' ? 'నేల పరీక్ష & ల్యాబ్స్' : 'Soil Health & Lab Test',
          category: 'Soil',
          icon: FileSpreadsheet,
        },
      ],
    },
    {
      title: 'Market, Finance & Schemes',
      items: [
        {
          id: 'mandi',
          label: language === 'hi' ? 'मंडी भाव व बिक्री' : language === 'te' ? 'మార్కెట్ ధరలు' : 'Mandi Prices & APMC',
          category: 'Market',
          icon: TrendingUp,
          tag: 'Live',
        },
        {
          id: 'sustainability',
          label: language === 'hi' ? 'लागत व पर्यावरण बचत' : language === 'te' ? 'ఖర్చు & పర్యావరణం' : 'Cost & Eco Sustainability',
          category: 'Finance',
          icon: Calculator,
        },
        {
          id: 'schemes',
          label: language === 'hi' ? 'सरकारी योजनाएं' : language === 'te' ? 'ప్రభుత్వ పథకాలు' : 'Govt Schemes & PMFBY',
          category: 'Govt',
          icon: Landmark,
        },
      ],
    },
    {
      title: 'Field Operations & Tracking',
      items: [
        {
          id: 'pest_map',
          label: language === 'hi' ? 'कीट हॉटस्पॉट रडार' : language === 'te' ? 'తెగుళ్ల రాడార్' : 'Pest Surveillance Map',
          category: 'Surveillance',
          icon: Map,
        },
        {
          id: 'tasks',
          label: language === 'hi' ? 'खेत कार्य योजना' : language === 'te' ? 'పనుల క్యాలెండర్' : 'Farm Tasks & Calendar',
          category: 'Operations',
          icon: CalendarCheck,
          badge: pendingTasksCount > 0 ? pendingTasksCount : undefined,
        },
        {
          id: 'orders',
          label: language === 'hi' ? 'ऑर्डर व बुकिंग ट्रैकिंग' : language === 'te' ? 'ఆర్డర్ల ట్రాకింగ్' : 'Order & Booking Tracker',
          category: 'Operations',
          icon: Package,
        },
        {
          id: 'verification',
          label: language === 'hi' ? 'पहले व बाद का असर' : language === 'te' ? 'ముందు & తర్వాత' : 'Follow-Up Verification',
          category: 'Efficacy',
          icon: CheckCircle,
        },
      ],
    },
    {
      title: 'Multi-Role Portals & Governance',
      items: [
        {
          id: 'officer_escalation',
          label: language === 'hi' ? 'कृषि विशेषज्ञ कतार' : language === 'te' ? 'అధికారి పరిశీలన' : 'Agronomist Escalations',
          category: 'Officer',
          icon: ShieldAlert,
        },
        {
          id: 'fpo_dashboard',
          label: language === 'hi' ? 'एफपीओ सामूहिक खरीद' : language === 'te' ? 'ఎఫ్.పి.ఓ హబ్' : 'FPO Bulk Aggregation',
          category: 'FPO',
          icon: Users,
        },
        {
          id: 'seller_dashboard',
          label: language === 'hi' ? 'विक्रेता व ड्रोन बेड़ा' : language === 'te' ? 'డీలర్ & డ్రోన్లు' : 'Seller & Drone Pilot Hub',
          category: 'Seller',
          icon: Store,
        },
        {
          id: 'profile',
          label: language === 'hi' ? 'खेत व पार्सल प्रोफाइल' : language === 'te' ? 'పొలం సమాచారం' : 'Farm & Plot Profile',
          category: 'Setup',
          icon: MapPin,
        },
        {
          id: 'audit',
          label: language === 'hi' ? 'सुरक्षा व ऑडिट ट्रेल' : language === 'te' ? 'ఆడిట్ లాగ్స్' : 'Privacy & Security Audit',
          category: 'Trust',
          icon: Lock,
        },
      ],
    },
  ];

  const handleSelectScreen = (screenId: ScreenId) => {
    triggerHaptic('light');
    setActiveScreen(screenId);
    if (window.innerWidth < 1024) {
      onCloseMobile();
    }
  };

  const filteredSections = navSections
    .map((section) => ({
      ...section,
      items: section.items.filter((item) =>
        item.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.id.toLowerCase().includes(searchQuery.toLowerCase())
      ),
    }))
    .filter((section) => section.items.length > 0);

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 lg:hidden animate-in fade-in duration-200"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 flex flex-col bg-gradient-to-b from-[#061224] via-[#0a192f] to-[#0c1e3d] text-slate-200 border-r border-blue-900/40 shadow-2xl transition-all duration-300 ease-in-out ${
          collapsed ? 'w-20' : 'w-72 sm:w-80'
        } ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
      >
        {/* Brand & App Title Header */}
        <div className="h-16 px-4 border-b border-blue-900/40 flex items-center justify-between shrink-0 bg-slate-950/40">
          <div
            onClick={() => handleSelectScreen('dashboard')}
            className="flex items-center gap-3 cursor-pointer group overflow-hidden"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-950 via-blue-700 to-sky-400 flex items-center justify-center text-white shadow-lg shadow-blue-900/30 ring-1 ring-sky-400/40 shrink-0 group-hover:scale-105 transition-transform">
              <Sprout className="w-5 h-5 text-sky-200" />
            </div>

            {!collapsed && (
              <div className="leading-tight truncate">
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-sm tracking-tight text-white group-hover:text-sky-300 transition-colors">
                    KrishiSetu
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded-sm bg-gradient-to-r from-blue-700 to-sky-600 text-white font-extrabold uppercase tracking-wider border border-sky-400/30">
                    Nexus
                  </span>
                </div>
                <p className="text-[10px] text-sky-300/80 truncate">
                  Farm Actions & Marketplace
                </p>
              </div>
            )}
          </div>

          {/* Mobile close button / Desktop collapse toggle */}
          <div className="flex items-center gap-1">
            <button
              onClick={onCloseMobile}
              className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              title="Close Navigation"
            >
              <X className="w-5 h-5" />
            </button>

            <button
              onClick={onToggleCollapse}
              className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
            >
              {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Quick Search Filter (when expanded) */}
        {!collapsed && (
          <div className="p-3 border-b border-blue-900/30 bg-slate-950/20 shrink-0">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search features (Home, Doctor, Weather)..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-blue-950/40 border border-blue-800/40 rounded-xl text-white placeholder-slate-400 outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400/50 transition-all font-medium"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                >
                  &times;
                </button>
              )}
            </div>
          </div>
        )}

        {/* Navigation Items (Scrollable from top to bottom) */}
        <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4 custom-scrollbar">
          {filteredSections.map((section, idx) => (
            <div key={idx} className="space-y-1">
              {!collapsed && (
                <div className="px-3 py-1 text-[10px] font-extrabold uppercase tracking-widest text-sky-300/70">
                  {section.title}
                </div>
              )}

              <div className="space-y-0.5">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeScreen === item.id;
                  const isHome = item.id === 'dashboard';

                  return (
                    <button
                      key={item.id}
                      onClick={() => handleSelectScreen(item.id)}
                      title={collapsed ? item.label : undefined}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold text-left transition-all group relative ${
                        isActive
                          ? 'bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 text-white shadow-lg shadow-blue-950/50 ring-1 ring-sky-300/30 font-bold'
                          : isHome
                          ? 'bg-blue-900/30 hover:bg-blue-900/50 text-slate-100 border border-blue-700/30 font-bold'
                          : 'text-slate-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      {/* Active indicator dot / Icon */}
                      <div className="relative shrink-0">
                        <Icon
                          className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                            isActive
                              ? 'text-white'
                              : isHome
                              ? 'text-sky-300'
                              : 'text-slate-400 group-hover:text-sky-300'
                          }`}
                        />
                        {Boolean(item.badge && typeof item.badge === 'number' && item.badge > 0) && (
                          <span className="absolute -top-1 -right-1.5 w-3.5 h-3.5 rounded-full bg-sky-400 text-slate-950 text-[9px] font-black flex items-center justify-center">
                            {item.badge}
                          </span>
                        )}
                      </div>

                      {!collapsed && (
                        <div className="flex-1 flex items-center justify-between gap-1 truncate">
                          <span className="truncate">{item.label}</span>
                          <div className="flex items-center gap-1 shrink-0">
                            {item.tag && (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-sky-400/20 text-sky-200 border border-sky-400/30 uppercase">
                                {item.tag}
                              </span>
                            )}
                            {item.badge && typeof item.badge === 'string' && (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-200 border border-amber-400/30">
                                {item.badge}
                              </span>
                            )}
                            {item.badge && typeof item.badge === 'number' && item.badge > 0 && (
                              <span className="text-[10px] font-black px-1.5 py-0.2 rounded bg-sky-400 text-slate-950">
                                {item.badge}
                              </span>
                            )}
                          </div>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* User Account / Session Footer Card */}
        <div className="p-3 border-t border-blue-900/40 bg-slate-950/50 shrink-0">
          {isAuthenticated ? (
            <div className="space-y-2">
              <div
                onClick={() => handleSelectScreen('profile')}
                className="flex items-center gap-2.5 p-2 rounded-xl bg-blue-950/40 border border-blue-800/40 hover:border-sky-400/50 transition-all cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-700 to-sky-500 flex items-center justify-center text-white font-black text-xs shrink-0 ring-1 ring-sky-300/40">
                  {currentUser.name.charAt(0)}
                </div>

                {!collapsed && (
                  <div className="flex-1 truncate leading-tight">
                    <p className="text-xs font-bold text-white group-hover:text-sky-300 transition-colors truncate">
                      {currentUser.name}
                    </p>
                    <p className="text-[10px] text-sky-300/80 capitalize font-mono truncate">
                      {currentRole} &bull; {currentUser.district}
                    </p>
                  </div>
                )}
              </div>

              {!collapsed && (
                <div className="flex items-center gap-1.5 pt-1">
                  <button
                    onClick={() => {
                      triggerHaptic('light');
                      setIsSignInModalOpen(true);
                    }}
                    className="flex-1 py-1 px-2 rounded-lg bg-blue-900/40 hover:bg-blue-800/60 text-sky-200 border border-blue-700/40 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors"
                  >
                    <UserIcon className="w-3 h-3" />
                    <span>Switch</span>
                  </button>
                  <button
                    onClick={() => {
                      triggerHaptic('medium');
                      signOut();
                    }}
                    className="py-1 px-2 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors"
                    title="Sign Out"
                  >
                    <LogOut className="w-3 h-3" />
                    <span>Exit</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => {
                triggerHaptic('light');
                setIsSignInModalOpen(true);
              }}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 hover:from-blue-800 hover:to-sky-700 text-white font-extrabold text-xs shadow-md shadow-blue-950/40 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
            >
              <LogIn className="w-4 h-4 text-sky-200" />
              {!collapsed && <span>Sign In / Register</span>}
            </button>
          )}
        </div>
      </aside>
    </>
  );
};
