import React from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  FileText,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  ChevronLeft,
  Volume2,
  VolumeX,
  Plus,
  ShoppingBag,
  ExternalLink,
  Droplets,
  Clock,
  QrCode,
} from 'lucide-react';

export const ProductDetailsScreen: React.FC = () => {
  const {
    selectedProduct,
    setActiveScreen,
    addToCart,
    playSpeech,
    stopSpeech,
    isSpeaking,
  } = useApp();

  const prod = selectedProduct;

  const handleReadLabelAloud = () => {
    if (isSpeaking) {
      stopSpeech();
    } else {
      const labelText = `सरकारी लेबल जानकारी: ${prod.name}। निर्माता: ${prod.brand}। सक्रिय तत्व: ${prod.label.activeIngredient}। प्रयोग मात्रा: ${prod.label.applicationRatePerAcre}। फसल कटाई से पहले प्रतीक्षा अवधि: ${prod.label.harvestIntervalDays} दिन। आवश्यक सुरक्षा साधन: ${prod.label.requiredPPE.join(', ')}। सावधान: खाली पैकेट को नष्ट करके सुरक्षित स्थान पर रखें।`;
      playSpeech(labelText);
    }
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveScreen('products')}
          className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Marketplace</span>
        </button>

        <button
          onClick={() => setActiveScreen('authenticity')}
          className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1"
        >
          <QrCode className="w-3.5 h-3.5 text-slate-600" />
          <span>Verify QR Code</span>
        </button>
      </div>

      {/* Main Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900 uppercase">
                {prod.category}
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                Batch: {prod.batch.batchNumber}
              </span>
            </div>
            <h1 className="text-xl font-black text-slate-900 mt-1">{prod.name}</h1>
            <p className="text-xs text-slate-500">
              Manufactured by <strong className="text-slate-800">{prod.brand}</strong> &bull; Sold by <strong className="text-slate-800">{prod.sellerName}</strong>
            </p>
          </div>

          <div className="sm:text-right shrink-0">
            <span className="text-2xl font-black text-slate-900">₹{prod.priceInr}</span>
            <span className="text-[10px] text-slate-400 block">Pack: {prod.packSize}</span>
          </div>
        </div>

        {/* Read Label Aloud Banner */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-blue-50 border border-blue-200">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-blue-700" />
            <span className="text-xs text-blue-950 font-bold">
              Audio Label Reader (कम पढ़े-लिखे किसान भाइयों के लिए आवाज़ में सुनें)
            </span>
          </div>
          <button
            onClick={handleReadLabelAloud}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
              isSpeaking ? 'bg-red-500 text-white animate-pulse' : 'bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 text-white hover:from-blue-800 hover:to-cyan-700 shadow-sm'
            }`}
          >
            {isSpeaking ? 'Stop Audio' : 'Play Label Audio'}
          </button>
        </div>

        {/* Blocked Alert if applicable */}
        {prod.isBlockedByTrustAgent && (
          <div className="p-3 rounded-xl bg-red-100 border border-red-300 text-xs text-red-900 font-semibold flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-bold">PURCHASE PROHIBITED:</strong>
              <span>{prod.blockReason}</span>
            </div>
          </div>
        )}
      </div>

      {/* Official Government Label Leaflet Viewer */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Government CIB&RC Verified Label Leaflet
            </h2>
          </div>
          <span className="text-[10px] font-mono font-bold bg-blue-50 text-blue-800 px-2 py-0.5 rounded">
            Reg: {prod.label.officialCIBRegistrationNumber}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Active Ingredient</span>
            <span className="font-bold text-slate-800">{prod.label.activeIngredient}</span>
            <span className="text-[10px] text-slate-500 block mt-0.5">Group: {prod.label.chemicalGroup}</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Application Dosage per Acre</span>
            <span className="font-bold text-slate-800">{prod.label.applicationRatePerAcre}</span>
            <span className="text-[10px] text-slate-500 block mt-0.5">Water Volume: {prod.label.waterVolumeLitersPerAcre}</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Pre-Harvest Waiting Period</span>
            <span className="font-bold text-blue-800">{prod.label.harvestIntervalDays} Days Interval</span>
            <span className="text-[10px] text-slate-500 block mt-0.5">Do not harvest within this period</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Toxicology Band</span>
            <span className="font-bold text-slate-800">{prod.label.toxicologyColorCode}</span>
          </div>
        </div>

        {/* Required PPE */}
        <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200 text-xs">
          <span className="font-bold text-amber-950 block mb-1">
            Mandatory Personal Protective Equipment (PPE):
          </span>
          <div className="flex flex-wrap gap-1.5">
            {prod.label.requiredPPE.map((p, i) => (
              <span key={i} className="px-2 py-0.5 bg-amber-200/60 text-amber-950 font-semibold rounded text-[11px]">
                &bull; {p}
              </span>
            ))}
          </div>
        </div>

        {/* Storage & Disposal */}
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-700">
          <span className="font-bold text-slate-900 block mb-0.5">Storage & Safe Container Disposal:</span>
          <p className="text-[11px] leading-relaxed text-slate-600">
            {prod.label.storageAndDisposal}
          </p>
        </div>

        {/* Add to Cart Footer */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 block">Total Package Price:</span>
            <span className="text-lg font-black text-slate-900">₹{prod.priceInr}</span>
          </div>

          <button
            disabled={prod.isBlockedByTrustAgent || !prod.inStock}
            onClick={() => {
              triggerHaptic('medium');
              if (addToCart(prod, 1)) {
                setActiveScreen('cart');
              }
            }}
            className="px-6 py-2.5 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-extrabold rounded-xl text-xs shadow-md shadow-blue-900/20 flex items-center gap-1.5 transition-all hover:scale-[1.01]"
          >
            <Plus className="w-4 h-4" />
            <span>{prod.inStock ? 'Add to Cart & Checkout &rarr;' : 'Out of Stock'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
