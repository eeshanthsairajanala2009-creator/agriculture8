import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  Scale,
  ShieldCheck,
  Leaf,
  AlertTriangle,
  Scissors,
  Eye,
  CheckCircle2,
  Clock,
  Sparkles,
  ShoppingBag,
} from 'lucide-react';

export const TreatmentScreen: React.FC = () => {
  const { setActiveScreen, setSelectedProduct, products, addToCart } = useApp();
  const [selectedPlan, setSelectedPlan] = useState<'sanitary' | 'organic' | 'chemical' | 'monitoring'>('sanitary');

  const treatmentOptions = [
    {
      id: 'sanitary',
      title: '1. Manual Sanitary Leaf Pruning (Immediate Safe Action)',
      category: 'Manual Cultural Practice',
      timing: 'Immediately today before rainfall commences',
      costInr: '₹0 (Farmer labor)',
      efficacy: 'High (Immediate inoculum reduction)',
      harvestInterval: '0 Days (No chemical involved)',
      ppe: ['Cotton garden gloves', 'Pruning shears dipped in 70% alcohol'],
      action: 'Clip lower 3-4 leaves showing target concentric rings. Bag and burn/bury clippings away from field bund.',
      benefits: 'Reduces fungal spore splash during upcoming rains; improves under-canopy ventilation.',
      isSafeDuringRain: true,
      tag: 'Recommended First Step',
      tagColor: 'bg-blue-100 text-blue-900',
    },
    {
      id: 'organic',
      title: '2. Bio-Trichoderma Soil & Foliar Drench',
      category: 'Biological Antagonist',
      timing: 'Apply in moist soil 24h AFTER rainfall front clears',
      costInr: '₹220 per acre (1 kg pack)',
      efficacy: 'Moderate to High preventative barrier',
      harvestInterval: '0 Days (Zero chemical residue)',
      ppe: ['Cotton dust mask'],
      action: 'Mix 1kg Bio-Trichoderma harzianum in 200L water. Drench root zone and spray lower canopy.',
      benefits: 'Living hyper-parasite colonizes fungal mycelia; zero chemical resistance risk.',
      isSafeDuringRain: false,
      tag: 'Eco-Certified & Safe',
      tagColor: 'bg-blue-100 text-blue-800',
      productId: 'prod_tricho',
    },
    {
      id: 'chemical',
      title: '3. Copper Hydroxide (Kocide 3000 WG)',
      category: 'Contact Chemical Fungicide (FRAC M01)',
      timing: 'Apply ONLY after foliage dries completely (Day 3)',
      costInr: '₹680 per acre (500 g pack)',
      efficacy: 'High broad-spectrum preventative barrier',
      harvestInterval: '3 Days waiting period before harvest',
      ppe: ['N95 face mask', 'Nitrile chemical gloves', 'Protective eye goggles'],
      action: '400g per acre in 200L clean water. Ultra-low volume drone spray recommended.',
      benefits: 'Multi-site contact action prevents spore germination; bactericidal + fungicidal.',
      isSafeDuringRain: false,
      tag: 'Potent Preventive',
      tagColor: 'bg-amber-100 text-amber-900',
      productId: 'prod_kocide',
    },
    {
      id: 'monitoring',
      title: '4. Active Field Scouting & Re-Scan',
      category: 'Observation & IPM Monitoring',
      timing: 'Daily inspection at 08:00 AM',
      costInr: '₹0',
      efficacy: 'Prevents unnecessary expenditure',
      harvestInterval: 'N/A',
      ppe: ['Magnifying lens or smartphone camera'],
      action: 'Inspect stem nodes and newly emerged leaves. Re-scan leaf photo if lesions spread upwards.',
      benefits: 'Avoids premature chemical spraying; preserves natural predator insects.',
      isSafeDuringRain: true,
      tag: 'IPM Prudent',
      tagColor: 'bg-slate-100 text-slate-800',
    },
  ];

  const handleSelectProduct = (productId?: string) => {
    if (productId) {
      triggerHaptic('medium');
      const prod = products.find((p) => p.id === productId);
      if (prod) {
        setSelectedProduct(prod);
        setActiveScreen('product_details');
      }
    }
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-800">
            <Scale className="w-4 h-4" />
          </div>
          <h1 className="text-base font-extrabold text-slate-900">
            Treatment Comparison Agent (Screen 11)
          </h1>
        </div>
        <p className="text-xs text-slate-500">
          Source-grounded comparison of cultural, biological, chemical & monitoring interventions
        </p>
      </div>

      {/* Weather Gate Warning */}
      <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-xs flex items-start gap-2.5">
        <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <strong className="text-amber-950 block">Timing Rule Enforced:</strong>
          <span className="text-amber-900 leading-relaxed">
            Due to 85% rain expected within 12 hours, start with <strong>Manual Sanitary Pruning</strong> today. Chemical or biological sprays must be scheduled for the clear window 24-48 hours from now.
          </span>
        </div>
      </div>

      {/* 4 Treatment Option Cards */}
      <div className="space-y-3">
        {treatmentOptions.map((opt) => (
          <div
            key={opt.id}
            onClick={() => {
              triggerHaptic('light');
              setSelectedPlan(opt.id as any);
            }}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              selectedPlan === opt.id
                ? 'border-blue-600 bg-white ring-2 ring-blue-500/20 shadow-md'
                : 'border-slate-200 bg-white hover:border-slate-300'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${opt.tagColor}`}>
                    {opt.tag}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">{opt.category}</span>
                </div>
                <h3 className="text-sm font-black text-slate-900 mt-1">{opt.title}</h3>
              </div>

              <div className="text-left sm:text-right shrink-0">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Estimated Cost</span>
                <span className="text-xs font-black text-slate-900">{opt.costInr}</span>
              </div>
            </div>

            {/* Specifications Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 my-3 text-xs text-slate-700">
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Application Timing</span>
                <span className="font-semibold text-slate-800">{opt.timing}</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Waiting Period / Pre-Harvest</span>
                <span className="font-semibold text-slate-800">{opt.harvestInterval}</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 sm:col-span-2">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Personal Protective Equipment (PPE)</span>
                <span className="font-semibold text-slate-800">{opt.ppe.join(', ')}</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              <strong className="text-slate-800">Action Protocol:</strong> {opt.action}
            </p>

            {/* Action buttons */}
            <div className="mt-3 flex items-center justify-between gap-2 pt-2 border-t border-slate-100">
              <span className="text-[11px] text-blue-900 font-medium">{opt.benefits}</span>

              {opt.productId ? (
                <button
                  onClick={() => handleSelectProduct(opt.productId)}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white font-bold rounded-lg text-xs shadow-md shadow-blue-600/30 flex items-center gap-1 shrink-0"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Inspect Verified Product &rarr;</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    triggerHaptic('light');
                    setActiveScreen('tasks');
                  }}
                  className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg text-xs shadow-xs shrink-0"
                >
                  Add to Farm Tasks &rarr;
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
