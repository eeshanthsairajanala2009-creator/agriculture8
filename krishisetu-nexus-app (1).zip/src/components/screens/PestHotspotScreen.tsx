import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PestReport } from '../../types';
import { triggerHaptic } from '../../utils/haptics';
import {
  Map,
  AlertTriangle,
  Radio,
  MapPin,
  ShieldAlert,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';

export const PestHotspotScreen: React.FC = () => {
  const { pestHotspots, setActiveScreen } = useApp();
  const [selectedHotspot, setSelectedHotspot] = useState<PestReport>(pestHotspots[0]);

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
            <Map className="w-4 h-4 text-blue-700" />
          </div>
          <h1 className="text-base font-extrabold text-slate-900">
            Pest Surveillance & Hotspot Radar (Screen 23)
          </h1>
        </div>
        <p className="text-xs text-slate-500">
          Geospatial outbreak clustering, fungal spore dispersion alerts & preventive radius
        </p>
      </div>

      {/* Early Warning Broadcast Banner */}
      <div className="p-4 rounded-2xl bg-rose-500 text-white shadow-md flex items-start gap-3">
        <div className="p-2 rounded-xl bg-black/20 shrink-0 mt-0.5">
          <Radio className="w-5 h-5 animate-pulse text-amber-300" />
        </div>
        <div>
          <span className="text-[10px] uppercase font-black tracking-widest bg-black/30 px-2 py-0.5 rounded">
            LOCAL DISTRICT EARLY WARNING TRIGGERED
          </span>
          <h2 className="text-sm font-black mt-1">
            Rapid Alternaria Fungal Cluster in Kolar Tomato Belt (38 Reports)
          </h2>
          <p className="text-xs text-rose-100 mt-0.5 leading-relaxed">
            Spore dispersion risk elevated due to high ambient humidity (88%) and forecasted rain. Tomato plots in Vemgal, Bangarapet, and Kolar rural are advised to initiate sanitary pruning and prepare bio-copper sprays.
          </p>
        </div>
      </div>

      {/* Interactive Map Canvas Simulation */}
      <div className="bg-slate-950 rounded-2xl p-4 sm:p-6 text-white relative overflow-hidden border border-slate-800 shadow-xl shadow-blue-950/20">
        <div className="flex items-center justify-between mb-3 text-xs">
          <span className="font-mono text-sky-400 font-bold">KOLAR DISTRICT SPATIAL GRID (13.13° N, 78.13° E)</span>
          <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
            Radius: 25 km
          </span>
        </div>

        {/* Visual Map Representation */}
        <div className="h-64 rounded-xl bg-slate-900 border border-slate-800 relative flex items-center justify-center overflow-hidden">
          {/* Grid lines */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:2rem_2rem] opacity-40"></div>

          {/* District boundary sketch */}
          <svg className="absolute inset-0 w-full h-full text-slate-700/60 pointer-events-none" viewBox="0 0 300 200">
            <path
              d="M30 40 Q80 20 150 40 T270 70 Q280 140 220 180 T70 160 Z"
              fill="rgba(37, 99, 235, 0.08)"
              stroke="rgba(56, 189, 248, 0.45)"
              strokeWidth="1.5"
              strokeDasharray="4 4"
            />
          </svg>

          {/* Farmer's Own Farm Pin */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-20">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
            </span>
            <span className="text-[9px] font-bold bg-blue-950 border border-sky-400 px-1.5 py-0.5 rounded text-sky-200 shadow-md mt-1">
              Your Farm (Plot #2)
            </span>
          </div>

          {/* Hotspot Pins */}
          {pestHotspots.map((spot, i) => {
            const isSelected = selectedHotspot.id === spot.id;
            const positions = [
              { top: '35%', left: '60%' },
              { top: '25%', left: '28%' },
              { top: '70%', left: '45%' },
            ];
            const pos = positions[i] || { top: '50%', left: '50%' };

            return (
              <button
                key={spot.id}
                onClick={() => {
                  triggerHaptic('light');
                  setSelectedHotspot(spot);
                }}
                style={{ top: pos.top, left: pos.left }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-10 transition-transform ${
                  isSelected ? 'scale-125 z-30' : 'hover:scale-110'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px] shadow-lg border-2 ${
                    spot.severity === 'high'
                      ? 'bg-rose-600 border-white text-white animate-pulse'
                      : spot.severity === 'moderate'
                      ? 'bg-amber-500 border-white text-slate-950'
                      : 'bg-blue-600 border-white text-white'
                  }`}
                >
                  {spot.reportsCount}
                </div>
                <span className="text-[9px] font-semibold bg-black/80 px-1 rounded text-white mt-0.5 whitespace-nowrap">
                  {spot.village.split(' ')[0]}
                </span>
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span> High Cluster (&gt;25)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Moderate (10-25)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span> Low (&lt;10)
            </span>
          </div>
          <span className="text-slate-500">Updated: 12 min ago</span>
        </div>
      </div>

      {/* Selected Hotspot Detail Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400">Cluster Details</span>
            <h3 className="text-sm font-black text-slate-900">{selectedHotspot.pestName}</h3>
            <p className="text-xs text-slate-500">{selectedHotspot.village}, {selectedHotspot.district} District</p>
          </div>

          <span
            className={`text-xs font-bold uppercase px-2 py-0.5 rounded ${
              selectedHotspot.severity === 'high'
                ? 'bg-rose-100 text-rose-800'
                : 'bg-amber-100 text-amber-800'
            }`}
          >
            {selectedHotspot.severity} Risk ({selectedHotspot.reportsCount} Cases)
          </span>
        </div>

        <div className="flex items-center justify-between pt-1">
          <span className="text-xs text-slate-600">
            Coordinates: {selectedHotspot.latitude}° N, {selectedHotspot.longitude}° E
          </span>
          <button
            onClick={() => {
              triggerHaptic('medium');
              setActiveScreen('treatment');
            }}
            className="px-3.5 py-1.5 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-lg text-xs shadow-md shadow-blue-900/20"
          >
            Review Protective Action &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
