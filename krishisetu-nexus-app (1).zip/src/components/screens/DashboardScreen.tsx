import React from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  AlertTriangle,
  CloudRain,
  Stethoscope,
  Sparkles,
  ShoppingBag,
  CheckSquare,
  TrendingUp,
  MapPin,
  ChevronRight,
  ShieldCheck,
  Plane,
  FileSpreadsheet,
  Volume2,
  Calendar,
} from 'lucide-react';

export const DashboardScreen: React.FC = () => {
  const {
    currentUser,
    farm,
    crop,
    weather,
    diagnosis,
    tasks,
    setActiveScreen,
    playSpeech,
    isSpeaking,
    stopSpeech,
    language,
    t,
  } = useApp();

  const pendingTasks = tasks.filter((t) => t.status !== 'completed');

  const handleVoiceListenOverview = () => {
    triggerHaptic('medium');
    if (isSpeaking) {
      stopSpeech();
    } else {
      let summary = `Hello ${currentUser.name}. Your tomato crop at ${farm.name} is in flowering stage. Early blight fungal symptoms detected on lower leaves. Critical note: 85 percent rainfall expected within 12 hours, so hold foliar sprays today.`;
      if (language === 'te') {
        summary = `నమస్కారం ${currentUser.name} గారు. మీ ${farm.name} లో టమోటా పంట పూత దశలో ఉంది. ఆకులపై ముందస్తు తెగులు లక్షణాలు కనిపించాయి. ముఖ్య గమనిక: రాబోయే 12 గంటల్లో 85 శాతం వర్ష సూచన ఉంది, కాబట్టి ఈరోజు ఎలాంటి రసాయన పిచికారీ చేయవద్దు.`;
      } else if (language === 'hi') {
        summary = `नमस्ते ${currentUser.name} जी। आपके ${farm.name} में टमाटर की फसल फूल आने की अवस्था में है। पत्तियों पर अगेती झुलसा रोग के लक्षण देखे गए हैं। ध्यान दें: अगले 12 घंटों में 85 प्रतिशत बारिश की संभावना है, इसलिए आज कोई भी रासायनिक छिड़काव न करें।`;
      }
      playSpeech(summary);
    }
  };

  return (
    <div className="space-y-4 pb-16 sm:pb-6">
      {/* Farmer Greeting & Field Context */}
      <div className="bg-gradient-to-r from-slate-950 via-blue-950 to-blue-900 border border-blue-500/30 rounded-2xl p-4 sm:p-5 text-white shadow-xl shadow-blue-950/30 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-blue-500/15 via-sky-400/10 to-transparent pointer-events-none"></div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-blue-500/30 text-sky-200 border border-sky-400/30 shadow-inner">
                1-Acre Tomato Pilot &bull; Kolar District
              </span>
              <span className="text-[11px] text-sky-200">KBF Member #409</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Welcome, {currentUser.name}
            </h1>
            <p className="text-xs text-blue-100 mt-0.5">
              Crop: <strong className="text-white">{crop.cropName} ({crop.variety})</strong> &bull; Stage: <strong className="text-amber-300">{crop.stage}</strong> (Planted: 1.0 Acre)
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleVoiceListenOverview}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all ${
                isSpeaking ? 'bg-red-500 text-white animate-pulse' : 'bg-white text-blue-950 hover:bg-blue-50 ring-1 ring-blue-300/50'
              }`}
            >
              <Volume2 className="w-4 h-4 text-blue-600" />
              <span>{isSpeaking ? t.stopAudio : t.readAloud}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Critical Weather Delay Action Banner */}
      <div
        onClick={() => setActiveScreen('weather')}
        className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-4 cursor-pointer hover:bg-amber-100/60 transition-colors shadow-xs"
      >
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500 text-slate-950 shrink-0">
            <CloudRain className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase text-amber-900 tracking-wider">
                {t.weather}
              </span>
              <span className="text-[10px] bg-amber-200 text-amber-950 font-bold px-1.5 py-0.2 rounded">
                85% Rain Forecast
              </span>
            </div>
            <h2 className="text-sm font-bold text-slate-900 mt-0.5">
              {t.sprayUnsafeAlert}
            </h2>
            <p className="text-xs text-slate-700 mt-1">
              {t.safeSprayWindow}
            </p>
          </div>
          <ChevronRight className="w-5 h-5 text-amber-700 shrink-0 self-center" />
        </div>
      </div>

      {/* Quick Core Action Tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveScreen('ask');
          }}
          className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-blue-500 hover:shadow-md text-left transition-all group flex flex-col justify-between"
        >
          <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900">{t.askAi}</h3>
            <p className="text-[11px] text-slate-500">{t.sprayQuestion}</p>
          </div>
        </button>

        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveScreen('camera');
          }}
          className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-blue-500 hover:shadow-md text-left transition-all group flex flex-col justify-between"
        >
          <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900">{t.diagnose}</h3>
            <p className="text-[11px] text-slate-500">{t.beforeAfter}</p>
          </div>
        </button>

        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveScreen('products');
          }}
          className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-blue-500 hover:shadow-md text-left transition-all group flex flex-col justify-between"
        >
          <div className="w-9 h-9 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <ShoppingBag className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900">{t.products}</h3>
            <p className="text-[11px] text-slate-500">{t.costEstimator}</p>
          </div>
        </button>

        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveScreen('services');
          }}
          className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-blue-500 hover:shadow-md text-left transition-all group flex flex-col justify-between"
        >
          <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Plane className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900">{t.services}</h3>
            <p className="text-[11px] text-slate-500">{t.schemes}</p>
          </div>
        </button>
      </div>

      {/* Active Crop Diagnostic State */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <h2 className="text-sm font-bold text-slate-900">Current Health Diagnosis</h2>
          </div>
          <span className="text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-medium">
            AI Screening (86% Confidence)
          </span>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <div
            onClick={() => setActiveScreen('camera')}
            className="w-full sm:w-36 h-28 bg-slate-950 rounded-xl relative overflow-hidden shrink-0 border border-slate-800 flex items-center justify-center cursor-pointer group shadow-inner"
          >
            {/* Visual tomato leaf rendering */}
            <div className="absolute inset-0 bg-gradient-to-b from-blue-950/70 to-slate-950 flex items-center justify-center">
              <svg viewBox="0 0 100 100" className="w-20 h-20 text-sky-400 opacity-90 drop-shadow-sm">
                <path
                  d="M50 15 C30 25 20 60 50 85 C80 60 70 25 50 15 Z"
                  fill="#1e3a8a"
                  stroke="#38bdf8"
                  strokeWidth="2"
                />
                <circle cx="48" cy="45" r="7" fill="#4e342e" stroke="#fbc02d" strokeWidth="2" />
                <circle cx="58" cy="58" r="5" fill="#4e342e" stroke="#fbc02d" strokeWidth="1.5" />
                <circle cx="38" cy="62" r="4" fill="#4e342e" stroke="#fbc02d" strokeWidth="1.5" />
              </svg>
            </div>
            <span className="absolute bottom-1 bg-black/70 text-white text-[9px] px-1.5 py-0.5 rounded font-semibold">
              Tap to Inspect &rarr;
            </span>
          </div>

          <div className="flex-1">
            <h3 className="text-base font-extrabold text-slate-900">
              {diagnosis.diseaseOrPest} ({diagnosis.scientificName})
            </h3>
            <p className="text-xs text-slate-600 font-medium">{diagnosis.hindiName}</p>
            <div className="mt-2 space-y-1 text-xs text-slate-600">
              <p>
                <strong className="text-slate-800">Visual Evidence:</strong> Bullseye concentric rings on lower foliage.
              </p>
              <p>
                <strong className="text-slate-800">Intervention Plan:</strong> Sanitary lower leaf pruning today; apply Bio-Trichoderma post-rain.
              </p>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button
                onClick={() => setActiveScreen('treatment')}
                className="px-3 py-1 bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white rounded-lg text-xs font-bold shadow-md shadow-blue-600/30"
              >
                Compare Treatments &rarr;
              </button>
              <button
                onClick={() => setActiveScreen('verification')}
                className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold"
              >
                Before/After Verify
              </button>
              <button
                onClick={() => setActiveScreen('officer_escalation')}
                className="px-3 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg text-xs font-semibold border border-blue-200"
              >
                Agronomist Review
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Field Tasks & Pest Surveillance Alert */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Farm Reminders */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-blue-600" />
              <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Field Operations Calendar</h2>
            </div>
            <button
              onClick={() => setActiveScreen('tasks')}
              className="text-xs text-blue-700 font-semibold hover:underline"
            >
              View All ({pendingTasks.length}) &rarr;
            </button>
          </div>

          <div className="space-y-2 mt-2">
            {tasks.slice(0, 2).map((t) => (
              <div
                key={t.id}
                className="p-2.5 rounded-xl border border-slate-100 bg-slate-50 flex items-start justify-between gap-2"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        t.status === 'delayed_weather' ? 'bg-amber-500' : 'bg-blue-600'
                      }`}
                    ></span>
                    <span className="text-xs font-bold text-slate-800">{t.title}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">{t.notes}</p>
                </div>
                <span className="text-[10px] font-mono text-slate-500 whitespace-nowrap bg-white px-1.5 py-0.5 rounded border border-slate-200">
                  {t.dueDate.split(' ')[0]}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Mandi & FPO Price Watch */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Mandi & Market Intelligence</h2>
            </div>
            <button
              onClick={() => setActiveScreen('mandi')}
              className="text-xs text-blue-700 font-semibold hover:underline"
            >
              Selling Options &rarr;
            </button>
          </div>

          <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-600 font-medium">Kolar Tomato APMC (Modal)</p>
                <div className="flex items-baseline gap-2 mt-0.5">
                  <span className="text-lg font-black text-slate-900">₹1,850</span>
                  <span className="text-xs font-bold text-blue-700">/ Quintal (+₹70 today)</span>
                </div>
              </div>
              <span className="px-2 py-1 bg-gradient-to-r from-blue-800 to-blue-700 text-white text-[10px] font-bold rounded-lg uppercase shadow-xs">
                Sell Now vs Pool
              </span>
            </div>
            <p className="text-[11px] text-slate-600 mt-2">
              Kolar Blossom FPO collective pooling adds ~₹120/quintal via direct retail off-take.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
