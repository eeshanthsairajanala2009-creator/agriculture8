import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  TrendingUp,
  Store,
  Warehouse,
  Users,
  Clock,
  ArrowUpRight,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Scale,
} from 'lucide-react';

export const MandiMarketScreen: React.FC = () => {
  const { marketPrices, setActiveScreen } = useApp();
  const [selectedStrategy, setSelectedStrategy] = useState<'sell_now' | 'fpo_pool' | 'cold_storage'>('fpo_pool');

  const strategies = [
    {
      id: 'sell_now',
      title: 'Option A: Sell Now at Kolar APMC Mandi',
      pricePerQuintal: '₹1,850',
      netReturn1Acre: '₹3,02,000 (180 quintals)',
      costs: '₹12,000 (₹4,500 transport + 6% commission & unloading)',
      risk: 'Immediate cash realization; susceptible to midday market gluts.',
      tag: 'Immediate Cash',
      color: 'bg-blue-50 text-blue-900 border-blue-200',
    },
    {
      id: 'fpo_pool',
      title: 'Option B: Kolar Blossom FPO Collective Pooling (Recommended)',
      pricePerQuintal: '₹2,020',
      netReturn1Acre: '₹3,42,000 (+₹40,000 gain)',
      costs: '₹6,000 (Shared refrigerated pickup, 0% commission)',
      risk: 'Payment cleared in 48 hours; guaranteed bulk off-take to Bangalore retail.',
      tag: 'Highest Farmer Margin',
      color: 'bg-blue-50/80 text-blue-950 border-blue-400 ring-2 ring-blue-500/20 shadow-md shadow-blue-950/5',
    },
    {
      id: 'cold_storage',
      title: 'Option C: Short-term Cold Storage Hold (7-10 Days)',
      pricePerQuintal: '₹2,250 (Projected)',
      netReturn1Acre: '₹3,25,000',
      costs: '₹22,000 (₹18,000 storage rent + secondary transport)',
      risk: 'Higher price potential, but fruit weight shrinkage risk (3-5%).',
      tag: 'Speculative Hold',
      color: 'bg-purple-50 text-purple-900 border-purple-200',
    },
  ];

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
                <TrendingUp className="w-4 h-4 text-blue-700" />
              </div>
              <h1 className="text-base font-extrabold text-slate-900">
                Mandi Intelligence & Selling Options (Screen 21)
              </h1>
            </div>
            <p className="text-xs text-slate-500">
              Government Agmarknet feeds, commission deductions & collective pooling margins
            </p>
          </div>

          <a
            href="https://agmarknet.gov.in"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-blue-700 font-semibold hover:underline flex items-center gap-1"
          >
            <span>Agmarknet Portal</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* 3 Mandi Price Ticker Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {marketPrices.map((m, idx) => (
          <div key={idx} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span className="font-bold text-slate-800">{m.district}</span>
              <span className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded font-mono">
                {m.trend === 'up' ? '▲ Up' : '● Stable'}
              </span>
            </div>

            <div>
              <span className="text-xl font-black text-slate-900">₹{m.modalPricePerQuintalInr}</span>
              <span className="text-xs text-slate-500 font-medium"> / Quintal</span>
            </div>

            <p className="text-[11px] text-slate-600 font-medium truncate">{m.mandiName}</p>

            <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-100 flex items-center justify-between">
              <span>Range: ₹{m.minPricePerQuintalInr} - ₹{m.maxPricePerQuintalInr}</span>
              <span className="text-blue-700 font-semibold">Live Feed</span>
            </div>
          </div>
        ))}
      </div>

      {/* 3 Selling Options Comparison (Sell Now vs Pool vs Storage) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
          Compare Selling & Produce Realization Strategies:
        </h2>

        <div className="space-y-3">
          {strategies.map((strat) => (
            <div
              key={strat.id}
              onClick={() => {
                triggerHaptic('light');
                setSelectedStrategy(strat.id as any);
              }}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                strat.color
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-black/5">
                <div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded uppercase bg-black/10">
                    {strat.tag}
                  </span>
                  <h3 className="text-sm font-black text-slate-900 mt-1">{strat.title}</h3>
                </div>

                <div className="sm:text-right shrink-0">
                  <span className="text-xs text-slate-500 block">Est. Net Produce Value</span>
                  <span className="text-base font-black text-slate-900">{strat.netReturn1Acre}</span>
                </div>
              </div>

              <div className="mt-2.5 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-slate-500 block text-[11px]">Deductions (Transport + Fee):</span>
                  <strong className="text-slate-800">{strat.costs}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Trade-off / Risk Note:</span>
                  <span className="text-slate-700">{strat.risk}</span>
                </div>
              </div>

              {strat.id === 'fpo_pool' && (
                <div className="mt-3 flex justify-end">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      triggerHaptic('submit');
                      setActiveScreen('fpo_dashboard');
                    }}
                    className="px-4 py-1.5 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20"
                  >
                    Join Kolar Blossom FPO Batch &rarr;
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
