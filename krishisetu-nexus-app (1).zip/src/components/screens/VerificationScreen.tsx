import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';

export const VerificationScreen: React.FC = () => {
  const { crop, setCrop, addAuditLog, currentUser, setActiveScreen } = useApp();
  const [verificationResult, setVerificationResult] = useState<{
    status: 'improved' | 'unchanged' | 'worsened';
    recoveryPercentage: number;
    observations: string[];
    actionAudited: string;
    nextGuidance: string;
  }>({
    status: 'improved',
    recoveryPercentage: 74,
    observations: [
      'Concentric bullseye rings on lower foliage dried out; sporulation arrested',
      'Fresh flower clusters and upper apical shoots show zero lesion transmission',
      'Protective bio-copper barrier adhered well; no leaf margin scorching detected',
    ],
    actionAudited: 'Sanitary lower leaf pruning + Bio-Copper application post-rain front',
    nextGuidance: 'Continue scouting daily at 08:00 AM. Inoculum load reduced from Moderate to Low.',
  });

  const handleConfirmVerified = () => {
    triggerHaptic('success');
    setCrop((prev) => ({
      ...prev,
      healthStatus: 'improving',
    }));

    addAuditLog({
      actorRole: currentUser.role,
      actorName: currentUser.name,
      actionType: 'DIAGNOSIS_GENERATED',
      details: 'Follow-up re-scan verified 74% recovery in tomato crop health. Status updated to IMPROVING.',
      agentName: 'Verification Agent',
    });

    alert('Farm crop health record updated to "Improving"!');
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
            <CheckCircle2 className="w-4 h-4 text-blue-700" />
          </div>
          <h1 className="text-base font-extrabold text-slate-900">
            Before-and-After Verification Agent (Screen 26)
          </h1>
        </div>
        <p className="text-xs text-slate-500">
          Comparative vision audit evaluating action outcome & pathological symptom regression
        </p>
      </div>

      {/* Side-by-Side Visual Comparison Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Day 0: Before Treatment */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-xs">
            <span className="font-bold text-slate-500 uppercase">Day 0: Before Treatment</span>
            <span className="font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
              Moderate Blight
            </span>
          </div>

          <div className="h-44 bg-slate-950 rounded-xl relative overflow-hidden flex items-center justify-center border border-slate-800">
            <svg viewBox="0 0 100 100" className="w-28 h-28 text-sky-500">
              <path d="M50 12 C28 24 16 62 50 88 C84 62 72 24 50 12 Z" fill="#1e3a8a" stroke="#0f172a" strokeWidth="2" />
              {/* Spreading concentric necrotic rings */}
              <circle cx="48" cy="45" r="9" fill="#4e342e" stroke="#fbc02d" strokeWidth="2" />
              <circle cx="62" cy="58" r="7" fill="#4e342e" stroke="#fbc02d" strokeWidth="1.5" />
              <circle cx="36" cy="64" r="6" fill="#4e342e" stroke="#fbc02d" strokeWidth="1.5" />
            </svg>
            <span className="absolute bottom-2 left-2 bg-black/80 text-white text-[10px] px-2 py-0.5 rounded font-mono">
              Observed: Oct 07 10:15 IST
            </span>
          </div>

          <p className="text-xs text-slate-600">
            Multiple necrotic target spots with chlorotic yellow halo margins spreading upwards towards flower racemes.
          </p>
        </div>

        {/* Day 4: Post-Treatment Re-Scan */}
        <div className="bg-white rounded-2xl border-2 border-blue-500 bg-blue-50/20 p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-blue-200 text-xs">
            <span className="font-bold text-blue-900 uppercase">Day 4: Follow-up Re-scan</span>
            <span className="font-bold text-blue-800 bg-blue-100 px-2 py-0.5 rounded">
              74% Recovery Verified
            </span>
          </div>

          <div className="h-44 bg-slate-950 rounded-xl relative overflow-hidden flex items-center justify-center border border-slate-800">
            <svg viewBox="0 0 100 100" className="w-28 h-28 text-sky-500">
              <path d="M50 12 C28 24 16 62 50 88 C84 62 72 24 50 12 Z" fill="#2563eb" stroke="#1d4ed8" strokeWidth="2" />
              {/* Shrunken dried lesions */}
              <circle cx="48" cy="45" r="5" fill="#1e293b" stroke="#38bdf8" strokeWidth="1" />
              <circle cx="62" cy="58" r="3" fill="#1e293b" stroke="#38bdf8" strokeWidth="1" />
            </svg>
            <span className="absolute bottom-2 left-2 bg-blue-950/90 text-sky-200 text-[10px] px-2 py-0.5 rounded font-mono">
              Re-scanned: Oct 11 08:30 IST
            </span>
          </div>

          <p className="text-xs text-slate-600">
            Lesions fully arrested and dried. Yellow chlorosis cleared. Zero new lesions on fresh terminal leaves.
          </p>
        </div>
      </div>

      {/* Outcome Analysis Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              Treatment Efficacy Outcome
            </span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl font-black text-blue-600">
                {verificationResult.recoveryPercentage}% Visual Recovery
              </span>
              <span className="text-xs font-bold text-blue-800 bg-blue-100 px-2 py-0.5 rounded">
                Condition: IMPROVING
              </span>
            </div>
          </div>

          <button
            onClick={handleConfirmVerified}
            className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20"
          >
            Update Farm Health Record &check;
          </button>
        </div>

        {/* Action Taken Audit */}
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs">
          <span className="font-bold text-slate-800 block mb-0.5">Intervention Protocol Evaluated:</span>
          <p className="text-slate-600">{verificationResult.actionAudited}</p>
        </div>

        {/* Evidence List */}
        <div className="space-y-1.5 text-xs text-slate-700">
          <strong className="block text-slate-900">Computer Vision Morphological Evidence:</strong>
          {verificationResult.observations.map((obs, i) => (
            <div key={i} className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
              <span>{obs}</span>
            </div>
          ))}
        </div>

        <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-500">{verificationResult.nextGuidance}</span>
          <button
            onClick={() => setActiveScreen('dashboard')}
            className="text-xs text-blue-700 font-bold hover:underline"
          >
            Return to Dashboard &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
