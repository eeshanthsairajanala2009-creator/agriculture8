import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  Camera,
  Upload,
  Sparkles,
  CheckCircle2,
  Stethoscope,
  Info,
  ShieldCheck,
} from 'lucide-react';

export const CameraUploadScreen: React.FC = () => {
  const { setActiveScreen, setDiagnosis } = useApp();
  const [selectedSample, setSelectedSample] = useState<'early_blight' | 'healthy' | 'late_blight' | 'leaf_curl' | 'nitrogen'>('early_blight');
  const [isScanning, setIsScanning] = useState(false);

  const samples = [
    {
      id: 'early_blight',
      title: 'Target Spot Bullseye (Early Blight) - Seed Scenario',
      condition: 'Early Blight (Alternaria solani)',
      confidence: 86,
      severity: 'moderate' as const,
      color: '#4e342e',
      spots: [
        { cx: 48, cy: 45, r: 8 },
        { cx: 62, cy: 58, r: 6 },
        { cx: 36, cy: 62, r: 5 },
      ],
      desc: 'Dark concentric brown rings with chlorotic yellow halo on lower foliage.',
    },
    {
      id: 'healthy',
      title: 'Healthy Tomato Leaf (Control Sample)',
      condition: 'Healthy Vigorous Foliage',
      confidence: 94,
      severity: 'low' as const,
      color: '#2e7d32',
      spots: [],
      desc: 'Vibrant green chlorophyll, zero fungal necrosis, clean leaf margins.',
    },
    {
      id: 'late_blight',
      title: 'Water-soaked Dark Lesions (Late Blight)',
      condition: 'Late Blight (Phytophthora infestans)',
      confidence: 81,
      severity: 'high' as const,
      color: '#212121',
      spots: [
        { cx: 50, cy: 35, r: 12 },
        { cx: 40, cy: 60, r: 10 },
      ],
      desc: 'Greasy water-soaked lesions with white downy fungal mildew on underside.',
    },
    {
      id: 'leaf_curl',
      title: 'Upward Puckered Leaves (Leaf Curl Virus)',
      condition: 'Tomato Leaf Curl Begomovirus (ToLCV)',
      confidence: 79,
      severity: 'moderate' as const,
      color: '#fbc02d',
      spots: [
        { cx: 50, cy: 50, r: 14 },
      ],
      desc: 'Stunted puckered leaves curling upward; transmitted by whitefly vectors.',
    },
  ];

  const handleRunAnalysis = () => {
    triggerHaptic('submit');
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      triggerHaptic('success');
      const chosen = samples.find((s) => s.id === selectedSample)!;
      setDiagnosis({
        id: `diag_${Date.now()}`,
        observationId: `obs_${Date.now()}`,
        crop: 'Tomato',
        diseaseOrPest: chosen.condition,
        scientificName: chosen.id === 'early_blight' ? 'Alternaria solani' : chosen.id === 'late_blight' ? 'Phytophthora infestans' : 'Solanum lycopersicum pathology',
        hindiName: chosen.id === 'early_blight' ? 'टमाटर का अगेती झुलसा (Early Blight)' : chosen.condition,
        confidence: chosen.confidence,
        severity: chosen.severity,
        visualEvidence: [
          chosen.desc,
          'Lower leaf canopy shows active pathology; stem junctions monitored',
          'Symptom progression consistent with high relative humidity (88%)',
        ],
        recommendedNextObservation: 'Check stem margins for collar rot and monitor upper fresh leaves daily.',
        requiresExpertEscalation: chosen.severity === 'high',
        aiCertaintyWarning:
          'Computer vision screening carries inherent uncertainty. Never purchase restricted pesticides without label verification and agronomic confirmation.',
        timestamp: new Date().toLocaleTimeString('en-IN') + ' IST',
      });
      setActiveScreen('diagnosis');
    }, 1200);
  };

  const currentSample = samples.find((s) => s.id === selectedSample)!;

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-800">
            <Camera className="w-4 h-4" />
          </div>
          <h1 className="text-base font-extrabold text-slate-900">Crop Doctor Scanner</h1>
        </div>
        <p className="text-xs text-slate-500">
          Upload real camera photos, select test samples, or inspect visual evidence before treating.
        </p>
      </div>

      {/* Main Viewfinder / Canvas */}
      <div className="bg-slate-950 rounded-2xl p-6 text-white text-center relative overflow-hidden border border-slate-800 shadow-xl shadow-blue-950/20">
        {/* Synthetic leaf pathology graphic */}
        <div className="w-56 h-56 mx-auto relative flex items-center justify-center">
          <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-2xl">
            {/* Tomato leaf base */}
            <path
              d="M50 12 C28 24 16 62 50 88 C84 62 72 24 50 12 Z"
              fill="#1e3a8a"
              stroke="#38bdf8"
              strokeWidth="2.5"
            />
            {/* Veins */}
            <line x1="50" y1="18" x2="50" y2="84" stroke="#60a5fa" strokeWidth="1.5" />
            <line x1="50" y1="35" x2="32" y2="28" stroke="#60a5fa" strokeWidth="1" />
            <line x1="50" y1="48" x2="26" y2="44" stroke="#60a5fa" strokeWidth="1" />
            <line x1="50" y1="62" x2="34" y2="60" stroke="#60a5fa" strokeWidth="1" />
            <line x1="50" y1="35" x2="68" y2="28" stroke="#60a5fa" strokeWidth="1" />
            <line x1="50" y1="48" x2="74" y2="44" stroke="#60a5fa" strokeWidth="1" />
            <line x1="50" y1="62" x2="66" y2="60" stroke="#60a5fa" strokeWidth="1" />

            {/* Pathology spots */}
            {currentSample.spots.map((spot, i) => (
              <g key={i}>
                {/* Yellow halo */}
                <circle cx={spot.cx} cy={spot.cy} r={spot.r + 3} fill="#fbc02d" opacity="0.4" />
                {/* Necrotic concentric ring */}
                <circle cx={spot.cx} cy={spot.cy} r={spot.r} fill={currentSample.color} />
                <circle cx={spot.cx} cy={spot.cy} r={spot.r * 0.6} fill="none" stroke="#8d6e63" strokeWidth="1" />
              </g>
            ))}
          </svg>

          {/* Scanning Reticle Animation */}
          {isScanning && (
            <div className="absolute inset-0 border-2 border-sky-400 rounded-2xl animate-pulse flex items-center justify-center">
              <div className="w-full h-1 bg-sky-400 shadow-sky-400 shadow-md animate-bounce"></div>
            </div>
          )}
        </div>

        <div className="mt-3">
          <span className="text-xs font-bold text-sky-400 uppercase tracking-wider block">
            {currentSample.condition}
          </span>
          <p className="text-xs text-slate-300 mt-1 max-w-md mx-auto">
            {currentSample.desc}
          </p>
        </div>

        <div className="mt-4 flex items-center justify-center gap-3">
          <button
            onClick={handleRunAnalysis}
            disabled={isScanning}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 hover:from-blue-600 hover:to-sky-500 disabled:opacity-50 text-white font-extrabold text-xs shadow-lg shadow-blue-900/40 transition-all flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-sky-200" />
            <span>{isScanning ? 'Diagnosing with Crop Doctor...' : 'Diagnose Sample Leaf &rarr;'}</span>
          </button>
        </div>
      </div>

      {/* Labeled Sample Test Set Switcher */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
          Select Standard Labeled Test Sample:
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {samples.map((s) => (
            <button
              key={s.id}
              onClick={() => setSelectedSample(s.id as any)}
              className={`p-3 rounded-xl border text-left transition-all ${
                selectedSample === s.id
                  ? 'border-blue-600 bg-blue-50/70 ring-1 ring-blue-500'
                  : 'border-slate-200 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">{s.title}</span>
                {selectedSample === s.id && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">{s.desc}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
