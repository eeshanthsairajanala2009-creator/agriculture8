import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  Landmark,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  FileCheck,
  AlertCircle,
  HelpCircle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

export const GovernmentSchemesScreen: React.FC = () => {
  const { governmentSchemes, farm, crop } = useApp();
  const [expandedSchemeId, setExpandedSchemeId] = useState(governmentSchemes[0].id);

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
            <Landmark className="w-4 h-4 text-blue-700" />
          </div>
          <h1 className="text-base font-extrabold text-slate-900">
            Government Schemes & PMFBY Crop Insurance (Screen 22)
          </h1>
        </div>
        <p className="text-xs text-slate-500">
          Subsidies, horticulture insurance coverage, and official DBT eligibility checker
        </p>
      </div>

      {/* Safety Notice: No False Promises */}
      <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900 flex items-start gap-2.5">
        <HelpCircle className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
        <div>
          <strong className="block text-blue-950 font-bold">Important Statutory Notice:</strong>
          <p className="text-[11px] leading-relaxed text-blue-800">
            KrishiSetu Nexus indexes official government guidelines and verifies eligibility checklists. Nexus does not promise automatic disbursement or guarantee claim approval; applications must be submitted via official state/central DBT portals.
          </p>
        </div>
      </div>

      {/* Schemes Accordion List */}
      <div className="space-y-3">
        {governmentSchemes.map((sch) => {
          const isExpanded = expandedSchemeId === sch.id;
          return (
            <div
              key={sch.id}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs transition-all"
            >
              <div
                onClick={() => {
                  triggerHaptic('light');
                  setExpandedSchemeId(isExpanded ? '' : sch.id);
                }}
                className="p-4 sm:p-5 flex items-start justify-between gap-3 cursor-pointer hover:bg-slate-50 transition-colors"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900 uppercase">
                      {sch.status}
                    </span>
                    {sch.subsidyPercentage && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900">
                        {sch.subsidyPercentage}% Govt Subsidy
                      </span>
                    )}
                  </div>
                  <h2 className="text-sm font-black text-slate-900 mt-1">{sch.name}</h2>
                  <p className="text-xs text-slate-500">{sch.ministry}</p>
                </div>

                <div className="p-1 rounded-lg bg-slate-100 text-slate-600 shrink-0">
                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </div>

              {isExpanded && (
                <div className="p-4 sm:p-5 pt-0 border-t border-slate-100 space-y-3 text-xs text-slate-700">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <strong className="text-slate-900 block mb-1">Benefit & Financial Coverage:</strong>
                    <p className="text-[11px] leading-relaxed text-slate-600">{sch.targetBenefit}</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <strong className="text-slate-900 block font-bold">Eligibility Checklist (1-Acre Tomato Plot):</strong>
                      <ul className="space-y-1 text-[11px] text-slate-600">
                        {sch.eligibilityConditions.map((cond, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                            <span>{cond}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="space-y-1">
                      <strong className="text-slate-900 block font-bold">Required Documents for Application:</strong>
                      <ul className="space-y-1 text-[11px] text-slate-600">
                        {sch.requiredDocuments.map((doc, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <FileCheck className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                            <span>{doc}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                    <span className="text-[11px] text-blue-900 font-semibold">
                      Matched with your Kolar district tomato profile &check;
                    </span>

                    <a
                      href={sch.applicationPortalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => triggerHaptic('light')}
                      className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20 flex items-center gap-1.5"
                    >
                      <span>Apply on Official Portal</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
