import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { calculatePriorityScore } from '../../utils/formulas';
import { triggerHaptic } from '../../utils/haptics';
import {
  Stethoscope,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  ChevronRight,
  ShieldAlert,
  CloudRain,
  Volume2,
  VolumeX,
  FileText,
} from 'lucide-react';

export const DiagnosisScreen: React.FC = () => {
  const {
    diagnosis,
    crop,
    farm,
    setActiveScreen,
    priorityWeights,
    setPriorityWeights,
    playSpeech,
    stopSpeech,
    isSpeaking,
  } = useApp();

  const [showFormulaCustomizer, setShowFormulaCustomizer] = useState(false);

  // Dynamic priority calculation
  const priorityBreakdown = calculatePriorityScore(
    {
      cropLossRisk: 75,
      treatmentUrgency: 85,
      affectedAcres: farm.totalAcres, // 1.0
      farmerVulnerability: 80, // smallholder marginal farmer
      weatherSensitivity: 95, // heavy rain within 12h
      spreadRisk: 85, // wind-borne fungal spores
      availability: 90,
      sustainability: 85,
    },
    priorityWeights
  );

  const handleSpeakDiagnosis = () => {
    triggerHaptic('medium');
    if (isSpeaking) {
      stopSpeech();
    } else {
      const speech = `फसल डॉक्टर जांच परिणाम: आपके टमाटर के पौधे पर अगेती झुलसा रोग यानी अर्ली ब्लाइट की पुष्टि हुई है। जांच की सटीकता 86 प्रतिशत है। पत्तियों पर भूरे छल्ले देखे गए हैं। चेतावनी: बारिश की संभावना को देखते हुए आज कोई स्प्रे न करें।`;
      playSpeech(speech);
    }
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-100 text-blue-800">
              <Stethoscope className="w-4 h-4" />
            </div>
            <div>
              <h1 className="text-base font-extrabold text-slate-900">Crop Doctor Clinical Diagnosis</h1>
              <p className="text-xs text-slate-500">
                Source-grounded diagnosis & bullseye computer vision pathology
              </p>
            </div>
          </div>

          <button
            onClick={handleSpeakDiagnosis}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs transition-colors ${
              isSpeaking
                ? 'bg-red-500 text-white animate-pulse'
                : 'bg-blue-50 text-blue-900 border border-blue-300 hover:bg-blue-100'
            }`}
          >
            {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-blue-600" />}
            <span className="hidden sm:inline">{isSpeaking ? 'Stop Audio' : 'Listen Diagnosis (आवाज़)'}</span>
          </button>
        </div>
      </div>

      {/* Main Condition Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-bold uppercase tracking-wider">
                Severity: {diagnosis.severity.toUpperCase()}
              </span>
              <span className="text-xs font-mono text-slate-500">
                Timestamp: {diagnosis.timestamp}
              </span>
            </div>
            <h2 className="text-xl font-black text-slate-900 mt-1">
              {diagnosis.diseaseOrPest}
            </h2>
            <p className="text-xs text-slate-500 font-medium italic">
              Scientific Name: {diagnosis.scientificName} &bull; {diagnosis.hindiName}
            </p>
          </div>

          {/* Confidence Meter */}
          <div className="sm:text-right shrink-0">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              Confidence Score
            </span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-2xl font-black text-blue-700">{diagnosis.confidence}%</span>
              <span className="text-xs text-slate-500">(High Likelihood)</span>
            </div>
            <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded font-medium block mt-0.5">
              Never 100% (Safety Caveat)
            </span>
          </div>
        </div>

        {/* Visual Evidence Bullet Points */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            Visual Pathology Evidence Observed:
          </h3>
          <div className="space-y-1.5">
            {diagnosis.visualEvidence.map((ev, i) => (
              <div key={i} className="flex items-start gap-2 p-2 rounded-lg bg-slate-50 border border-slate-100 text-xs text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>{ev}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Cautious Certainty Disclaimer */}
        <div className="p-3 rounded-xl bg-slate-100 text-slate-700 text-xs flex items-start gap-2.5 border border-slate-200">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong className="text-slate-900">Safety Rule Enforced:</strong> {diagnosis.aiCertaintyWarning}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 pt-2">
          <button
            onClick={() => {
              triggerHaptic('medium');
              setActiveScreen('weather');
            }}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs shadow-xs flex items-center gap-1.5"
          >
            <CloudRain className="w-4 h-4" />
            <span>Check Weather & Spray Window &rarr;</span>
          </button>

          <button
            onClick={() => {
              triggerHaptic('medium');
              setActiveScreen('treatment');
            }}
            className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-600/30 flex items-center gap-1.5"
          >
            <span>Compare Treatment Options &rarr;</span>
          </button>

          <button
            onClick={() => {
              triggerHaptic('warning');
              setActiveScreen('officer_escalation');
            }}
            className="px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-800 font-semibold rounded-xl text-xs border border-blue-200 flex items-center gap-1.5"
          >
            <ShieldAlert className="w-4 h-4 text-blue-600" />
            <span>Escalate to Agronomist</span>
          </button>
        </div>
      </div>

      {/* Suggested Priority Formula Calculation Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Priority Formula Calculation
            </h3>
            <p className="text-[11px] text-slate-500">
              priority = 0.25×Loss + 0.15×Urgency + 0.10×Acres + 0.10×Vulnerability + 0.10×Weather + 0.10×Spread + 0.10×Availability + 0.10×Sustainability
            </p>
          </div>

          <button
            onClick={() => setShowFormulaCustomizer(!showFormulaCustomizer)}
            className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center gap-1"
          >
            <Sliders className="w-3.5 h-3.5 text-slate-500" />
            <span>{showFormulaCustomizer ? 'Hide Weights' : 'Adjust Weights'}</span>
          </button>
        </div>

        {/* Priority Score Output */}
        <div className="p-3 rounded-xl bg-linear-to-r from-slate-900 to-slate-800 text-white flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
              Calculated Composite Priority Score
            </span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl font-black text-amber-400">
                {priorityBreakdown.finalPriorityScore} / 100
              </span>
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-400/20 text-amber-300">
                Category: {priorityBreakdown.priorityCategory}
              </span>
            </div>
          </div>
          <span className="text-xs text-slate-300 text-right max-w-xs">
            High priority action indicated due to imminent rain front & flowering vulnerability.
          </span>
        </div>

        {/* Formula Weight Adjusters (Configurable) */}
        {showFormulaCustomizer && (
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-3 text-xs">
            <h4 className="font-bold text-slate-800">Customizable Dynamic Priority Weights:</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="text-[10px] font-bold text-slate-500 block">
                  Crop-Loss ({priorityWeights.cropLossRisk.toFixed(2)})
                </label>
                <input
                  type="range"
                  min="0.05"
                  max="0.5"
                  step="0.05"
                  value={priorityWeights.cropLossRisk}
                  onChange={(e) =>
                    setPriorityWeights((p) => ({ ...p, cropLossRisk: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-blue-600"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 block">
                  Urgency ({priorityWeights.treatmentUrgency.toFixed(2)})
                </label>
                <input
                  type="range"
                  min="0.05"
                  max="0.5"
                  step="0.05"
                  value={priorityWeights.treatmentUrgency}
                  onChange={(e) =>
                    setPriorityWeights((p) => ({ ...p, treatmentUrgency: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-blue-600"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 block">
                  Weather ({priorityWeights.weatherSensitivity.toFixed(2)})
                </label>
                <input
                  type="range"
                  min="0.05"
                  max="0.5"
                  step="0.05"
                  value={priorityWeights.weatherSensitivity}
                  onChange={(e) =>
                    setPriorityWeights((p) => ({ ...p, weatherSensitivity: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-blue-600"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 block">
                  Sustainability ({priorityWeights.sustainability.toFixed(2)})
                </label>
                <input
                  type="range"
                  min="0.05"
                  max="0.5"
                  step="0.05"
                  value={priorityWeights.sustainability}
                  onChange={(e) =>
                    setPriorityWeights((p) => ({ ...p, sustainability: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-blue-600"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
