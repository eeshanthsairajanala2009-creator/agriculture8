import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Product } from '../../types';
import { calculateProductCompatibility } from '../../utils/formulas';
import { triggerHaptic } from '../../utils/haptics';
import {
  ShoppingBag,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  FileText,
  Star,
  Info,
  SlidersHorizontal,
  Plus,
  Volume2,
  VolumeX,
} from 'lucide-react';

export const ProductMarketplaceScreen: React.FC = () => {
  const {
    products,
    weather,
    crop,
    diagnosis,
    addToCart,
    compatibilityWeights,
    setSelectedProduct,
    setActiveScreen,
    playSpeech,
    stopSpeech,
    isSpeaking,
  } = useApp();

  const [filterCategory, setFilterCategory] = useState<'all' | 'fungicide' | 'bio_control'>('all');
  const [organicOnly, setOrganicOnly] = useState(false);

  const filteredProducts = products.filter((p) => {
    if (filterCategory !== 'all' && p.category !== filterCategory) return false;
    if (organicOnly && p.category !== 'bio_control') return false;
    return true;
  });

  const handleInspectProduct = (prod: Product) => {
    setSelectedProduct(prod);
    setActiveScreen('product_details');
  };

  const handleReadProductAloud = (prod: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    if (isSpeaking) {
      stopSpeech();
    } else {
      const text = `${prod.name}. कीमत ₹${prod.priceInr}। सक्रिय तत्व: ${prod.label.activeIngredient}। फसल प्रतीक्षा अवधि: ${prod.label.harvestIntervalDays} दिन। आवश्यक सुरक्षा साधन: ${prod.label.requiredPPE.join(', ')}।`;
      playSpeech(text);
    }
  };

  return (
    <div className="space-y-4 max-w-4xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 rounded-lg bg-blue-100 text-blue-800">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <h1 className="text-base font-extrabold text-slate-900">
                Verified Agricultural Marketplace (Screen 12)
              </h1>
            </div>
            <p className="text-xs text-slate-500">
              Only CIB&RC registered, crop-compatible, in-date products with verified sellers
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveScreen('authenticity')}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl text-xs flex items-center gap-1.5 border border-slate-300"
            >
              <span>Scan QR / Batch Code</span>
            </button>
            <button
              onClick={() => setActiveScreen('cart')}
              className="px-3.5 py-1.5 bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-600/30"
            >
              Go to Cart &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Weather Gate Warning in Marketplace */}
      <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-xs flex items-start gap-2.5">
        <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <strong className="text-amber-950 block">Marketplace Weather Gate Active:</strong>
          <span className="text-amber-900 leading-relaxed">
            Foliar chemicals purchased today are scheduled for post-rain application (after 24h). Trust Agent prevents automatic same-day spraying bookings.
          </span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-white rounded-xl border border-slate-200 p-3 text-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setFilterCategory('all')}
            className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
              filterCategory === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Products ({products.length})
          </button>
          <button
            onClick={() => setFilterCategory('bio_control')}
            className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
              filterCategory === 'bio_control' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Organic & Bio-Control
          </button>
          <button
            onClick={() => setFilterCategory('fungicide')}
            className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
              filterCategory === 'fungicide' ? 'bg-blue-800 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Chemical Fungicides
          </button>
        </div>

        <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700 select-none">
          <input
            type="checkbox"
            checked={organicOnly}
            onChange={(e) => setOrganicOnly(e.target.checked)}
            className="w-4 h-4 accent-blue-600 rounded"
          />
          <span>Organic Preference Only</span>
        </label>
      </div>

      {/* Products Listing Grid */}
      <div className="space-y-3">
        {filteredProducts.map((prod) => {
          const breakdown = calculateProductCompatibility(
            prod,
            crop.cropName,
            diagnosis.diseaseOrPest,
            weather,
            compatibilityWeights
          );

          return (
            <div
              key={prod.id}
              onClick={() => handleInspectProduct(prod)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden ${
                prod.isBlockedByTrustAgent
                  ? 'border-red-300 bg-red-50/50 hover:bg-red-50'
                  : !prod.inStock
                  ? 'border-slate-200 bg-slate-50/70 opacity-75'
                  : 'border-slate-200 bg-white hover:border-blue-500 hover:shadow-md'
              }`}
            >
              {/* Blocked Header Banner if Trust Agent Locked */}
              {prod.isBlockedByTrustAgent && (
                <div className="bg-red-600 text-white px-3 py-1 -mt-4 -mx-4 mb-3 text-xs font-black flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4" />
                    <span>STRICT SAFETY BLOCK: PROHIBITED FROM CHECKOUT</span>
                  </div>
                  <span className="text-[10px] bg-red-800 px-2 py-0.5 rounded font-mono">
                    TRUST & SAFETY AGENT
                  </span>
                </div>
              )}

              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800">
                      {prod.brand}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900">
                      Pack: {prod.packSize}
                    </span>
                    <span className="text-[10px] text-slate-500">
                      Batch: {prod.batch.batchNumber} (Exp: {prod.batch.expiryDate})
                    </span>
                    {prod.sellerVerified ? (
                      <span className="text-[10px] font-bold text-blue-700 flex items-center gap-0.5">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Verified Dealer</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-red-600 flex items-center gap-0.5">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Unverified Seller</span>
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-black text-slate-900 mt-1">
                    {prod.name}
                  </h3>
                  <p className="text-xs text-slate-600 font-medium">
                    Active Formulation: <strong>{prod.formulation}</strong>
                  </p>

                  {/* Why this product explanation */}
                  <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                    <strong className="text-slate-700">Why recommended:</strong> {prod.whyThisProduct}
                  </p>

                  {/* Block Reason Box */}
                  {prod.isBlockedByTrustAgent && (
                    <div className="mt-2 p-2.5 rounded-xl bg-red-100/80 border border-red-200 text-xs text-red-900 font-semibold">
                      {prod.blockReason}
                    </div>
                  )}

                  {/* CIB Registration & Waiting Period */}
                  <div className="mt-2.5 flex flex-wrap items-center gap-3 text-[11px] text-slate-600">
                    <span>
                      CIB&RC: <strong className="text-slate-800">{prod.label.officialCIBRegistrationNumber}</strong>
                    </span>
                    <span>
                      Harvest Wait: <strong className="text-slate-800">{prod.label.harvestIntervalDays} Days</strong>
                    </span>
                    <span>
                      PPE: <strong className="text-slate-800">{prod.label.requiredPPE.join(', ')}</strong>
                    </span>
                  </div>
                </div>

                {/* Price and Cart Action */}
                <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-start gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                  <div className="text-right">
                    <span className="text-xl font-black text-slate-900">₹{prod.priceInr}</span>
                    <span className="text-[10px] text-slate-400 block">incl. all taxes</span>
                  </div>

                  {/* Compatibility Score */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-slate-500">Compatibility:</span>
                    <span
                      className={`text-xs font-black font-mono px-2 py-0.5 rounded ${
                        breakdown.finalScore >= 85
                          ? 'bg-blue-100 text-blue-900'
                          : breakdown.finalScore > 0
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {breakdown.finalScore}%
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 mt-1">
                    <button
                      onClick={(e) => handleReadProductAloud(prod, e)}
                      className="p-2 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs"
                      title="Read product information aloud"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      disabled={prod.isBlockedByTrustAgent || !prod.inStock}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (prod.isBlockedByTrustAgent) {
                          triggerHaptic('error');
                        } else {
                          triggerHaptic('medium');
                        }
                        addToCart(prod, 1);
                      }}
                      className="px-3.5 py-1.5 bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 disabled:opacity-30 disabled:cursor-not-allowed text-white font-bold rounded-lg text-xs shadow-md shadow-blue-600/30 flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{prod.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
