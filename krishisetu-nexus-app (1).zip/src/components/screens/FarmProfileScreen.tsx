import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  MapPin,
  Sprout,
  Droplets,
  Calendar,
  CheckCircle2,
  UserCheck,
  ShieldCheck,
  Activity,
  Save,
  LogIn,
} from 'lucide-react';

export const FarmProfileScreen: React.FC = () => {
  const { farm, setFarm, crop, setCrop, currentUser, currentRole, livestock, addAuditLog, language, setIsSignInModalOpen } = useApp();
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveProfile = () => {
    triggerHaptic('submit');
    setSavedSuccess(true);
    addAuditLog({
      actorRole: currentUser.role,
      actorName: currentUser.name,
      actionType: 'CONSENT_MODIFIED',
      details: `Farm profile updated: ${farm.name} (${farm.totalAcres} acres, ${crop.cropName})`,
      agentName: 'Trust and Safety Agent',
    });
    setTimeout(() => {
      setSavedSuccess(false);
    }, 4000);
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
            <MapPin className="w-4 h-4 text-blue-700" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-slate-900">
              Farm & Crop Profile (Screen 1 & 3)
            </h1>
            <p className="text-xs text-slate-500">
              Land parcel registry, irrigation infrastructure & active vegetative stages
            </p>
          </div>
        </div>
      </div>

      {/* Authenticated Account Identity Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-blue-950 to-blue-900 border border-blue-500/30 rounded-2xl p-4 sm:p-5 text-white shadow-lg shadow-blue-950/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-blue-700 to-sky-500 flex items-center justify-center text-white font-black text-base shadow-md shadow-blue-900/40 shrink-0">
            {currentUser.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black text-white">{currentUser.name}</h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/30 text-sky-200 border border-sky-400/30 capitalize">
                {currentRole}
              </span>
            </div>
            <p className="text-xs text-sky-200 mt-0.5">
              Phone: <strong className="font-mono text-white">{currentUser.phone}</strong> &bull; {currentUser.district}, {currentUser.state}
            </p>
            {currentUser.fpoAffiliation && (
              <span className="text-[11px] text-sky-300 font-semibold block mt-0.5">
                {currentUser.fpoAffiliation}
              </span>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            triggerHaptic('light');
            setIsSignInModalOpen(true);
          }}
          className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 hover:from-blue-600 hover:to-sky-500 text-white font-extrabold rounded-xl text-xs shadow-md shadow-blue-950/30 flex items-center gap-1.5 shrink-0 self-start sm:self-auto transition-transform hover:scale-[1.02]"
        >
          <LogIn className="w-3.5 h-3.5 text-sky-200" />
          <span>Switch Account / Sign In</span>
        </button>
      </div>

      {/* Farm Particulars */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            1-Acre Pilot Farm Coordinates
          </h2>
          <span className="text-xs font-mono text-sky-800 bg-sky-50 border border-sky-200/70 px-2.5 py-0.5 rounded font-bold">
            GPS: {farm.latitude}° N, {farm.longitude}° E
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="font-bold text-slate-700 block mb-1">Farm Plot Name:</label>
            <input
              type="text"
              value={farm.name}
              onChange={(e) => setFarm((prev) => ({ ...prev, name: e.target.value }))}
              className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium text-slate-900"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Total Cultivated Area (Acres):</label>
            <input
              type="number"
              step="0.1"
              value={farm.totalAcres}
              onChange={(e) => setFarm((prev) => ({ ...prev, totalAcres: parseFloat(e.target.value) || 1.0 }))}
              className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium text-slate-900"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Soil Type:</label>
            <select
              value={farm.soilType}
              onChange={(e) => setFarm((prev) => ({ ...prev, soilType: e.target.value as any }))}
              className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium text-slate-900"
            >
              <option value="Red Loam">Red Loam (Eastern Dry Zone)</option>
              <option value="Black Sandy Loam">Black Sandy Loam</option>
              <option value="Clayey">Clayey</option>
              <option value="Alluvial">Alluvial</option>
            </select>
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Primary Irrigation Source:</label>
            <select
              value={farm.irrigationSource}
              onChange={(e) => setFarm((prev) => ({ ...prev, irrigationSource: e.target.value as any }))}
              className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium text-slate-900"
            >
              <option value="Drip System">Precision Drip System</option>
              <option value="Borewell">Borewell Flood</option>
              <option value="Canal">Canal</option>
              <option value="Rainfed">Rainfed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Active Crop Profile */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Sprout className="w-4 h-4 text-blue-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Active Planted Crop & Life Stage
            </h2>
          </div>
          <span className="text-xs font-bold text-slate-500">
            Sown: {crop.sowingDate}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="font-bold text-slate-700 block mb-1">Crop Name:</label>
            <input
              type="text"
              value={crop.cropName}
              onChange={(e) => setCrop((prev) => ({ ...prev, cropName: e.target.value }))}
              className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium text-slate-900"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Cultivar / Variety:</label>
            <input
              type="text"
              value={crop.variety}
              onChange={(e) => setCrop((prev) => ({ ...prev, variety: e.target.value }))}
              className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium text-slate-900"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Phenological Growth Stage:</label>
            <select
              value={crop.stage}
              onChange={(e) => setCrop((prev) => ({ ...prev, stage: e.target.value as any }))}
              className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium text-slate-900"
            >
              <option value="Nursery">Nursery / Seedling</option>
              <option value="Vegetative">Vegetative (30 Days)</option>
              <option value="Flowering">Flowering (45 Days - Seed Scenario)</option>
              <option value="Fruit Formation">Fruit Formation (60 Days)</option>
              <option value="Harvesting">Harvesting (75+ Days)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Integrated Livestock Profile (Livestock Agent Support) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-purple-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Farm Livestock Herd (Livestock Agent Integration)
            </h2>
          </div>
          <span className="text-[11px] text-slate-500">2 Tagged Animals</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          {livestock.map((ani) => (
            <div key={ani.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">{ani.animalType} ({ani.breed})</span>
                <span
                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${
                    ani.status === 'healthy' ? 'bg-blue-100 text-blue-900' : 'bg-amber-100 text-amber-900'
                  }`}
                >
                  {ani.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">Tag: {ani.tagNumber} &bull; Age: {ani.ageYears} Yrs</p>
              <p className="text-[11px] text-slate-600 italic mt-1">{ani.recentConcern}</p>
            </div>
          ))}
        </div>
      </div>

      {savedSuccess && (
        <div className="p-4 rounded-2xl bg-blue-50 border-2 border-blue-400 text-xs text-blue-950 font-bold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
          <span>
            {language === 'te'
              ? 'పొలం సమాచారం విజయవంతంగా భద్రపరచబడింది!'
              : language === 'hi'
              ? 'खेत और फसल की जानकारी सफलतापूर्वक सहेजी गई!'
              : 'Farm and crop profile successfully saved and updated!'}
          </span>
        </div>
      )}

      {/* Action Submit Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={handleSaveProfile}
          className="px-6 py-2.5 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-extrabold rounded-xl text-xs shadow-md shadow-blue-900/20 flex items-center gap-2 transition-all hover:scale-[1.01]"
        >
          <Save className="w-4 h-4" />
          <span>
            {language === 'te'
              ? 'ప్రొఫైల్ సేవ్ చేయండి (Submit)'
              : language === 'hi'
              ? 'प्रोफ़ाइल सहेजें (Submit)'
              : 'Save & Submit Profile'}
          </span>
        </button>
      </div>
    </div>
  );
};
