import React from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  CloudRain,
  Wind,
  Droplets,
  Thermometer,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Volume2,
  VolumeX,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';

export const WeatherScreen: React.FC = () => {
  const { weather, crop, farm, setActiveScreen, playSpeech, stopSpeech, isSpeaking } = useApp();

  const handleSpeakWeather = () => {
    triggerHaptic('medium');
    if (isSpeaking) {
      stopSpeech();
    } else {
      const speech = `मौसम और छिड़काव सलाह: कोलार जिले में अगले 12 घंटों में 85 प्रतिशत भारी बारिश की चेतावनी है। तापमान 27 डिग्री और हवा 14 किलोमीटर प्रति घंटा है। महत्वपूर्ण चेतावनी: आज रासायनिक दवा का छिड़काव बिल्कुल न करें, क्योंकि दवा बारिश में धुल जाएगी। ड्रिप सिंचाई भी आज बंद रखें।`;
      playSpeech(speech);
    }
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-100 text-blue-800">
              <CloudRain className="w-4 h-4" />
            </div>
            <div>
              <h1 className="text-base font-extrabold text-slate-900">
                Weather & Spray-Window Agent
              </h1>
              <p className="text-xs text-slate-500">
                Hourly microclimate, precipitation window & irrigation scheduling
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300">
              Data: {weather.dataSource.toUpperCase()}
            </span>
            <button
              onClick={handleSpeakWeather}
              className={`p-1.5 rounded-lg text-xs font-bold transition-colors ${
                isSpeaking ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
              title="Listen weather advisory"
            >
              {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-blue-600" />}
            </button>
          </div>
        </div>
      </div>

      {/* Critical Spray Window Advisory Banner */}
      <div className="p-5 rounded-2xl bg-amber-500 text-slate-950 shadow-md">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-slate-950 text-amber-400 shrink-0 mt-0.5">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider bg-slate-950 text-white px-2 py-0.5 rounded">
                SPRAY WINDOW: UNSAFE (RAIN WITHIN 12H)
              </span>
              <span className="text-xs font-bold">Rainfall: 85% Probability</span>
            </div>
            <h2 className="text-base sm:text-lg font-black mt-1">
              POSTPONE ALL FOLIAR SPRAYS UNTIL RAIN FRONT PASSES
            </h2>
            <p className="text-xs font-medium mt-1 leading-relaxed text-slate-950">
              {weather.sprayAdvisory}
            </p>
          </div>
        </div>
      </div>

      {/* 4 Microclimate Indicators */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <div className="flex items-center gap-1.5 text-slate-500 mb-1">
            <Thermometer className="w-4 h-4 text-rose-500" />
            <span className="text-[11px] font-bold">Temperature</span>
          </div>
          <span className="text-lg font-black text-slate-900">{weather.temperatureC}°C</span>
          <span className="text-[10px] text-slate-400 block">Optimal for fungal spore germ</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <div className="flex items-center gap-1.5 text-slate-500 mb-1">
            <Droplets className="w-4 h-4 text-blue-500" />
            <span className="text-[11px] font-bold">Humidity</span>
          </div>
          <span className="text-lg font-black text-slate-900">{weather.humidityPercent}%</span>
          <span className="text-[10px] text-amber-600 font-semibold block">High moisture alert</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <div className="flex items-center gap-1.5 text-slate-500 mb-1">
            <Wind className="w-4 h-4 text-sky-500" />
            <span className="text-[11px] font-bold">Wind Speed</span>
          </div>
          <span className="text-lg font-black text-slate-900">{weather.windSpeedKmh} km/h</span>
          <span className="text-[10px] text-blue-600 block">Below 15 km/h limit</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <div className="flex items-center gap-1.5 text-slate-500 mb-1">
            <CloudRain className="w-4 h-4 text-indigo-500" />
            <span className="text-[11px] font-bold">Rain Forecast</span>
          </div>
          <span className="text-lg font-black text-slate-900">{weather.rainExpectedMm} mm</span>
          <span className="text-[10px] text-red-600 font-bold block">85% next 12 hours</span>
        </div>
      </div>

      {/* Irrigation Recommendation Section (Screen 10) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Droplets className="w-4 h-4 text-blue-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Irrigation Recommendation (Screen 10)
            </h2>
          </div>
          <span className="text-[11px] font-bold text-blue-800 bg-blue-50 px-2 py-0.5 rounded">
            Soil: {farm.soilType} &bull; System: {farm.irrigationSource}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900">
          <p className="font-semibold">{weather.irrigationRecommendation}</p>
          <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
            <div>
              <span className="text-blue-700/70 block">Current Soil Moisture:</span>
              <strong className="text-blue-950">78% (Field Capacity)</strong>
            </div>
            <div>
              <span className="text-blue-700/70 block">Crop Water Need:</span>
              <strong className="text-blue-950">Low (Rain-assisted)</strong>
            </div>
            <div>
              <span className="text-blue-700/70 block">Next Scheduled Run:</span>
              <strong className="text-blue-950">In 48 Hours</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Recommended Next Actions */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
        <button
          onClick={() => {
            triggerHaptic('medium');
            setActiveScreen('treatment');
          }}
          className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20"
        >
          Compare Non-Chemical & Post-Rain Treatments &rarr;
        </button>

        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveScreen('tasks');
          }}
          className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl text-xs"
        >
          View Field Tasks & Delay Holds
        </button>
      </div>
    </div>
  );
};
