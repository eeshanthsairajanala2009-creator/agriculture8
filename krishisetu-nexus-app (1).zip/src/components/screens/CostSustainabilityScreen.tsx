import React from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  Calculator,
  Leaf,
  Droplets,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  DollarSign,
  PieChart,
} from 'lucide-react';

export const CostSustainabilityScreen: React.FC = () => {
  const { farm, crop, setActiveScreen } = useApp();

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
            <Calculator className="w-4 h-4 text-blue-700" />
          </div>
          <h1 className="text-base font-extrabold text-slate-900">
            Cost & Sustainability Agent (Screen 20)
          </h1>
        </div>
        <p className="text-xs text-slate-500">
          Transparent 1-acre acreage cost scenarios, yield protection ROI & eco-impact index
        </p>
      </div>

      {/* Yield Protection Estimate Card */}
      <div className="bg-gradient-to-r from-slate-950 via-blue-950 to-blue-900 text-white rounded-2xl p-5 shadow-xl shadow-blue-950/20 border border-blue-500/30 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-500/30 text-sky-200 px-2.5 py-0.5 rounded border border-sky-400/30">
            Yield Protection ROI &bull; 1.0 Acre Tomato Plot
          </span>
          <span className="text-xs text-sky-300 font-mono">Arka Rakshak Hybrid</span>
        </div>

        <div>
          <h2 className="text-lg font-black">Estimated Protected Farm Revenue: ₹65,000+</h2>
          <p className="text-xs text-blue-100 mt-1 leading-relaxed">
            Baseline expected harvest: 180 Quintals @ ₹1,850/quintal = ₹3,33,000. Untreated Alternaria blight causes 25-35% flower drop and fruit lesioning (~₹90,000 loss). Prompt intervention preserves over ₹65,000 in net crop value.
          </p>
        </div>

        <div className="p-3 bg-white/10 rounded-xl text-xs flex items-center justify-between border border-white/10">
          <span>Assumed Untreated Loss: <strong>30%</strong></span>
          <span>Intervention Efficacy: <strong>88%</strong></span>
          <span>Net Protected Value: <strong className="text-sky-300">~₹68,500</strong></span>
        </div>
      </div>

      {/* 3 Cost Scenarios (Low / Medium / High) */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
          Multi-Tier 1-Acre Treatment Scenarios:
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Low Scenario */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-2 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-50 text-sky-800 uppercase block w-fit">
                Low Cost (Organic)
              </span>
              <h3 className="text-sm font-black text-slate-900 mt-2">Pruning + Bio-Trichoderma</h3>
              <p className="text-[11px] text-slate-500 mt-1">
                Sanitary leaf clipping + 1kg Bio-agent applied via drip/knapsack.
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100">
              <span className="text-xl font-black text-sky-700">₹220</span>
              <span className="text-[10px] text-slate-400 block">total direct outlay</span>
            </div>
          </div>

          {/* Medium Scenario */}
          <div className="bg-white rounded-2xl border-2 border-blue-500 bg-blue-50/20 p-4 shadow-xs space-y-2 flex flex-col justify-between relative">
            <span className="absolute -top-2.5 right-4 bg-gradient-to-r from-blue-700 to-sky-600 text-white text-[9px] font-black uppercase px-2 py-0.5 rounded-full shadow-xs">
              Recommended
            </span>
            <div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800 uppercase block w-fit">
                Medium Cost (Contact)
              </span>
              <h3 className="text-sm font-black text-slate-900 mt-2">Kocide 3000 + Manual Knapsack</h3>
              <p className="text-[11px] text-slate-500 mt-1">
                400g Copper Hydroxide WG + ₹100 hired labor/water drum.
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100">
              <span className="text-xl font-black text-slate-900">₹780</span>
              <span className="text-[10px] text-slate-400 block">chemical + application</span>
            </div>
          </div>

          {/* High Scenario */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-2 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-800 uppercase block w-fit">
                High Precision (Drone)
              </span>
              <h3 className="text-sm font-black text-slate-900 mt-2">Kocide + Drone Spray Service</h3>
              <p className="text-[11px] text-slate-500 mt-1">
                Chemical + ₹550 Garuda precision drone pilot (8 min/acre).
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100">
              <span className="text-xl font-black text-purple-900">₹1,230</span>
              <span className="text-[10px] text-slate-400 block">complete turnkey service</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sustainability Agent Environmental Comparison */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <Leaf className="w-4 h-4 text-blue-600" />
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Sustainability & Resource Efficiency Scorecard
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-blue-500" />
              <span>Water Consumption per Acre</span>
            </h3>
            <div className="flex items-center justify-between text-[11px]">
              <span>Traditional Knapsack Sprayer:</span>
              <strong className="text-slate-800">200 Liters / Acre</strong>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span>Precision Drone Spraying:</span>
              <strong className="text-sky-700 font-bold">16 Liters (92% Water Saved!)</strong>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-1.5">
              <Leaf className="w-4 h-4 text-blue-600" />
              <span>Soil Mycorrhiza & Chemical Drift</span>
            </h3>
            <div className="flex items-center justify-between text-[11px]">
              <span>Broad-Spectrum Systemic:</span>
              <strong className="text-red-700">High soil residual & drift</strong>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span>Bio-Trichoderma & Copper WG:</span>
              <strong className="text-sky-700 font-bold">Eco-Friendly (FRAC M01)</strong>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <button
            onClick={() => {
              triggerHaptic('medium');
              setActiveScreen('treatment');
            }}
            className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20"
          >
            Select Action Plan &rarr;
          </button>
          <button
            onClick={() => {
              triggerHaptic('light');
              setActiveScreen('mandi');
            }}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl text-xs"
          >
            Review Mandi Selling Options &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
