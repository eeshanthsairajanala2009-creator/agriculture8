import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  QrCode,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Barcode,
  Search,
  Camera,
  RefreshCw,
} from 'lucide-react';

export const AuthenticityScannerScreen: React.FC = () => {
  const { setActiveScreen, addAuditLog } = useApp();
  const [codeInput, setCodeInput] = useState('NEXUS-VERIFY-KC3000-88910');
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<{
    status: 'authentic' | 'counterfeit' | 'expired';
    batch: string;
    product: string;
    mfgDate: string;
    expDate: string;
    cibrcMatch: boolean;
    sellerMatch: boolean;
    alertMessage: string;
  } | null>({
    status: 'authentic',
    batch: 'KC-2026-04B',
    product: 'Kocide 3000 WG (Copper Hydroxide 46.1% WG)',
    mfgDate: '10 April 2026',
    expDate: '09 April 2028',
    cibrcMatch: true,
    sellerMatch: true,
    alertMessage: 'Genuine batch verified against Ministry of Agriculture CIB&RC Gazette and Corteva secure serial registry.',
  });

  const handleVerify = (codeToVerify?: string) => {
    const code = codeToVerify || codeInput;
    triggerHaptic('medium');
    setIsScanning(true);

    setTimeout(() => {
      setIsScanning(false);
      if (code.includes('KC3000')) {
        triggerHaptic('success');
        setScanResult({
          status: 'authentic',
          batch: 'KC-2026-04B',
          product: 'Kocide 3000 WG (Copper Hydroxide 46.1% WG)',
          mfgDate: '10 April 2026',
          expDate: '09 April 2028',
          cibrcMatch: true,
          sellerMatch: true,
          alertMessage: 'Genuine batch verified against CIB&RC Gazette registration and Corteva secure serial registry.',
        });
      } else if (code.includes('TH2000')) {
        triggerHaptic('success');
        setScanResult({
          status: 'authentic',
          batch: 'TH-2026-08A',
          product: 'Bio-Trichoderma Harzianum 2% WP',
          mfgDate: '01 August 2026',
          expDate: '01 August 2027',
          cibrcMatch: true,
          sellerMatch: true,
          alertMessage: 'Certified authentic biological agent produced by ICAR-IIHR authorized facility.',
        });
      } else {
        triggerHaptic('error');
        setScanResult({
          status: 'counterfeit',
          batch: 'MN-2023-09X (EXPIRED / INVALID)',
          product: 'Monocrotophos 36% SL (Banned / Counterfeit Alert)',
          mfgDate: '01 Sept 2023',
          expDate: '31 Aug 2025 (EXPIRED)',
          cibrcMatch: false,
          sellerMatch: false,
          alertMessage: 'CRITICAL ALERT: Expired batch and invalid security cryptographic hash! Product is not registered for vegetable application. Counterfeit incident logged.',
        });

        addAuditLog({
          actorRole: 'farmer',
          actorName: 'Ramesh Patel',
          actionType: 'PRODUCT_BLOCKED',
          details: `Authenticity Scanner flagged fake/expired QR code: ${code}`,
          agentName: 'Product Authenticity Agent',
        });
      }
    }, 900);
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
            <QrCode className="w-4 h-4 text-blue-700" />
          </div>
          <h1 className="text-base font-extrabold text-slate-900">
            Product Authenticity Scanner (Screen 14)
          </h1>
        </div>
        <p className="text-xs text-slate-500">
          Anti-counterfeit verification via QR, barcode, and CIB&RC batch registry
        </p>
      </div>

      {/* Camera / Barcode Viewfinder */}
      <div className="bg-slate-950 rounded-2xl p-6 text-white text-center relative overflow-hidden border border-slate-800 shadow-xl shadow-blue-950/20">
        <div className="w-44 h-44 mx-auto border-2 border-dashed border-sky-400/80 rounded-2xl flex flex-col items-center justify-center relative shadow-inner">
          <Barcode className="w-20 h-20 text-sky-400" />
          <span className="text-[10px] text-sky-300 font-mono mt-1">ALIGN QR / BARCODE</span>

          {isScanning && (
            <div className="absolute inset-0 bg-blue-500/10 flex items-center justify-center">
              <div className="w-full h-1 bg-sky-400 shadow-md animate-bounce"></div>
            </div>
          )}
        </div>

        <p className="text-xs text-slate-400 mt-3">
          Point device camera at the printed batch barcode or QR stamp on the input container.
        </p>
      </div>

      {/* Code Input & Preset Buttons */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
        <label className="text-xs font-bold text-slate-800 block">
          Enter or Scan Batch Verification Hash:
        </label>

        <div className="flex gap-2">
          <input
            type="text"
            value={codeInput}
            onChange={(e) => setCodeInput(e.target.value)}
            className="flex-1 text-xs p-2.5 rounded-xl border border-slate-300 font-mono outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
            placeholder="NEXUS-VERIFY-..."
          />
          <button
            onClick={() => handleVerify()}
            disabled={isScanning}
            className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20"
          >
            {isScanning ? 'Verifying...' : 'Verify Batch'}
          </button>
        </div>

        {/* Quick Demo Test Presets */}
        <div className="space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">
            Click to test seed scenario codes:
          </span>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => {
                setCodeInput('NEXUS-VERIFY-KC3000-88910');
                handleVerify('NEXUS-VERIFY-KC3000-88910');
              }}
              className="px-2.5 py-1 rounded-lg bg-sky-50 text-sky-900 border border-sky-200 font-medium text-[11px]"
            >
              Test Authentic Kocide 3000
            </button>
            <button
              onClick={() => {
                setCodeInput('NEXUS-VERIFY-TH2000-44911');
                handleVerify('NEXUS-VERIFY-TH2000-44911');
              }}
              className="px-2.5 py-1 rounded-lg bg-sky-50 text-sky-900 border border-sky-200 font-medium text-[11px]"
            >
              Test Bio-Trichoderma
            </button>
            <button
              onClick={() => {
                setCodeInput('INVALID-SUSPICIOUS-BARCODE');
                handleVerify('INVALID-SUSPICIOUS-BARCODE');
              }}
              className="px-2.5 py-1 rounded-lg bg-red-50 text-red-800 border border-red-200 font-medium text-[11px]"
            >
              Test Counterfeit / Expired Batch
            </button>
          </div>
        </div>
      </div>

      {/* Verification Result Card */}
      {scanResult && (
        <div
          className={`p-5 rounded-2xl border shadow-sm space-y-3 ${
            scanResult.status === 'authentic'
              ? 'bg-blue-50/80 border-blue-300'
              : 'bg-red-50 border-red-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {scanResult.status === 'authentic' ? (
              <ShieldCheck className="w-5 h-5 text-blue-700" />
            ) : (
              <ShieldAlert className="w-5 h-5 text-red-700" />
            )}
            <h2 className="text-sm font-black uppercase tracking-wider text-slate-900">
              {scanResult.status === 'authentic'
                ? 'GENUINE BATCH VERIFIED BY NEXUS'
                : 'COUNTERFEIT / EXPIRED PRODUCT DETECTED'}
            </h2>
          </div>

          <p className="text-xs text-slate-700 font-medium leading-relaxed">
            {scanResult.alertMessage}
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-xs">
            <div className="p-2 rounded-lg bg-white border border-slate-200">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Batch Number</span>
              <span className="font-mono font-bold text-slate-900">{scanResult.batch}</span>
            </div>
            <div className="p-2 rounded-lg bg-white border border-slate-200">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Expiry Date</span>
              <span
                className={`font-mono font-bold ${
                  scanResult.status === 'authentic' ? 'text-blue-700' : 'text-red-700'
                }`}
              >
                {scanResult.expDate}
              </span>
            </div>
            <div className="p-2 rounded-lg bg-white border border-slate-200">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">CIB&RC Registry</span>
              <span className="font-bold text-slate-900">
                {scanResult.cibrcMatch ? 'Matches Official Gazette' : 'Discrepancy / Banned'}
              </span>
            </div>
            <div className="p-2 rounded-lg bg-white border border-slate-200">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Dealer Link</span>
              <span className="font-bold text-slate-900">
                {scanResult.sellerMatch ? 'Licensed Agri Dealer' : 'Unregistered Source'}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
