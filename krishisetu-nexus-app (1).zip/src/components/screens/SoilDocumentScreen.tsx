import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  FileSpreadsheet,
  FlaskConical,
  BookOpen,
  MapPin,
  CheckCircle2,
  Calendar,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

export const SoilDocumentScreen: React.FC = () => {
  const { soilReport, farm, crop, documents, services, createBooking, setActiveScreen } = useApp();
  const [selectedDocId, setSelectedDocId] = useState(documents[0].id);
  const [bookingSuccess, setBookingSuccess] = useState<string | null>(null);

  const soilLabService = services.find((s) => s.serviceType === 'soil_testing') || services[1];
  const activeDoc = documents.find((d) => d.id === selectedDocId) || documents[0];

  const handleBookLab = () => {
    triggerHaptic('order');
    const booking = createBooking(soilLabService, 'Tomorrow at 10:00 AM', 'GPS geo-tagged core sample pickup');
    setBookingSuccess(`Sample collection booked! Booking ID: #${booking.id}`);
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
            <FileSpreadsheet className="w-4 h-4 text-blue-700" />
          </div>
          <h1 className="text-base font-extrabold text-slate-900">
            Soil Health Card & Document RAG Agent (Screen 16 & 17)
          </h1>
        </div>
        <p className="text-xs text-slate-500">
          OCR parameter extraction, crop stage nutrient balancing & verified lab registry
        </p>
      </div>

      {/* Official Soil Report Summary Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900 uppercase">
                GOI Verified Soil Test Card
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {soilReport.labRegistrationNumber}
              </span>
            </div>
            <h2 className="text-sm font-black text-slate-900 mt-1">
              {soilReport.labName}
            </h2>
            <p className="text-xs text-slate-500">
              Sample Date: <strong className="text-slate-800">{soilReport.sampleDate}</strong> &bull; Verified by Senior Agronomist
            </p>
          </div>

          <span className="text-xs font-bold text-sky-800 bg-sky-50 px-2.5 py-1 rounded-lg border border-sky-200">
            Plot: {farm.name} (1.0 Acre)
          </span>
        </div>

        {/* 4 Soil Parameters Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Soil pH (Reaction)</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-slate-900">{soilReport.pH}</span>
              <span className="text-[10px] font-bold text-amber-700">({soilReport.pHCategory})</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-1">Ideal: 6.5 - 7.5</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Available Nitrogen (N)</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-rose-700">{soilReport.nitrogenKgHa}</span>
              <span className="text-[10px] text-slate-500">kg/ha</span>
            </div>
            <span className="text-[10px] font-bold text-red-600 block mt-1">Status: LOW (&lt;280)</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Phosphorus (P2O5)</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-slate-900">{soilReport.phosphorusKgHa}</span>
              <span className="text-[10px] text-slate-500">kg/ha</span>
            </div>
            <span className="text-[10px] font-bold text-sky-700 block mt-1">Status: MEDIUM</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Potassium (K2O)</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-slate-900">{soilReport.potassiumKgHa}</span>
              <span className="text-[10px] text-slate-500">kg/ha</span>
            </div>
            <span className="text-[10px] font-bold text-blue-700 block mt-1">Status: OPTIMAL</span>
          </div>
        </div>

        {/* Nutritional Guidance for Flowering Stage */}
        <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900 space-y-1">
          <strong className="block text-blue-950 font-bold">
            Agronomic Guidance for Flowering Tomatoes ({crop.stage}):
          </strong>
          <p className="leading-relaxed">
            {soilReport.recommendedNutrientAdvice}
          </p>
        </div>
      </div>

      {/* Nearby Registered Testing Laboratory (Screen 17) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <FlaskConical className="w-4 h-4 text-purple-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Nearby Registered Testing Laboratories (Screen 17)
            </h2>
          </div>
          <span className="text-[11px] text-slate-500">Distance: 7.5 km</span>
        </div>

        {bookingSuccess && (
          <div className="p-3 bg-blue-50 border border-blue-300 rounded-xl text-xs text-blue-950 font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
            <span>{bookingSuccess}</span>
          </div>
        )}

        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-xs font-bold text-slate-900">{soilLabService.title}</h3>
            <p className="text-[11px] text-slate-600 mt-0.5">
              Provider: <strong className="text-slate-800">{soilLabService.providerName}</strong> &bull; NABL Registered
            </p>
            <p className="text-[11px] text-slate-500 mt-1">
              Equipment: {soilLabService.equipmentDetails}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="text-right">
              <span className="text-base font-black text-slate-900">₹{soilLabService.priceInr}</span>
              <span className="text-[10px] text-slate-500 block">per composite sample</span>
            </div>
            <button
              onClick={handleBookLab}
              className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20"
            >
              Book Sample Pickup
            </button>
          </div>
        </div>
      </div>

      {/* Agricultural Document RAG Viewer */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <BookOpen className="w-4 h-4 text-slate-700" />
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Verified Document Chunks & RAG Citations
          </h2>
        </div>

        <p className="text-xs text-slate-500">
          Every diagnosis and recommendation cites verbatim extracts from official gazettes and bulletins:
        </p>

        {/* Document Selector Pills */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {documents.map((doc) => (
            <button
              key={doc.id}
              onClick={() => setSelectedDocId(doc.id)}
              className={`px-3 py-1.5 rounded-xl text-xs whitespace-nowrap border transition-all ${
                selectedDocId === doc.id
                  ? 'border-blue-600 bg-blue-50 text-blue-950 font-bold shadow-xs'
                  : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {doc.title.slice(0, 32)}...
            </button>
          ))}
        </div>

        {/* Active Document Viewer */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-[11px]">
            <span>Source: <strong className="text-slate-800">{activeDoc.source}</strong></span>
            <span>Page {activeDoc.pageNumber} &bull; {activeDoc.publicationDate}</span>
          </div>

          <h3 className="font-bold text-slate-900 text-xs">{activeDoc.title}</h3>

          <blockquote className="p-3 bg-white rounded-lg border-l-4 border-blue-600 italic text-slate-700 font-serif leading-relaxed">
            "{activeDoc.extractedSnippet}"
          </blockquote>

          <a
            href={activeDoc.verifiedOfficialLink}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] text-blue-700 font-semibold hover:underline flex items-center gap-1 inline-flex mt-1"
          >
            <span>Verify Source on Official Portal</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};
