import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  Users,
  ShoppingBag,
  Plane,
  Truck,
  TrendingUp,
  CheckCircle2,
  AlertTriangle,
  Plus,
} from 'lucide-react';

export const FpoDashboardScreen: React.FC = () => {
  const { currentUser } = useApp();
  const [createdOrderMsg, setCreatedOrderMsg] = useState<string | null>(null);

  const bulkCampaigns = [
    {
      id: 'bulk_01',
      title: 'Bulk Bio-Trichoderma Harzianum 2% WP (ICAR Strain)',
      participatingFarmers: 42,
      totalAcreage: '68 Acres',
      singlePrice: '₹220 / kg',
      bulkGroupPrice: '₹185 / kg (16% Group Discount)',
      status: 'Open for Enrollment (Closes Friday)',
    },
    {
      id: 'bulk_02',
      title: 'Kocide 3000 WG (Copper Hydroxide 500g)',
      participatingFarmers: 28,
      totalAcreage: '40 Acres',
      singlePrice: '₹680 / pack',
      bulkGroupPrice: '₹590 / pack (13% Group Discount)',
      status: 'Target Reached (Dispatched to Kolar Hub)',
    },
  ];

  const handleCreateGroupOrder = () => {
    triggerHaptic('submit');
    setCreatedOrderMsg(
      'New FPO Group Procurement Campaign initiated for Kolar Blossom FPO! Member WhatsApp and SMS alerts generated.'
    );
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 rounded-lg bg-purple-100 text-purple-800">
                <Users className="w-4 h-4" />
              </div>
              <div>
                <h1 className="text-base font-extrabold text-slate-900">
                  Cooperative & FPO Management Hub (Screen 28)
                </h1>
                <p className="text-xs text-slate-500">
                  Logged in as <strong className="text-slate-800">{currentUser.name}</strong> &bull; Kolar Blossom FPO (412 Active Members)
                </p>
              </div>
            </div>
          </div>

          <button
            onClick={handleCreateGroupOrder}
            className="px-3.5 py-1.5 bg-purple-700 hover:bg-purple-600 text-white font-bold rounded-xl text-xs shadow-xs flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Bulk Campaign</span>
          </button>
        </div>
      </div>

      {createdOrderMsg && (
        <div className="p-4 rounded-2xl bg-blue-50 border border-blue-300 text-xs text-blue-950 font-bold flex items-center gap-2 shadow-md shadow-blue-950/10">
          <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
          <span>{createdOrderMsg}</span>
        </div>
      )}

      {/* Aggregate Health Surveillance Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Enrolled Acreage</span>
          <span className="text-lg font-black text-slate-900">480 Acres</span>
          <span className="text-[10px] text-blue-600 font-medium block mt-0.5">Tomato dominant (72%)</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Pest Hotspot Alerts</span>
          <span className="text-lg font-black text-rose-600">38 Active</span>
          <span className="text-[10px] text-slate-500 block mt-0.5">Early Blight cluster</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Shared Drone Fleet</span>
          <span className="text-lg font-black text-indigo-700">3 Drones</span>
          <span className="text-[10px] text-blue-600 font-medium block mt-0.5">Garuda Kisan units</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Bulk Savings Rate</span>
          <span className="text-lg font-black text-blue-700">14.8%</span>
          <span className="text-[10px] text-slate-500 block mt-0.5">Average member gain</span>
        </div>
      </div>

      {/* Group Procurement Campaigns */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
          Active Demand Aggregation & Bulk Purchase Pools:
        </h2>

        <div className="space-y-3">
          {bulkCampaigns.map((camp) => (
            <div key={camp.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-200 text-xs">
                <div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-900 uppercase">
                    {camp.status}
                  </span>
                  <h3 className="text-sm font-black text-slate-900 mt-1">{camp.title}</h3>
                </div>

                <div className="text-left sm:text-right shrink-0">
                  <span className="text-xs font-black text-blue-700">{camp.bulkGroupPrice}</span>
                  <span className="text-[10px] text-slate-400 line-through block">Single MRP: {camp.singlePrice}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                <span>Participating Farmers: <strong className="text-slate-900">{camp.participatingFarmers}</strong></span>
                <span>Total Aggregated Acreage: <strong className="text-slate-900">{camp.totalAcreage}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
