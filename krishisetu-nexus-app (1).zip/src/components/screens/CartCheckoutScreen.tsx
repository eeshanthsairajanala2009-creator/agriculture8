import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  ShoppingCart,
  Trash2,
  CheckCircle2,
  ShieldCheck,
  CreditCard,
  QrCode,
  DollarSign,
  AlertTriangle,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

export const CartCheckoutScreen: React.FC = () => {
  const {
    cart,
    removeFromCart,
    clearCart,
    checkoutCart,
    currentUser,
    setActiveScreen,
    products,
    addToCart,
  } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Cash on Delivery' | 'FPO Group Account'>('UPI');
  const [confirmedLabel, setConfirmedLabel] = useState(true);
  const [orderSuccess, setOrderSuccess] = useState<{ id: string; otp: string; total: number } | null>(null);

  const subtotal = cart.reduce((sum, item) => sum + item.product.priceInr * item.quantity, 0);
  const deliveryFee = cart.length > 0 ? 40 : 0;
  const fpoDiscount = currentUser.fpoAffiliation && cart.length > 0 ? Math.round(subtotal * 0.08) : 0;
  const total = Math.max(0, subtotal + deliveryFee - fpoDiscount);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    if (!confirmedLabel) {
      triggerHaptic('warning');
      alert('Please acknowledge that you have reviewed the CIB&RC product label directions.');
      return;
    }

    triggerHaptic('order');
    const created = checkoutCart(paymentMethod);
    setOrderSuccess({
      id: created.id,
      otp: created.deliveryOtp,
      total: created.totalInr,
    });
  };

  const handleAddSeedSample = () => {
    triggerHaptic('medium');
    const kocide = products.find((p) => p.id === 'prod_kocide');
    if (kocide) addToCart(kocide, 1);
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
              <ShoppingCart className="w-4 h-4 text-blue-700" />
            </div>
            <div>
              <h1 className="text-base font-extrabold text-slate-900">
                Cart & Transparent Checkout (Screen 15)
              </h1>
              <p className="text-xs text-slate-500">
                Verified inputs, FPO group discounts & zero hidden delivery charges
              </p>
            </div>
          </div>

          {cart.length > 0 && (
            <button
              onClick={clearCart}
              className="text-xs text-red-600 font-semibold hover:underline"
            >
              Clear Cart
            </button>
          )}
        </div>
      </div>

      {/* Success Order Confirmation Card */}
      {orderSuccess && (
        <div className="bg-blue-50 border-2 border-blue-400 rounded-2xl p-5 shadow-lg shadow-blue-950/10 space-y-3">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-6 h-6 text-blue-600 shrink-0" />
            <div>
              <span className="text-xs font-mono font-bold text-blue-800">
                ORDER CONFIRMED #{orderSuccess.id}
              </span>
              <h2 className="text-lg font-black text-slate-900">
                Payment Received & Dispatch Scheduled
              </h2>
            </div>
          </div>

          <div className="p-3 bg-white rounded-xl border border-blue-200 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-500 block">Delivery Verification OTP:</span>
              <strong className="text-xl font-mono font-black text-blue-700 tracking-widest">
                {orderSuccess.otp}
              </strong>
            </div>
            <div className="text-right">
              <span className="text-slate-500 block">Total Paid:</span>
              <strong className="text-base font-black text-slate-900">₹{orderSuccess.total}</strong>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={() => setActiveScreen('orders')}
              className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20"
            >
              Track Live Order Milestones &rarr;
            </button>
            <button
              onClick={() => setActiveScreen('tasks')}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl text-xs"
            >
              View Field Application Task
            </button>
          </div>
        </div>
      )}

      {/* Empty State */}
      {cart.length === 0 && !orderSuccess && (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center shadow-xs space-y-3">
          <ShoppingCart className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-700">Your Agricultural Cart is Empty</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Browse verified fungicides, bio-antagonists, and soil amendments compatible with your 1-acre tomato plot.
          </p>
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={handleAddSeedSample}
              className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20 flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Add Kocide 3000 WG (Seed Item)</span>
            </button>
            <button
              onClick={() => setActiveScreen('products')}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl text-xs"
            >
              Browse Marketplace &rarr;
            </button>
          </div>
        </div>
      )}

      {/* Cart Items List */}
      {cart.length > 0 && (
        <div className="space-y-3">
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Selected Verified Inputs ({cart.length})
            </h2>

            <div className="divide-y divide-slate-100">
              {cart.map((item) => (
                <div key={item.product.id} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">{item.product.name}</h3>
                    <p className="text-[11px] text-slate-500">
                      Pack: {item.product.packSize} &bull; Batch: {item.product.batch.batchNumber}
                    </p>
                    <span className="text-[10px] text-blue-700 font-semibold">
                      Seller: {item.product.sellerName} (Verified)
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-slate-900">
                      ₹{item.product.priceInr} &times; {item.quantity}
                    </span>
                    <button
                      onClick={() => removeFromCart(item.product.id)}
                      className="text-slate-400 hover:text-red-600 p-1 rounded"
                      title="Remove"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Transparent Cost Breakdown */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-2 text-xs">
            <h2 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
              Itemized Cost Breakdown
            </h2>

            <div className="flex justify-between text-slate-600">
              <span>Item Subtotal:</span>
              <span>₹{subtotal}</span>
            </div>

            <div className="flex justify-between text-slate-600">
              <span>Delivery & Handling (Kolar Hub):</span>
              <span>₹{deliveryFee}</span>
            </div>

            {fpoDiscount > 0 && (
              <div className="flex justify-between text-blue-700 font-semibold">
                <span>FPO Collective Bulk Discount (8%):</span>
                <span>-₹{fpoDiscount}</span>
              </div>
            )}

            <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-black text-slate-900">
              <span>Total Payable Amount:</span>
              <span className="text-blue-700 font-mono text-base">₹{total}</span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Select Simulated Payment Method:
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {[
                { id: 'UPI', label: 'Simulated UPI', note: 'GPay / PhonePe / BHIM' },
                { id: 'Cash on Delivery', label: 'Cash on Delivery', note: 'Pay at farm gate' },
                { id: 'FPO Group Account', label: 'FPO Collective Wallet', note: 'Kolar Blossom FPO' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setPaymentMethod(m.id as any)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    paymentMethod === m.id
                      ? 'border-blue-600 bg-blue-50/70 ring-1 ring-blue-500 font-bold'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <span className="text-xs text-slate-900 block">{m.label}</span>
                  <span className="text-[10px] text-slate-500">{m.note}</span>
                </button>
              ))}
            </div>

            {/* Mandatory Farmer Consent Checkbox */}
            <label className="flex items-start gap-2.5 pt-2 border-t border-slate-100 text-xs text-slate-700 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={confirmedLabel}
                onChange={(e) => setConfirmedLabel(e.target.checked)}
                className="w-4 h-4 accent-blue-600 rounded mt-0.5"
              />
              <span>
                I confirm that I have reviewed the <strong>CIB&RC product label directions</strong>, harvest interval ({cart[0]?.product.label.harvestIntervalDays || 3} days), and required PPE before application.
              </span>
            </label>

            {/* Checkout Button */}
            <button
              onClick={handleCheckout}
              className="w-full py-3 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-black text-sm rounded-xl shadow-lg shadow-blue-950/20 transition-all flex items-center justify-center gap-2 hover:scale-[1.01]"
            >
              <span>Confirm & Place Order (₹{total}) &rarr;</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
