import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  ShieldAlert,
  CheckCircle2,
  XCircle,
  FileText,
  UserCheck,
  Stethoscope,
  Send,
  Sparkles,
} from 'lucide-react';

export const OfficerEscalationScreen: React.FC = () => {
  const { diagnosis, approveEscalation, rejectEscalation, currentUser } = useApp();
  const [officerNote, setOfficerNote] = useState(
    'Agreed with Early Blight diagnosis. Heavy rain within 12h makes foliar chemical spray unsafe today. Recommended: Sanitary leaf pruning today, followed by Bio-Trichoderma @ 5g/L post-rain.'
  );
  const [actionDone, setActionDone] = useState<string | null>(null);

  const handleApprove = () => {
    triggerHaptic('success');
    approveEscalation(diagnosis.id, officerNote);
    setActionDone('Prescription verified & signed by Dr. Anita Rao. Dispatched to farmer Ramesh Patel.');
  };

  const handleCorrect = () => {
    triggerHaptic('warning');
    rejectEscalation(diagnosis.id, officerNote);
    setActionDone('Prescription corrected & safety disclaimer updated for farmer Ramesh Patel.');
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-800">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-slate-900">
              Agriculture Officer & Agronomist Escalation Queue (Screen 27)
            </h1>
            <p className="text-xs text-slate-500">
              Logged in as <strong className="text-slate-800">{currentUser.name}</strong> (Senior Horticulturist, ICAR UHS)
            </p>
          </div>
        </div>
      </div>

      {actionDone && (
        <div className="p-4 rounded-2xl bg-blue-50 border-2 border-blue-400 text-xs text-blue-950 font-bold flex items-center gap-2 shadow-md shadow-blue-950/10">
          <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
          <span>{actionDone}</span>
        </div>
      )}

      {/* Escalated Case Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900 uppercase">
                Status: {diagnosis.escalationStatus ? diagnosis.escalationStatus.replace('_', ' ').toUpperCase() : 'PENDING REVIEW'}
              </span>
              <span className="text-xs font-mono text-slate-500">ID: {diagnosis.id}</span>
            </div>
            <h2 className="text-base font-black text-slate-900 mt-1">
              Case #8821: Tomato Early Blight (Alternaria solani)
            </h2>
            <p className="text-xs text-slate-500">
              Farmer: <strong>Ramesh Patel</strong> &bull; Kolar District &bull; Flowering Stage (1.0 Acre)
            </p>
          </div>

          <span className="text-xs font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-lg">
            AI Confidence: {diagnosis.confidence}%
          </span>
        </div>

        {/* Visual Pathology Evidence */}
        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 text-xs space-y-2">
          <strong className="text-slate-900 block font-bold">
            Uploaded Leaf Evidence & Computer Vision Extraction:
          </strong>
          <ul className="list-disc pl-4 space-y-1 text-slate-600 text-[11px]">
            {diagnosis.visualEvidence.map((ev, i) => (
              <li key={i}>{ev}</li>
            ))}
          </ul>
        </div>

        {/* Weather Sensitivity Check */}
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950 space-y-1">
          <strong className="block font-bold">Weather Agent Input:</strong>
          <p className="text-[11px] text-amber-900">
            85% rainfall forecasted within next 12 hours. Chemical application should NOT be permitted today.
          </p>
        </div>

        {/* Agronomist Notes & Prescription */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-800 block">
            Agronomist Clinical Advice & Certified Digital Prescription:
          </label>
          <textarea
            value={officerNote}
            onChange={(e) => setOfficerNote(e.target.value)}
            rows={3}
            className="w-full text-xs p-3 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900"
          />
        </div>

        {/* Approval Controls */}
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <button
            onClick={handleCorrect}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs flex items-center gap-1.5"
          >
            <XCircle className="w-4 h-4 text-slate-500" />
            <span>Send Corrected Note</span>
          </button>

          <button
            onClick={handleApprove}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs shadow-xs flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Approve & Sign Verified Advice &rarr;</span>
          </button>
        </div>
      </div>
    </div>
  );
};
