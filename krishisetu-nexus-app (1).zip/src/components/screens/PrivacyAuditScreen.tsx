import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  Lock,
  ShieldCheck,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  FileText,
  UserCheck,
  Eye,
  EyeOff,
  History,
} from 'lucide-react';

export const PrivacyAuditScreen: React.FC = () => {
  const { auditLogs, currentUser, addAuditLog } = useApp();
  const [blurFaces, setBlurFaces] = useState(true);
  const [sharePhoneWithSeller, setSharePhoneWithSeller] = useState(false);
  const [shareGpsWithPilot, setShareGpsWithPilot] = useState(true);
  const [dataDeletedMsg, setDataDeletedMsg] = useState<string | null>(null);

  const handleDeleteAllData = () => {
    triggerHaptic('heavy');
    if (
      window.confirm(
        'Are you sure you want to delete all cached images, voice logs, and personal identifiers? This cannot be undone.'
      )
    ) {
      triggerHaptic('success');
      setDataDeletedMsg('All locally stored voice records, cached photos, and session telemetry purged successfully.');
      addAuditLog({
        actorRole: currentUser.role,
        actorName: currentUser.name,
        actionType: 'DATA_DELETED',
        details: 'Farmer invoked Right to Erasure: local cache, uploaded voice recordings & raw image data wiped.',
        agentName: 'Trust and Safety Agent',
      });
    }
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
            <Lock className="w-4 h-4 text-blue-700" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-slate-900">
              Privacy, Consent & Audit Trail (Screen 2 & 30)
            </h1>
            <p className="text-xs text-slate-500">
              Privacy-first guarantees, automatic face blurring, data erasure & audit logs
            </p>
          </div>
        </div>
      </div>

      {dataDeletedMsg && (
        <div className="p-4 rounded-2xl bg-blue-50 border border-blue-300 text-xs text-blue-950 font-bold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
          <span>{dataDeletedMsg}</span>
        </div>
      )}

      {/* Privacy Guarantees Box */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
          Farmer Data Minimization & Consent Controls:
        </h2>

        <div className="space-y-2 text-xs">
          <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
            <div>
              <span className="font-bold text-slate-900 block">Automatic Facial & Personal ID Blur</span>
              <span className="text-[11px] text-slate-500">
                Blurs human faces and house numbers in crop foliage photos prior to AI processing
              </span>
            </div>
            <input
              type="checkbox"
              checked={blurFaces}
              onChange={(e) => setBlurFaces(e.target.checked)}
              className="w-4 h-4 accent-blue-600 rounded"
            />
          </label>

          <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
            <div>
              <span className="font-bold text-slate-900 block">Precision Farm GPS Sharing for Drone Pilots</span>
              <span className="text-[11px] text-slate-500">
                Shares plot coordinates strictly with the booked drone pilot for automated terrain flight
              </span>
            </div>
            <input
              type="checkbox"
              checked={shareGpsWithPilot}
              onChange={(e) => setShareGpsWithPilot(e.target.checked)}
              className="w-4 h-4 accent-blue-600 rounded"
            />
          </label>

          <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
            <div>
              <span className="font-bold text-slate-900 block">Direct Phone Number Sharing with Sellers</span>
              <span className="text-[11px] text-slate-500">
                Default: Masked virtual relay. Enable only to allow direct WhatsApp delivery coordination
              </span>
            </div>
            <input
              type="checkbox"
              checked={sharePhoneWithSeller}
              onChange={(e) => setSharePhoneWithSeller(e.target.checked)}
              className="w-4 h-4 accent-blue-600 rounded"
            />
          </label>
        </div>

        {/* Right to Erasure / Delete Data */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Right to Erasure &bull; Section 12 Digital Data Protection
          </span>
          <button
            onClick={handleDeleteAllData}
            className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 font-bold rounded-xl text-xs border border-red-200 flex items-center gap-1.5 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Purge All Stored Data</span>
          </button>
        </div>
      </div>

      {/* Immutable Audit Log Table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-slate-700" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Tamper-Evident System Audit Trail ({auditLogs.length} Events)
            </h2>
          </div>
          <span className="text-[10px] font-mono text-sky-800 bg-sky-50 px-2 py-0.5 rounded font-bold border border-sky-200/60">
            Cryptographic Integrity Verified
          </span>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {auditLogs.map((log) => (
            <div key={log.id} className="py-2.5 space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-slate-400 font-bold">{log.timestamp}</span>
                  <span className="px-1.5 py-0.2 rounded font-bold uppercase text-[9px] bg-slate-100 text-slate-700">
                    {log.actionType}
                  </span>
                </div>
                <span className="text-blue-700 font-semibold">{log.agentName}</span>
              </div>
              <p className="text-slate-700 font-medium">{log.details}</p>
              <span className="text-[10px] text-slate-400">Actor: {log.actorName} ({log.actorRole})</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
