import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { triggerHaptic } from '../../utils/haptics';
import {
  Store,
  Package,
  Plus,
  CheckCircle2,
  AlertTriangle,
  QrCode,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';

export const SellerDashboardScreen: React.FC = () => {
  const { products, setProducts, currentUser, addAuditLog } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdPrice, setNewProdPrice] = useState('450');
  const [newProdBatch, setNewProdBatch] = useState('BATCH-2026-X1');
  const [newProdExp, setNewProdExp] = useState('2028-06-30');

  const handleAddNewBatch = () => {
    if (!newProdName.trim()) return;
    triggerHaptic('submit');

    const newProduct = {
      id: `prod_${Date.now()}`,
      name: newProdName,
      brand: 'KisanSeva Inputs',
      category: 'bio_control' as const,
      formulation: 'Botanical Formulation 5% EC',
      packSize: '1 L',
      priceInr: parseFloat(newProdPrice) || 450,
      sellerId: currentUser.id,
      sellerName: currentUser.name,
      sellerVerified: true,
      inStock: true,
      stockUnits: 50,
      compatibilityScore: 88,
      label: {
        id: `lbl_${Date.now()}`,
        activeIngredient: 'Azadirachtin 50,000 ppm',
        chemicalGroup: 'Botanical Bio-Pesticide',
        targetPests: ['Early Blight', 'Whitefly', 'Thrips'],
        targetCrops: ['Tomato', 'Chilli', 'Okra'],
        applicationRatePerAcre: '500ml in 200L water',
        waterVolumeLitersPerAcre: '200 L',
        harvestIntervalDays: 0,
        requiredPPE: ['Face mask'],
        toxicologyColorCode: 'Green (Caution)' as const,
        storageAndDisposal: 'Keep in shade.',
        officialCIBRegistrationNumber: 'CIR-99,102/2024-Neem-88',
      },
      batch: {
        batchNumber: newProdBatch,
        manufacturingDate: '2026-06-01',
        expiryDate: newProdExp,
        qrVerificationCode: `NEXUS-VERIFY-${newProdBatch}`,
        isExpired: false,
        isAuthentic: true,
      },
      rating: 5.0,
      reviewsCount: 1,
      isBlockedByTrustAgent: false,
      whyThisProduct: 'Certified seller inventory uploaded via Nexus verified batch portal.',
    };

    setProducts((prev) => [newProduct, ...prev]);
    setShowAddModal(false);

    addAuditLog({
      actorRole: 'seller',
      actorName: currentUser.name,
      actionType: 'ORDER_PLACED',
      details: `Added new verified product batch: ${newProduct.name} (${newProduct.batch.batchNumber})`,
      agentName: 'Product Marketplace Agent',
    });
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 rounded-lg bg-amber-100 text-amber-900">
                <Store className="w-4 h-4" />
              </div>
              <h1 className="text-base font-extrabold text-slate-900">
                Agri-Dealer & Service Provider Hub (Screen 29)
              </h1>
            </div>
            <p className="text-xs text-slate-500">
              Logged in as <strong className="text-slate-800">{currentUser.name}</strong> &bull; License #KA-AGR-KLR-8891
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs shadow-xs flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Batch / Stock</span>
          </button>
        </div>
      </div>

      {/* Stock Health & Compliance Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Listed SKUs</span>
          <span className="text-lg font-black text-slate-900">{products.length} Items</span>
          <span className="text-[10px] text-blue-600 font-medium block mt-0.5">3 Active Batches</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Compliance Gate</span>
          <span className="text-lg font-black text-blue-600">100% Passed</span>
          <span className="text-[10px] text-slate-500 block mt-0.5">CIB&RC Verified</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Flagged / Expired</span>
          <span className="text-lg font-black text-rose-600">1 Item Locked</span>
          <span className="text-[10px] text-red-600 block mt-0.5">Trust Agent Blocked</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Dispatch SLA</span>
          <span className="text-lg font-black text-slate-900">4 Hours</span>
          <span className="text-[10px] text-blue-600 font-medium block mt-0.5">Kolar Farm Gate</span>
        </div>
      </div>

      {/* Dealer Inventory Table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
        <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
          Managed Batch Inventory & Expiry Watch:
        </h2>

        <div className="divide-y divide-slate-100 text-xs">
          {products.map((p) => (
            <div key={p.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-slate-900">{p.name}</h3>
                  {p.isBlockedByTrustAgent ? (
                    <span className="text-[9px] font-bold bg-red-100 text-red-800 px-1.5 py-0.2 rounded">
                      BLOCKED / EXPIRED
                    </span>
                  ) : (
                    <span className="text-[9px] font-bold bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded">
                      VERIFIED STOCK
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Batch: <strong className="font-mono">{p.batch.batchNumber}</strong> &bull; Exp: <strong className="font-mono">{p.batch.expiryDate}</strong> &bull; CIB: {p.label.officialCIBRegistrationNumber}
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="font-black text-slate-900 text-sm">₹{p.priceInr}</span>
                <span className="text-slate-500 text-[11px]">Stock: {p.stockUnits} units</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-100">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-5 space-y-4 border border-slate-200">
            <h3 className="text-base font-extrabold text-slate-900">Add Verified Product Batch</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-800 block mb-1">Product Title:</label>
                <input
                  type="text"
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="e.g. Bio-Neem Pure Azadirachtin 5% EC"
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-amber-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Price (₹):</label>
                  <input
                    type="number"
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-amber-600"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Batch Code:</label>
                  <input
                    type="text"
                    value={newProdBatch}
                    onChange={(e) => setNewProdBatch(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-amber-600 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">Expiry Date:</label>
                <input
                  type="date"
                  value={newProdExp}
                  onChange={(e) => setNewProdExp(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-amber-600 font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 text-slate-600 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleAddNewBatch}
                className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs shadow-xs"
              >
                Publish Batch
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
