import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Task } from '../../types';
import { triggerHaptic } from '../../utils/haptics';
import {
  Package,
  CalendarCheck,
  CheckCircle2,
  Clock,
  Truck,
  AlertTriangle,
  Plus,
  WifiOff,
  ChevronRight,
} from 'lucide-react';

export const OrdersTasksScreen: React.FC = () => {
  const { orders, bookings, tasks, setTasks, isOffline, addAuditLog, currentUser } = useApp();
  const [activeTab, setActiveTab] = useState<'tasks' | 'orders' | 'bookings'>('tasks');
  const [newTaskTitle, setNewTaskTitle] = useState('');

  const toggleTaskCompletion = (taskId: string) => {
    triggerHaptic('light');
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const nextStatus = t.status === 'completed' ? 'planned' : 'completed';
          addAuditLog({
            actorRole: currentUser.role,
            actorName: currentUser.name,
            actionType: 'CONSENT_MODIFIED',
            details: `Task "${t.title}" toggled to ${nextStatus.toUpperCase()} ${isOffline ? '(Cached Offline)' : ''}`,
            agentName: 'Field Operations Agent',
          });
          return {
            ...t,
            status: nextStatus,
            completedOffline: isOffline,
          };
        }
        return t;
      })
    );
  };

  const handleAddNewTask = () => {
    if (!newTaskTitle.trim()) return;
    triggerHaptic('submit');
    const newTask: Task = {
      id: `task_${Date.now()}`,
      title: newTaskTitle.trim(),
      category: 'scouting',
      status: 'planned',
      dueDate: '2026-10-10 08:00',
      notes: 'Custom farm reminder added by farmer.',
      weatherDependent: false,
      completedOffline: isOffline,
    };
    setTasks((prev) => [newTask, ...prev]);
    setNewTaskTitle('');
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
                <CalendarCheck className="w-4 h-4 text-blue-700" />
              </div>
              <h1 className="text-base font-extrabold text-slate-900">
                Operations Calendar & Order Tracking (Screen 24 & 25)
              </h1>
            </div>
            <p className="text-xs text-slate-500">
              Weather-aware farm task scheduler, offline completion sync & live delivery OTP
            </p>
          </div>

          {isOffline && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-orange-100 text-orange-900 flex items-center gap-1 border border-orange-300">
              <WifiOff className="w-3 h-3" />
              <span>Offline Queue Active</span>
            </span>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-xl bg-slate-100 p-1 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('tasks')}
          className={`flex-1 py-2 rounded-lg transition-all ${
            activeTab === 'tasks' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Farm Tasks ({tasks.length})
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex-1 py-2 rounded-lg transition-all ${
            activeTab === 'orders' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Product Orders ({orders.length})
        </button>
        <button
          onClick={() => setActiveTab('bookings')}
          className={`flex-1 py-2 rounded-lg transition-all ${
            activeTab === 'bookings' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Service Bookings ({bookings.length})
        </button>
      </div>

      {/* Tasks Tab */}
      {activeTab === 'tasks' && (
        <div className="space-y-3">
          {/* Add quick task */}
          <div className="bg-white rounded-2xl border border-slate-200 p-3 shadow-xs flex gap-2">
            <input
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="Add new farm task (e.g. Inspect tomato blossom clusters)..."
              className="flex-1 text-xs px-3 py-2 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-800"
            />
            <button
              onClick={handleAddNewTask}
              disabled={!newTaskTitle.trim()}
              className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 disabled:opacity-40 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-md shadow-blue-900/20"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </div>

          <div className="space-y-2">
            {tasks.map((task) => {
              const isCompleted = task.status === 'completed';
              return (
                <div
                  key={task.id}
                  onClick={() => toggleTaskCompletion(task.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                    isCompleted
                      ? 'bg-slate-50/80 border-slate-200 opacity-70'
                      : task.status === 'delayed_weather'
                      ? 'bg-amber-50/70 border-amber-300'
                      : 'bg-white border-slate-200 hover:border-blue-500'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={isCompleted}
                      onChange={() => {}}
                      className="w-4 h-4 accent-blue-600 rounded mt-0.5 cursor-pointer"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-xs font-bold ${
                            isCompleted ? 'line-through text-slate-500' : 'text-slate-900'
                          }`}
                        >
                          {task.title}
                        </span>
                        {task.status === 'delayed_weather' && (
                          <span className="text-[10px] font-bold bg-amber-200 text-amber-950 px-1.5 py-0.2 rounded">
                            Weather Hold
                          </span>
                        )}
                        {task.completedOffline && (
                          <span className="text-[9px] font-mono bg-orange-100 text-orange-800 px-1 rounded">
                            Offline Synced
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{task.notes}</p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono text-slate-400 bg-white px-2 py-0.5 rounded border border-slate-200 shrink-0">
                    {task.dueDate}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <div className="space-y-3">
          {orders.map((ord) => (
            <div
              key={ord.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
                <div>
                  <span className="text-xs font-mono font-bold text-blue-800">{ord.id}</span>
                  <p className="text-[11px] text-slate-500">Ordered: {ord.createdAt}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-black text-slate-900 bg-sky-50 text-sky-900 border border-sky-200 px-2.5 py-1 rounded-lg">
                    Delivery OTP: {ord.deliveryOtp}
                  </span>
                  <span className="text-xs font-bold capitalize px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                    {ord.deliveryStatus}
                  </span>
                </div>
              </div>

              {/* Items */}
              <div className="space-y-1 text-xs">
                {ord.items.map((item, i) => (
                  <div key={i} className="flex justify-between text-slate-700">
                    <span>{item.productName} &times; {item.quantity}</span>
                    <strong className="text-slate-900 font-mono">₹{item.totalPrice}</strong>
                  </div>
                ))}
              </div>

              {/* Delivery ETA */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs flex items-center justify-between">
                <span className="text-slate-600">
                  Est. Delivery: <strong className="text-slate-900">{ord.estimatedDeliveryDate}</strong>
                </span>
                <span className="text-blue-700 font-semibold">Payment: {ord.paymentMethod} (₹{ord.totalInr})</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Bookings Tab */}
      {activeTab === 'bookings' && (
        <div className="space-y-3">
          {bookings.map((bk) => (
            <div
              key={bk.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-2"
            >
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <span className="text-xs font-mono font-bold text-purple-800">{bk.id}</span>
                  <h3 className="text-sm font-black text-slate-900">{bk.serviceTitle}</h3>
                </div>
                <span className="text-xs font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900 uppercase">
                  {bk.status}
                </span>
              </div>

              <div className="text-xs text-slate-600 space-y-1">
                <p>Provider: <strong className="text-slate-800">{bk.providerName}</strong></p>
                <p>Scheduled: <strong className="text-slate-800">{bk.scheduledDate}</strong></p>
                <p>Notes: {bk.notes}</p>
              </div>

              <div className="pt-2 border-t border-slate-100 flex justify-between text-xs font-bold">
                <span className="text-slate-600">Total Charged:</span>
                <span className="text-blue-700 font-mono">₹{bk.totalChargeInr}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
