import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ServiceListing } from '../../types';
import { triggerHaptic } from '../../utils/haptics';
import {
  Wrench,
  Plane,
  ShieldCheck,
  Star,
  Clock,
  MapPin,
  Calendar,
  CheckCircle2,
  CalendarCheck,
  AlertTriangle,
  ChevronRight,
} from 'lucide-react';

export const ServicesScreen: React.FC = () => {
  const { services, createBooking, setActiveScreen } = useApp();
  const [selectedService, setSelectedService] = useState<ServiceListing | null>(null);
  const [bookingDate, setBookingDate] = useState('2026-10-09 (Post-Rain Clear Morning)');
  const [bookingNotes, setBookingNotes] = useState('1.0 Acre Tomato plot - Precision bio-copper foliar spraying');
  const [confirmedBookingId, setConfirmedBookingId] = useState<string | null>(null);

  const handleConfirmBooking = () => {
    if (!selectedService) return;
    triggerHaptic('order');
    const booking = createBooking(selectedService, bookingDate, bookingNotes);
    setConfirmedBookingId(booking.id);
    setSelectedService(null);
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto pb-16 sm:pb-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 rounded-lg bg-blue-100 text-blue-900">
                <Plane className="w-4 h-4 text-blue-700" />
              </div>
              <h1 className="text-base font-extrabold text-slate-900">
                Agricultural Service Marketplace (Screen 18 & 19)
              </h1>
            </div>
            <p className="text-xs text-slate-500">
              Verified precision drone pilots, soil analysts, agronomists & shared tractors
            </p>
          </div>

          <button
            onClick={() => setActiveScreen('orders')}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl border border-slate-300"
          >
            Track Active Bookings
          </button>
        </div>
      </div>

      {/* Booking Success Banner */}
      {confirmedBookingId && (
        <div className="p-4 rounded-2xl bg-blue-50 border-2 border-blue-400 shadow-md shadow-blue-950/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
            <div>
              <h3 className="text-xs font-black text-slate-900 uppercase">
                Service Booking Confirmed #{confirmedBookingId}
              </h3>
              <p className="text-xs text-slate-600">
                Provider has accepted the scheduled slot. Tracking details added to Operations Calendar.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveScreen('tasks')}
            className="px-3 py-1.5 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-lg text-xs shrink-0 shadow-xs"
          >
            View Calendar &rarr;
          </button>
        </div>
      )}

      {/* Services List */}
      <div className="space-y-3">
        {services.map((srv) => (
          <div
            key={srv.id}
            className="p-4 sm:p-5 rounded-2xl border border-slate-200 bg-white hover:border-blue-400 transition-all shadow-xs space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800 uppercase">
                    {srv.serviceType.replace('_', ' ')}
                  </span>
                  <span className="text-[10px] text-slate-500 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400" />
                    <span>{srv.distanceKm} km away (Kolar Hub)</span>
                  </span>
                  <span className="text-[10px] font-bold text-sky-700 flex items-center gap-0.5">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Verified Provider</span>
                  </span>
                </div>

                <h2 className="text-sm font-black text-slate-900 mt-1">{srv.title}</h2>
                <p className="text-xs text-slate-500">
                  Operated by <strong className="text-slate-800">{srv.providerName}</strong> &bull; Rating {srv.rating} &starf;
                </p>
              </div>

              <div className="sm:text-right shrink-0">
                <span className="text-lg font-black text-slate-900">₹{srv.priceInr}</span>
                <span className="text-[10px] text-slate-500 block">{srv.priceUnit}</span>
                {srv.travelChargeInr > 0 && (
                  <span className="text-[10px] text-slate-400 block">+ ₹{srv.travelChargeInr} travel</span>
                )}
              </div>
            </div>

            {/* Equipment & Details */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-700 space-y-1">
              <p>
                <strong className="text-slate-900">Equipment / Methodology:</strong> {srv.equipmentDetails}
              </p>
              <p>
                <strong className="text-slate-900">Required Farmer Prep:</strong> {srv.requiredPreparation}
              </p>
              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                <span>Availability: <strong className="text-blue-700">{srv.availability}</strong></span>
                <span>Languages: {srv.languagesSupported.join(', ')}</span>
              </div>
            </div>

            {/* Book Now Button */}
            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-slate-500">{srv.cancellationPolicy}</span>
              <button
                onClick={() => setSelectedService(srv)}
                className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20 flex items-center gap-1.5"
              >
                <CalendarCheck className="w-3.5 h-3.5" />
                <span>Book Service Slot &rarr;</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Booking Slot Modal / Drawer */}
      {selectedService && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-100">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-5 space-y-4 border border-slate-200">
            <div className="pb-2 border-b border-slate-100">
              <span className="text-[10px] font-bold uppercase text-blue-700">Schedule Service</span>
              <h3 className="text-base font-extrabold text-slate-900">{selectedService.title}</h3>
              <p className="text-xs text-slate-500 mt-0.5">Provider: {selectedService.providerName}</p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-800 block mb-1">Select Scheduled Slot:</label>
                <select
                  value={bookingDate}
                  onChange={(e) => setBookingDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                >
                  <option value="2026-10-09 (Post-Rain Clear Morning - 07:00 AM)">
                    Friday 07:00 AM (Recommended - Post-rain clear window)
                  </option>
                  <option value="2026-10-09 (Post-Rain Afternoon - 03:30 PM)">
                    Friday 03:30 PM (Evening window)
                  </option>
                  <option value="2026-10-10 (Saturday Morning - 08:00 AM)">
                    Saturday 08:00 AM
                  </option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">Plot Details / Notes:</label>
                <textarea
                  value={bookingNotes}
                  onChange={(e) => setBookingNotes(e.target.value)}
                  rows={2}
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                />
              </div>

              {/* Price Breakdown */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Base Service Fee:</span>
                  <span>₹{selectedService.priceInr}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Pilot Travel Charge:</span>
                  <span>₹{selectedService.travelChargeInr}</span>
                </div>
                <div className="pt-1 border-t border-slate-200 flex justify-between font-bold text-slate-900">
                  <span>Total Amount:</span>
                  <span className="text-blue-700">
                    ₹{selectedService.priceInr + selectedService.travelChargeInr}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedService(null)}
                className="px-4 py-2 text-slate-600 hover:text-slate-900 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmBooking}
                className="px-5 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-600 hover:from-blue-800 hover:to-cyan-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/20"
              >
                Confirm Booking
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
