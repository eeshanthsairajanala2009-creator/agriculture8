import React, { useState } from 'react';
import {
  X,
  Smartphone,
  KeyRound,
  Users,
  UserPlus,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Lock,
  Eye,
  EyeOff,
  PhoneCall,
  RefreshCw,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DEMO_USERS } from '../data/seedData';
import { UserRole } from '../types';
import { triggerHaptic } from '../utils/haptics';

interface SignInModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type AuthTab = 'otp' | 'password' | 'persona' | 'register';

export const SignInModal: React.FC<SignInModalProps> = ({ isOpen, onClose }) => {
  const { signIn, signUp, currentRole, currentUser, isAuthenticated, signOut } = useApp();

  const [activeTab, setActiveTab] = useState<AuthTab>('otp');
  
  // Mobile OTP state
  const [phoneNumber, setPhoneNumber] = useState('98452 11042');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpTimer, setOtpTimer] = useState(45);
  const [selectedOtpRole, setSelectedOtpRole] = useState<UserRole>('farmer');

  // Password / Kisan ID state
  const [identifier, setIdentifier] = useState('KA-KLR-KISAN-409');
  const [password, setPassword] = useState('NexusPass@2026');
  const [showPassword, setShowPassword] = useState(false);

  // Registration state
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('farmer');
  const [regDistrict, setRegDistrict] = useState('Kolar');
  const [regState, setRegState] = useState('Karnataka');
  const [regCrop, setRegCrop] = useState('Tomato (Hybrid)');

  // Feedback banner
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isOpen) return null;

  const handleSendOtp = () => {
    if (!phoneNumber.trim()) {
      setStatusMsg({ type: 'error', text: 'Please enter a valid 10-digit mobile number' });
      return;
    }
    triggerHaptic('light');
    setOtpSent(true);
    setOtpCode('409210'); // Simulated instant OTP for convenience
    setStatusMsg({
      type: 'success',
      text: 'OTP sent via SMS to +91 ' + phoneNumber + '. Use simulated OTP: 409210',
    });
  };

  const handleVerifyOtp = () => {
    if (otpCode !== '409210' && otpCode.length < 4) {
      setStatusMsg({ type: 'error', text: 'Invalid verification code. Enter 409210' });
      return;
    }
    triggerHaptic('submit');
    const baseUser = DEMO_USERS[selectedOtpRole] || DEMO_USERS.farmer;
    signIn(
      {
        ...baseUser,
        phone: `+91 ${phoneNumber}`,
      },
      selectedOtpRole
    );
    setStatusMsg({ type: 'success', text: `Welcome back, ${baseUser.name}! Signed in successfully.` });
    setTimeout(() => {
      onClose();
      setStatusMsg(null);
    }, 600);
  };

  const handlePasswordSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim()) {
      setStatusMsg({ type: 'error', text: 'Please enter your Mobile, Email or Kisan ID' });
      return;
    }
    triggerHaptic('submit');
    // Map to farmer or admin if admin keyword
    const role: UserRole = identifier.toLowerCase().includes('admin')
      ? 'admin'
      : identifier.toLowerCase().includes('officer')
      ? 'officer'
      : 'farmer';
    const baseUser = DEMO_USERS[role];
    signIn(baseUser, role);
    setStatusMsg({ type: 'success', text: `Authenticated successfully as ${baseUser.name}` });
    setTimeout(() => {
      onClose();
      setStatusMsg(null);
    }, 600);
  };

  const handlePersonaSelect = (roleKey: UserRole) => {
    triggerHaptic('medium');
    const targetUser = DEMO_USERS[roleKey];
    signIn(targetUser, roleKey);
    setStatusMsg({
      type: 'success',
      text: `Signed in as ${targetUser.name} (${roleKey.toUpperCase()})`,
    });
    setTimeout(() => {
      onClose();
      setStatusMsg(null);
    }, 500);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regPhone.trim()) {
      setStatusMsg({ type: 'error', text: 'Please enter full name and mobile number' });
      return;
    }
    triggerHaptic('submit');
    signUp({
      name: regName,
      phone: `+91 ${regPhone}`,
      role: regRole,
      district: regDistrict,
      state: regState,
      cropName: regCrop,
    });
    setStatusMsg({ type: 'success', text: `Registration complete! Welcome to KrishiSetu Nexus, ${regName}.` });
    setTimeout(() => {
      onClose();
      setStatusMsg(null);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Shiny Navy Header */}
        <div className="px-5 py-4 border-b border-blue-900 bg-gradient-to-r from-slate-950 via-blue-950 to-blue-900 text-white flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-400 shadow-sm shadow-sky-400"></span>
              <h2 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-1.5">
                <span>Sign In to KrishiSetu Nexus</span>
              </h2>
            </div>
            <p className="text-xs text-sky-200 mt-0.5">
              Access certified agronomy, verified inputs, drone bookings & mandi pools
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Auth Status Strip if already signed in */}
        {isAuthenticated && (
          <div className="bg-blue-50/90 border-b border-blue-200/80 px-5 py-2.5 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
              <span className="text-blue-950">
                Currently signed in as: <strong className="font-bold text-slate-900">{currentUser.name}</strong> ({currentRole.toUpperCase()})
              </span>
            </div>
            <button
              onClick={() => {
                triggerHaptic('light');
                signOut();
                setStatusMsg({ type: 'success', text: 'You have signed out successfully' });
              }}
              className="px-2.5 py-1 text-[11px] font-bold text-red-700 bg-red-100/80 hover:bg-red-200 rounded-md transition-colors"
            >
              Sign Out
            </button>
          </div>
        )}

        {/* Tab Buttons */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-3 overflow-x-auto text-xs font-semibold">
          {[
            { id: 'otp', label: 'Mobile OTP', icon: Smartphone },
            { id: 'persona', label: '1-Click Persona', icon: Users },
            { id: 'password', label: 'Kisan ID / Pass', icon: KeyRound },
            { id: 'register', label: 'New Register', icon: UserPlus },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  triggerHaptic('light');
                  setActiveTab(tab.id as AuthTab);
                  setStatusMsg(null);
                }}
                className={`py-3 px-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-colors text-xs ${
                  isSelected
                    ? 'border-blue-600 text-blue-900 font-bold bg-white'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Feedback message banner */}
        {statusMsg && (
          <div
            className={`mx-5 mt-4 p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
              statusMsg.type === 'success'
                ? 'bg-blue-50 text-blue-950 border border-blue-300'
                : 'bg-rose-50 text-rose-950 border border-rose-300'
            }`}
          >
            {statusMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
            ) : (
              <Lock className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{statusMsg.text}</span>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* TAB 1: Mobile OTP */}
          {activeTab === 'otp' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-blue-50/60 rounded-xl border border-blue-200/70 text-slate-700">
                <span className="font-bold text-blue-950 block mb-0.5">Instant Mobile Login for Farmers & Dealers</span>
                <p className="text-[11px] text-slate-600">
                  Enter your registered 10-digit mobile number to receive a secure SMS OTP verification code.
                </p>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">Select Persona Role:</label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                  {(['farmer', 'officer', 'seller', 'fpo', 'admin'] as UserRole[]).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setSelectedOtpRole(r)}
                      className={`py-1.5 px-2 rounded-lg text-[11px] font-bold capitalize border text-center transition-all ${
                        selectedOtpRole === r
                          ? 'border-blue-600 bg-blue-50 text-blue-900 shadow-xs ring-1 ring-blue-500'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">Mobile Number (India +91):</label>
                <div className="flex gap-2">
                  <span className="px-3 py-2 bg-slate-100 border border-slate-300 rounded-xl font-mono font-bold text-slate-700 flex items-center">
                    +91
                  </span>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="e.g. 98452 11042"
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-mono text-slate-900 font-semibold"
                  />
                  {!otpSent && (
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      className="px-4 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 hover:from-blue-800 hover:to-sky-700 text-white font-bold rounded-xl shadow-md shadow-blue-950/20 whitespace-nowrap"
                    >
                      Get OTP
                    </button>
                  )}
                </div>
              </div>

              {otpSent && (
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">Enter 6-Digit OTP:</span>
                    <button
                      type="button"
                      onClick={() => setOtpCode('409210')}
                      className="text-[11px] font-bold text-blue-700 hover:underline flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3 text-sky-500" />
                      <span>Auto-fill Demo Code (409210)</span>
                    </button>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={6}
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      placeholder="409210"
                      className="flex-1 px-3 py-2 text-center text-base tracking-widest font-mono font-black border border-slate-300 rounded-xl outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-blue-900"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyOtp}
                      className="px-5 py-2 bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 hover:from-blue-800 hover:to-sky-700 text-white font-bold rounded-xl shadow-md shadow-blue-950/20 flex items-center gap-1.5"
                    >
                      <span>Verify & Enter</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                    <span>Didn't receive SMS?</span>
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      className="text-blue-700 font-bold hover:underline flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Resend OTP</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Quick 1-Click Persona Sign-In */}
          {activeTab === 'persona' && (
            <div className="space-y-3">
              <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200/70 text-slate-700">
                <span className="font-bold text-blue-950 block">Instant System Evaluation Personas</span>
                <p className="text-[11px] text-slate-600">
                  Quickly sign in as any of the 5 official platform stakeholders to test customized dashboards and workflows.
                </p>
              </div>

              <div className="space-y-2">
                {[
                  {
                    id: 'farmer' as UserRole,
                    name: 'Ramesh Patel',
                    roleDesc: 'Smallholder Farmer (1-Acre Tomato Pilot)',
                    details: 'Kolar Blossom FPO Member #409 • Arka Rakshak Hybrid',
                    badge: 'Farmer Portal',
                    color: 'border-blue-300 hover:border-blue-500 bg-white',
                  },
                  {
                    id: 'officer' as UserRole,
                    name: 'Dr. Anita Rao',
                    roleDesc: 'Senior Agronomist / Agriculture Officer',
                    details: 'ICAR UHS Horticultural University • Escalation Queue',
                    badge: 'Expert Review',
                    color: 'border-sky-300 hover:border-sky-500 bg-white',
                  },
                  {
                    id: 'seller' as UserRole,
                    name: 'KisanSeva Agrochemicals & SkySpray',
                    roleDesc: 'Verified Agri-Dealer & Certified Drone Pilot',
                    details: 'DGCA Certified Fleet • CIB&RC Batch Inventory',
                    badge: 'Dealer / Drone',
                    color: 'border-amber-300 hover:border-amber-500 bg-white',
                  },
                  {
                    id: 'fpo' as UserRole,
                    name: 'Suresh Deshmukh',
                    roleDesc: 'FPO General Manager (Kolar Blossom FPO)',
                    details: '480 Enrolled Acres • Collective Procurement & Bulking',
                    badge: 'FPO Collective',
                    color: 'border-indigo-300 hover:border-indigo-500 bg-white',
                  },
                  {
                    id: 'admin' as UserRole,
                    name: 'Vikram Joshi',
                    roleDesc: 'Nexus System Administrator & Trust Guardian',
                    details: 'Cryptographic Audit Trail • Governance & Model Registry',
                    badge: 'System Admin',
                    color: 'border-slate-300 hover:border-slate-500 bg-white',
                  },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handlePersonaSelect(item.id)}
                    className={`w-full p-3 rounded-xl border text-left transition-all hover:shadow-md flex items-center justify-between group ${item.color}`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs">{item.name}</span>
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-900">
                          {item.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5">{item.roleDesc}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">{item.details}</p>
                    </div>
                    <span className="px-3 py-1.5 bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 text-white font-bold text-[11px] rounded-lg shadow-xs group-hover:scale-105 transition-transform shrink-0">
                      Sign In &rarr;
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: Kisan ID / Email & Password */}
          {activeTab === 'password' && (
            <form onSubmit={handlePasswordSignIn} className="space-y-3">
              <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200/70 text-slate-700">
                <span className="font-bold text-blue-950 block">PM-KISAN ID / KCC / Email Sign-In</span>
                <p className="text-[11px] text-slate-600">
                  Government-integrated login using your Kisan Credit Card number or registered email.
                </p>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">
                  Kisan ID / Registration Number / Email:
                </label>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="e.g. KA-KLR-KISAN-409 or ramesh.patel@kisan.gov.in"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-mono text-slate-900 font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">Password / Security PIN:</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full px-3 py-2 pr-10 border border-slate-300 rounded-xl outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900 font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="checkbox" defaultChecked className="accent-blue-600 rounded" />
                  <span>Remember device for 30 days</span>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setIdentifier('KA-KLR-KISAN-409');
                    setPassword('NexusPass@2026');
                    setStatusMsg({ type: 'success', text: 'Pre-filled demo credentials for farmer login.' });
                  }}
                  className="text-blue-700 font-semibold hover:underline"
                >
                  Forgot / Reset PIN
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 hover:from-blue-800 hover:to-sky-700 text-white font-bold rounded-xl shadow-md shadow-blue-950/20 text-xs flex items-center justify-center gap-2 mt-2"
              >
                <span>Authorize & Sign In</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}

          {/* TAB 4: New Registration / Sign Up */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-3">
              <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200/70 text-slate-700">
                <span className="font-bold text-blue-950 block">Register New Farmer / Stakeholder Account</span>
                <p className="text-[11px] text-slate-600">
                  Create your profile to start tracking soil health, disease diagnostics, and FPO group discounts.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Full Name (पूरा नाम):</label>
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="e.g. Suresh Gowda"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium text-slate-900"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Mobile (मोबाइल नंबर):</label>
                  <input
                    type="tel"
                    required
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="e.g. 98451 99882"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-medium text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Role:</label>
                  <select
                    value={regRole}
                    onChange={(e) => setRegRole(e.target.value as UserRole)}
                    className="w-full px-2.5 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-600 font-medium text-slate-900"
                  >
                    <option value="farmer">Farmer (किसान)</option>
                    <option value="officer">Agronomist / Officer</option>
                    <option value="seller">Agri-Seller / Drone</option>
                    <option value="fpo">FPO Manager</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">District:</label>
                  <input
                    type="text"
                    value={regDistrict}
                    onChange={(e) => setRegDistrict(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-600 font-medium text-slate-900"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Primary Crop:</label>
                  <input
                    type="text"
                    value={regCrop}
                    onChange={(e) => setRegCrop(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-600 font-medium text-slate-900"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 hover:from-blue-800 hover:to-sky-700 text-white font-bold rounded-xl shadow-md shadow-blue-950/20 text-xs flex items-center justify-center gap-2 mt-2"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Create Account & Sign In</span>
              </button>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1">
            <Lock className="w-3 h-3 text-slate-400" />
            <span>256-bit encrypted authentication & tamper-evident audit trail</span>
          </span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold rounded-lg text-xs"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
