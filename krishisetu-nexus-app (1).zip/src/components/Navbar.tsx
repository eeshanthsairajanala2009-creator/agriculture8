import React, { useState } from 'react';
import { useApp, ScreenId } from '../context/AppContext';
import { UserRole } from '../types';
import { triggerHaptic } from '../utils/haptics';
import {
  Sprout,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
  UserCheck,
  Menu,
  X,
  ShieldCheck,
  FileText,
  Sparkles,
  Layers,
  LogIn,
  LogOut,
  User as UserIcon,
} from 'lucide-react';

interface NavbarProps {
  onOpenDocs: () => void;
  onOpenScreenPicker: () => void;
  onToggleSidebar?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenDocs, onOpenScreenPicker, onToggleSidebar }) => {
  const {
    currentRole,
    switchRole,
    currentUser,
    isAuthenticated,
    setIsSignInModalOpen,
    signOut,
    t,
    language,
    setLanguage,
    sunlightMode,
    setSunlightMode,
    isOffline,
    setIsOffline,
    triggerOfflineSync,
    isSpeaking,
    stopSpeech,
    activeScreen,
    setActiveScreen,
  } = useApp();

  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const roles: { id: UserRole; label: string; badge: string; color: string }[] = [
    { id: 'farmer', label: 'Farmer (Ramesh Patel)', badge: '1-Acre Tomato', color: 'bg-blue-700' },
    { id: 'officer', label: 'Agronomist / Officer (Dr. Anita Rao)', badge: 'ICAR UHS', color: 'bg-sky-600' },
    { id: 'seller', label: 'Agri Seller & Drone Pilot', badge: 'DGCA Certified', color: 'bg-amber-600' },
    { id: 'fpo', label: 'FPO Manager (Suresh Deshmukh)', badge: 'Kolar Blossom FPO', color: 'bg-indigo-600' },
    { id: 'admin', label: 'System Admin (Vikram Joshi)', badge: 'Platform Trust', color: 'bg-slate-700' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top emergency warning bar if spray is unsafe */}
      {activeScreen !== 'weather' && (
        <div
          onClick={() => setActiveScreen('weather')}
          className="bg-amber-500 hover:bg-amber-600 text-slate-950 px-3 py-1 text-xs font-semibold flex items-center justify-between cursor-pointer transition-colors"
        >
          <div className="flex items-center gap-1.5 truncate">
            <span className="animate-pulse flex h-2 w-2 rounded-full bg-red-600"></span>
            <span className="font-bold">WEATHER ALERT:</span>
            <span className="truncate">85% Rain in 12h — Hold foliar chemical sprays to prevent ₹800+ loss!</span>
          </div>
          <span className="underline ml-2 shrink-0">View Advisory &rarr;</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-2">
        {/* Sidebar Toggle & Logo */}
        <div className="flex items-center gap-2">
          {onToggleSidebar && (
            <button
              onClick={() => {
                triggerHaptic('light');
                onToggleSidebar();
              }}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors border border-slate-300 flex items-center justify-center shadow-xs"
              title="Toggle Left Navigation Menu"
            >
              <Menu className="w-4 h-4 text-slate-800" />
            </button>
          )}

          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setActiveScreen('dashboard')}>
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-950 via-blue-700 to-sky-400 flex items-center justify-center text-white shadow-md shadow-blue-900/25 ring-1 ring-blue-400/30">
              <Sprout className="w-5 h-5 text-sky-200" />
            </div>
            <div className="leading-tight">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base tracking-tight text-slate-900">KrishiSetu</span>
                <span className="text-xs px-1.5 py-0.5 rounded-sm bg-blue-100 text-blue-900 font-extrabold uppercase tracking-wider border border-blue-200">
                  Nexus
                </span>
              </div>
              <p className="text-[10px] text-slate-500 hidden sm:block">From farmer question to verified farm action</p>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick Voice Stop if speaking */}
          {isSpeaking && (
            <button
              onClick={stopSpeech}
              className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-red-100 text-red-700 animate-pulse font-semibold"
              title="Stop audio readout"
            >
              <VolumeX className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Mute Voice</span>
            </button>
          )}

          {/* Sunlight Mode Toggle */}
          <button
            onClick={() => {
              triggerHaptic('light');
              setSunlightMode((prev) => !prev);
            }}
            className={`p-1.5 sm:px-2.5 sm:py-1 rounded-lg text-xs font-medium border flex items-center gap-1 transition-all ${
              sunlightMode
                ? 'bg-amber-100 text-amber-900 border-amber-300'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            title="Outdoor high-contrast sunlight mode"
          >
            {sunlightMode ? <Sun className="w-4 h-4 text-amber-600" /> : <Moon className="w-4 h-4 text-slate-500" />}
            <span className="hidden md:inline">{sunlightMode ? 'Sunlight High Contrast' : 'Standard View'}</span>
          </button>

          {/* Offline Simulator */}
          <button
            onClick={() => {
              triggerHaptic('medium');
              if (isOffline) triggerOfflineSync();
              else setIsOffline(true);
            }}
            className={`p-1.5 sm:px-2.5 sm:py-1 rounded-lg text-xs font-medium border flex items-center gap-1 transition-all ${
              isOffline
                ? 'bg-orange-100 text-orange-900 border-orange-300 animate-pulse'
                : 'bg-blue-50 text-blue-900 border-blue-200 hover:bg-blue-100'
            }`}
            title="Toggle offline simulated mode"
          >
            {isOffline ? <WifiOff className="w-3.5 h-3.5 text-orange-600" /> : <Wifi className="w-3.5 h-3.5 text-blue-600" />}
            <span className="hidden sm:inline">{isOffline ? 'Offline (Sync)' : 'Online (Sync Live)'}</span>
          </button>

          {/* Top-Level Language Toggle (English / Hindi / Telugu) */}
          <div
            role="group"
            aria-label="Select Application Language"
            className="flex rounded-lg border border-slate-200 overflow-hidden text-xs font-semibold bg-slate-50 shadow-xs"
          >
            <button
              onClick={() => {
                triggerHaptic('light');
                setLanguage('en');
              }}
              className={`px-2 py-1 transition-all flex items-center gap-1 ${
                language === 'en'
                  ? 'bg-gradient-to-r from-blue-900 via-blue-700 to-blue-800 text-white font-bold shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
              title="Switch to English"
            >
              <span>EN</span>
            </button>
            <button
              onClick={() => {
                triggerHaptic('light');
                setLanguage('hi');
              }}
              className={`px-2 py-1 transition-all flex items-center gap-1 ${
                language === 'hi'
                  ? 'bg-gradient-to-r from-blue-900 via-blue-700 to-blue-800 text-white font-bold shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
              title="हिंदी में बदलें (Hindi)"
            >
              <span>हिंदी</span>
            </button>
            <button
              onClick={() => {
                triggerHaptic('light');
                setLanguage('te');
              }}
              className={`px-2 py-1 transition-all flex items-center gap-1 ${
                language === 'te'
                  ? 'bg-gradient-to-r from-blue-900 via-blue-700 to-blue-800 text-white font-bold shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
              title="తెలుగులోకి మార్చండి (Telugu)"
            >
              <span>తెలుగు</span>
            </button>
          </div>

          {/* Sign In & User Account Control */}
          {isAuthenticated ? (
            <div className="relative">
              <button
                onClick={() => {
                  triggerHaptic('light');
                  setUserMenuOpen(!userMenuOpen);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-slate-950 via-blue-950 to-blue-900 text-white border border-blue-500/30 hover:border-blue-400 text-xs font-semibold shadow-sm transition-all"
                title="User Account & Session"
              >
                <div className="w-4 h-4 rounded-full bg-blue-700 flex items-center justify-center text-[10px] font-bold text-sky-200">
                  {currentUser.name.charAt(0)}
                </div>
                <span className="hidden md:inline font-bold text-slate-100 max-w-[110px] truncate">
                  {currentUser.name}
                </span>
                <span className="text-[10px] font-mono px-1 rounded bg-blue-500/20 text-sky-300 hidden sm:inline capitalize">
                  {currentRole}
                </span>
                <span className="text-[10px] text-slate-400">&blacktriangledown;</span>
              </button>

              {userMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-2xl border border-slate-200 py-2.5 z-50 animate-in fade-in zoom-in-95 duration-100"
                  onClick={() => setUserMenuOpen(false)}
                >
                  <div className="px-3.5 py-2 border-b border-slate-100 mb-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-blue-700 tracking-wider">
                        Authenticated User
                      </span>
                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-900 uppercase">
                        {currentRole}
                      </span>
                    </div>
                    <p className="text-sm font-black text-slate-900 mt-0.5">{currentUser.name}</p>
                    <p className="text-[11px] text-slate-500 font-mono">{currentUser.phone}</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      {currentUser.district}, {currentUser.state} {currentUser.fpoAffiliation ? `• ${currentUser.fpoAffiliation}` : ''}
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      triggerHaptic('light');
                      setActiveScreen('profile');
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs flex items-center gap-2 text-slate-700 hover:bg-slate-50 transition-colors font-medium"
                  >
                    <UserIcon className="w-3.5 h-3.5 text-blue-600" />
                    <span>View Profile & Land Holdings</span>
                  </button>

                  <button
                    onClick={() => {
                      triggerHaptic('light');
                      setIsSignInModalOpen(true);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs flex items-center gap-2 text-slate-700 hover:bg-slate-50 transition-colors font-medium"
                  >
                    <LogIn className="w-3.5 h-3.5 text-sky-600" />
                    <span>Switch User / Sign In as Another User</span>
                  </button>

                  <div className="pt-1.5 mt-1 border-t border-slate-100 px-1">
                    <button
                      onClick={() => {
                        triggerHaptic('medium');
                        signOut();
                      }}
                      className="w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors font-bold"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>{t.signOut || 'Sign Out'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => {
                triggerHaptic('light');
                setIsSignInModalOpen(true);
              }}
              className="px-3 sm:px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 hover:from-blue-800 hover:to-sky-700 text-white font-extrabold text-xs shadow-md shadow-blue-950/25 flex items-center gap-1.5 transition-all hover:scale-[1.02]"
              title="Sign In with Mobile OTP or Kisan ID"
            >
              <LogIn className="w-3.5 h-3.5 text-sky-200" />
              <span>{t.signIn || 'Sign In'}</span>
            </button>
          )}

          {/* Role Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                triggerHaptic('light');
                setRoleMenuOpen(!roleMenuOpen);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold shadow-xs transition-colors"
            >
              <UserCheck className="w-3.5 h-3.5 text-sky-400" />
              <span className="capitalize">{currentRole}</span>
              <span className="text-[10px] text-slate-400">&blacktriangledown;</span>
            </button>

            {roleMenuOpen && (
              <div
                className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-100"
                onClick={() => setRoleMenuOpen(false)}
              >
                <div className="px-3 py-1.5 border-b border-slate-100 mb-1">
                  <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Switch System Persona</p>
                  <p className="text-xs text-slate-600">Simulate role-specific dashboards & workflows</p>
                </div>
                {roles.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => {
                      triggerHaptic('medium');
                      switchRole(r.id);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors ${
                      currentRole === r.id ? 'bg-blue-50/90 font-bold text-blue-950' : 'text-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${r.color}`}></span>
                        <span>{r.label}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 ml-4">{r.badge}</span>
                    </div>
                    {currentRole === r.id && <span className="text-blue-600 text-xs font-extrabold">&check;</span>}
                  </button>
                ))}

                <div className="border-t border-slate-100 mt-1 pt-1 px-1">
                  <button
                    onClick={() => {
                      triggerHaptic('light');
                      setIsSignInModalOpen(true);
                    }}
                    className="w-full text-left px-2.5 py-1.5 text-xs text-blue-700 hover:bg-blue-50 font-bold rounded-lg flex items-center gap-1.5"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Open Sign-In / Register Modal &rarr;</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* System Deliverables & 30-Screen Navigator */}
          <button
            onClick={onOpenScreenPicker}
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg bg-blue-50 text-blue-900 border border-blue-200 hover:bg-blue-100 text-xs font-semibold flex items-center gap-1"
            title="30 Screens Directory"
          >
            <Layers className="w-4 h-4 text-blue-600" />
            <span className="hidden sm:inline">All 30 Screens</span>
          </button>

          <button
            onClick={onOpenDocs}
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg bg-slate-100 text-slate-800 hover:bg-slate-200 border border-slate-300 text-xs font-semibold flex items-center gap-1"
            title="System Architecture, Safety Checklist & Evaluation Report"
          >
            <FileText className="w-4 h-4 text-blue-600" />
            <span className="hidden md:inline">Docs & Safety</span>
          </button>
        </div>
      </div>
    </header>
  );
};
