import React from 'react';
import { useApp, ScreenId } from '../context/AppContext';
import { triggerHaptic } from '../utils/haptics';
import {
  X,
  Languages,
  UserCheck,
  MapPin,
  LayoutDashboard,
  MessageSquare,
  Camera,
  Mic,
  Stethoscope,
  CloudSun,
  Droplets,
  Scale,
  ShoppingBag,
  FileSearch,
  QrCode,
  ShoppingCart,
  FileSpreadsheet,
  FlaskConical,
  Wrench,
  Plane,
  Calculator,
  TrendingUp,
  Landmark,
  Map,
  Package,
  CalendarCheck,
  CheckCircle,
  ShieldAlert,
  Users,
  Store,
  Lock,
} from 'lucide-react';

interface ScreenPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ScreenPickerModal: React.FC<ScreenPickerModalProps> = ({ isOpen, onClose }) => {
  const { activeScreen, setActiveScreen } = useApp();

  if (!isOpen) return null;

  const screenList: {
    id: ScreenId;
    num: number;
    title: string;
    category: string;
    icon: React.ElementType;
    desc: string;
  }[] = [
    { id: 'welcome', num: 1, title: 'Welcome & Language Selection', category: 'Onboarding', icon: Languages, desc: 'Bilingual Hindi/English entry portal' },
    { id: 'consent', num: 2, title: 'Farmer Registration & Consent', category: 'Onboarding', icon: UserCheck, desc: 'Privacy-first permissions & face blurring' },
    { id: 'profile', num: 3, title: 'Farm & Crop Profile', category: 'Farm Setup', icon: MapPin, desc: '1-acre tomato plot, soil type, irrigation' },
    { id: 'dashboard', num: 4, title: 'Crop & Livestock Dashboard', category: 'Core Hub', icon: LayoutDashboard, desc: 'Real-time farm health, alerts & herd status' },
    { id: 'ask', num: 5, title: 'Ask the AI Assistant', category: 'Intake Agent', icon: MessageSquare, desc: 'Voice, text, document & sensor inputs' },
    { id: 'camera', num: 6, title: 'Camera & Image Upload', category: 'Crop Doctor', icon: Camera, desc: 'Tomato leaf disease scanner & sample picker' },
    { id: 'voice', num: 7, title: 'Voice Recording Screen', category: 'Voice Agent', icon: Mic, desc: 'Hindi/English speech recognition & audio reply' },
    { id: 'diagnosis', num: 8, title: 'AI Diagnosis Results', category: 'Crop Doctor', icon: Stethoscope, desc: 'Early Blight bullseye evidence, 86% confidence' },
    { id: 'weather', num: 9, title: 'Weather & Spray Window', category: 'Weather Agent', icon: CloudSun, desc: 'Rain hold warning, wind speed & spray safety' },
    { id: 'irrigation', num: 10, title: 'Irrigation Recommendation', category: 'Weather Agent', icon: Droplets, desc: 'Drip scheduling & soil moisture balance' },
    { id: 'treatment', num: 11, title: 'Treatment Comparison', category: 'Treatment Agent', icon: Scale, desc: 'Chemical vs Bio-Trichoderma vs Leaf Pruning' },
    { id: 'products', num: 12, title: 'Product Marketplace', category: 'Marketplace', icon: ShoppingBag, desc: 'Verified inputs & blocked expired chemicals' },
    { id: 'product_details', num: 13, title: 'Product Details & CIB Label', category: 'Marketplace', icon: FileSearch, desc: 'Official government leaflet, PPE, waiting period' },
    { id: 'authenticity', num: 14, title: 'Product Authenticity Scanner', category: 'Trust & Safety', icon: QrCode, desc: 'QR code batch verify & anti-counterfeit detection' },
    { id: 'cart', num: 15, title: 'Cart & Transparent Checkout', category: 'Commerce', icon: ShoppingCart, desc: 'Itemized fee breakdown, FPO discount & simulated UPI' },
    { id: 'soil', num: 16, title: 'Soil Report & Document Viewer', category: 'Soil & RAG', icon: FileSpreadsheet, desc: 'ICAR soil card OCR, pH 6.1, low nitrogen' },
    { id: 'soil_labs', num: 17, title: 'Soil-Testing Laboratory Search', category: 'Soil Services', icon: FlaskConical, desc: 'Nearby NABL labs in Kolar, pricing & pickup' },
    { id: 'services', num: 18, title: 'Agricultural Service Marketplace', category: 'Services', icon: Wrench, desc: 'Drone spray, tractor rotavator, agronomists' },
    { id: 'machinery', num: 19, title: 'Machinery & Drone Spray Booking', category: 'Services', icon: Plane, desc: 'Garuda Kisan drone reservation with pilot' },
    { id: 'sustainability', num: 20, title: 'Cost & Sustainability Analysis', category: 'Finance & Eco', icon: Calculator, desc: 'Multi-scenario ROI, chemical reduction scorecard' },
    { id: 'mandi', num: 21, title: 'Mandi Prices & Selling Options', category: 'Market Agent', icon: TrendingUp, desc: 'Kolar & Azadpur tomato APMC prices & trends' },
    { id: 'schemes', num: 22, title: 'Government Schemes & PMFBY', category: 'Govt Schemes', icon: Landmark, desc: 'Crop insurance, SMAM drone subsidy eligibility' },
    { id: 'pest_map', num: 23, title: 'Pest Hotspot Surveillance Map', category: 'Surveillance', icon: Map, desc: 'District fungal cluster alert & spread warnings' },
    { id: 'orders', num: 24, title: 'Orders & Booking Tracking', category: 'Commerce', icon: Package, desc: 'Milestones, dispatch status & delivery OTP' },
    { id: 'tasks', num: 25, title: 'Farm Tasks & Offline Reminders', category: 'Operations', icon: CalendarCheck, desc: 'Field calendar, weather holds & offline sync' },
    { id: 'verification', num: 26, title: 'Before & After Verification', category: 'Verification', icon: CheckCircle, desc: 'Re-scan leaf comparison: 74% visual recovery' },
    { id: 'officer_escalation', num: 27, title: 'Agriculture Officer Escalation', category: 'Expert Review', icon: ShieldAlert, desc: 'Agronomist queue, review high-risk prescriptions' },
    { id: 'fpo_dashboard', num: 28, title: 'Cooperative / FPO Dashboard', category: 'FPO Hub', icon: Users, desc: 'Kolar Blossom FPO bulk buying & shared fleet' },
    { id: 'seller_dashboard', num: 29, title: 'Seller & Provider Dashboard', category: 'Seller Hub', icon: Store, desc: 'Batch inventory, expiry tracking & fulfillment' },
    { id: 'audit', num: 30, title: 'Privacy, Consent & Audit Log', category: 'Governance', icon: Lock, desc: 'Tamper-evident logs, data deletion & citations' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shadow-sm shadow-blue-500"></span>
              All 30 Application Modules & Screens
            </h2>
            <p className="text-xs text-slate-500">
              Direct access to all 30 screens required in the KrishiSetu Nexus specifications
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Screen Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {screenList.map((sc) => {
            const Icon = sc.icon;
            const isCurrent = activeScreen === sc.id;
            return (
              <button
                key={sc.id}
                onClick={() => {
                  triggerHaptic('light');
                  setActiveScreen(sc.id);
                  onClose();
                }}
                className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                  isCurrent
                    ? 'border-blue-600 bg-blue-50/80 ring-2 ring-blue-500/20 shadow-md shadow-blue-950/5'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-md bg-gradient-to-tr from-slate-950 to-blue-900 text-white text-[10px] font-extrabold flex items-center justify-center">
                      {sc.num}
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900 bg-blue-100/80 px-1.5 py-0.5 rounded border border-blue-200/50">
                      {sc.category}
                    </span>
                  </div>
                  <Icon className={`w-4 h-4 ${isCurrent ? 'text-blue-700' : 'text-slate-400'}`} />
                </div>
                <h3 className="text-xs font-bold text-slate-900 line-clamp-1">{sc.title}</h3>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{sc.desc}</p>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Click any card to inspect the module immediately.</span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 text-xs"
          >
            Close Directory
          </button>
        </div>
      </div>
    </div>
  );
};
