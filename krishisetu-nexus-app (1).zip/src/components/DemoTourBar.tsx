import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { triggerHaptic } from '../utils/haptics';
import { Play, ChevronRight, ChevronLeft, Sparkles, CheckCircle2 } from 'lucide-react';

export const DemoTourBar: React.FC = () => {
  const { demoStep, runDemoStep } = useApp();
  const [collapsed, setCollapsed] = useState(false);

  const steps = [
    { id: 1, title: '1. Voice & Intake', desc: 'Farmer asks: "Can I spray today? Rain expected tomorrow"' },
    { id: 2, title: '2. Crop Doctor', desc: 'Analyzes leaf spots -> Early Blight (86% confidence)' },
    { id: 3, title: '3. Weather Delay', desc: '85% Rain alert within 12h -> Delay chemical spray' },
    { id: 4, title: '4. Compare Treatments', desc: 'Chemical vs Bio-Trichoderma vs Manual Leaf Pruning' },
    { id: 5, title: '5. Marketplace & Safety', desc: 'Verified products & Trust Agent BLOCKS expired chemical' },
    { id: 6, title: '6. Drone & Lab Services', desc: 'Book Precision Drone Spraying & Kolar Soil Test' },
    { id: 7, title: '7. Field Tasks', desc: 'Weather-dependent hold & offline task sync' },
    { id: 8, title: '8. Re-Scan & Verify', desc: 'Follow-up leaf re-scan -> 74% visual recovery verified' },
    { id: 9, title: '9. Agronomist Escalation', desc: 'Dr. Anita Rao reviews & approves treatment plan' },
    { id: 10, title: '10. FPO Collective Hub', desc: 'Cooperative bulk buying & shared drone pool' },
    { id: 11, title: '11. Audit & Safety', desc: 'Immutable audit logs, data minimization & CIB citations' },
  ];

  if (collapsed) {
    return (
      <div className="bg-gradient-to-r from-slate-950 via-blue-950 to-blue-900 text-white px-3 py-1.5 flex items-center justify-between text-xs shadow-inner border-b border-blue-900/40">
        <div className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-sky-300" />
          <span className="font-bold">5-Minute Seed Scenario Walkthrough</span>
          <span className="text-sky-300 hidden sm:inline">(1-Acre Tomato Farm Early Blight Demo)</span>
        </div>
        <button
          onClick={() => setCollapsed(false)}
          className="bg-blue-800 hover:bg-blue-700 px-2 py-0.5 rounded text-[11px] font-semibold flex items-center gap-1 border border-blue-600/40"
        >
          <span>Expand Steps</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    );
  }

  const currentStepObj = steps.find((s) => s.id === demoStep) || steps[0];

  return (
    <aside aria-label="Demo Walkthrough Guide" className="bg-slate-900 text-white border-b border-slate-800 px-3 sm:px-6 py-2 shadow-md">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-amber-400 text-slate-950">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                Interactive 5-Min Scenario Tour
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">
                Step {demoStep || 1} of {steps.length}
              </span>
            </div>
            <p className="text-xs font-medium text-slate-200">
              <span className="text-sky-400 font-bold">{currentStepObj.title}:</span> {currentStepObj.desc}
            </p>
          </div>
        </div>

        {/* Step Navigation Controls */}
        <div className="flex items-center gap-1.5 w-full md:w-auto justify-between md:justify-end overflow-x-auto pb-1 md:pb-0">
          <button
            disabled={demoStep <= 1}
            onClick={() => {
              triggerHaptic('light');
              runDemoStep(Math.max(1, demoStep - 1));
            }}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 rounded text-xs flex items-center gap-1"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Prev</span>
          </button>

          {/* Quick Step Buttons */}
          <div className="flex items-center gap-1">
            {steps.map((st) => (
              <button
                key={st.id}
                onClick={() => {
                  triggerHaptic('light');
                  runDemoStep(st.id);
                }}
                className={`w-6 h-6 rounded-full text-[11px] font-bold flex items-center justify-center transition-all ${
                  demoStep === st.id
                    ? 'bg-amber-400 text-slate-950 scale-110 shadow-xs'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
                title={st.title}
              >
                {st.id}
              </button>
            ))}
          </div>

          <button
            disabled={demoStep >= steps.length}
            onClick={() => {
              triggerHaptic('medium');
              runDemoStep(demoStep ? demoStep + 1 : 2);
            }}
            className="px-2.5 py-1 bg-gradient-to-r from-blue-700 via-blue-600 to-sky-600 hover:from-blue-600 hover:to-sky-500 rounded text-xs font-bold flex items-center gap-1 text-white shadow-md shadow-blue-950/40"
          >
            <span>Next Step</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setCollapsed(true)}
            className="text-[10px] text-slate-400 hover:text-white underline ml-1"
          >
            Hide
          </button>
        </div>
      </div>
    </aside>
  );
};
