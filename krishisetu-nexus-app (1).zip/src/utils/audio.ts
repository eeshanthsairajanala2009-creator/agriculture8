/**
 * Voice synthesis and recognition utilities for low-literacy farmers
 */

export function speakText(
  text: string,
  lang: 'en' | 'hi' | 'te' = 'en',
  onEnd?: () => void,
  rate: number = 0.9 // Slightly slower for low-literacy clarity
): SpeechSynthesisUtterance | null {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    console.warn('Speech synthesis not supported on this browser.');
    return null;
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = lang === 'te' ? 'te-IN' : lang === 'hi' ? 'hi-IN' : 'en-IN';
  utterance.rate = rate;
  utterance.pitch = 1.0;

  // Try finding native voice for dialect if available
  const voices = window.speechSynthesis.getVoices();
  const targetVoice = voices.find((v) =>
    lang === 'te'
      ? v.lang.startsWith('te')
      : lang === 'hi'
      ? v.lang.startsWith('hi')
      : v.lang.startsWith('en-IN') || v.lang.startsWith('en')
  );
  if (targetVoice) {
    utterance.voice = targetVoice;
  }

  if (onEnd) {
    utterance.onend = onEnd;
    utterance.onerror = onEnd;
  }

  window.speechSynthesis.speak(utterance);
  return utterance;
}

export function stopSpeaking(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function isSpeechSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}
