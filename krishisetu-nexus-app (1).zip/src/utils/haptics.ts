/**
 * Haptic tactile feedback utility using Navigator.vibrate API
 * Provides tactile confirmation for mobile farmers and low-literacy users.
 */

export type HapticFeedbackType =
  | 'light'
  | 'medium'
  | 'heavy'
  | 'success'
  | 'warning'
  | 'error'
  | 'recording'
  | 'submit'
  | 'order';

export function triggerHaptic(type: HapticFeedbackType = 'light'): boolean {
  if (
    typeof window === 'undefined' ||
    !('navigator' in window) ||
    typeof window.navigator.vibrate !== 'function'
  ) {
    return false;
  }

  try {
    switch (type) {
      case 'light':
        // Short subtle tap for general button clicks and navigation
        return window.navigator.vibrate(25);

      case 'medium':
        // Standard interactive button press
        return window.navigator.vibrate(45);

      case 'heavy':
        // High impact action
        return window.navigator.vibrate(75);

      case 'recording':
        // Dual pulse indicating microphone recording started/stopped
        return window.navigator.vibrate([60, 40, 60]);

      case 'submit':
        // Form / prompt submission confirmation
        return window.navigator.vibrate([40, 40, 60]);

      case 'order':
      case 'success':
        // Success celebration pattern for confirmed order or verified action
        return window.navigator.vibrate([50, 40, 70, 40, 100]);

      case 'warning':
        // Weather hold / safety alert vibration
        return window.navigator.vibrate([70, 50, 70]);

      case 'error':
        // Blocked product / counterfeit alert
        return window.navigator.vibrate([100, 50, 100, 50, 120]);

      default:
        return window.navigator.vibrate(30);
    }
  } catch (err) {
    console.debug('Navigator.vibrate was blocked or not permitted:', err);
    return false;
  }
}
