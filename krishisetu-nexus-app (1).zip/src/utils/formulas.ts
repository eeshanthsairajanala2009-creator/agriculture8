import { PriorityFormulaWeights, ProductCompatibilityWeights, Product, WeatherSnapshot } from '../types';

export interface PriorityBreakdown {
  cropLossRiskScore: number;
  treatmentUrgencyScore: number;
  affectedAcresScore: number;
  farmerVulnerabilityScore: number;
  weatherSensitivityScore: number;
  spreadRiskScore: number;
  availabilityScore: number;
  sustainabilityScore: number;
  finalPriorityScore: number;
  priorityCategory: 'Low' | 'Medium' | 'High' | 'Critical';
}

export function calculatePriorityScore(
  inputs: {
    cropLossRisk: number; // 0-100
    treatmentUrgency: number; // 0-100
    affectedAcres: number; // e.g. 1.0 acre -> normalized 0-100
    farmerVulnerability: number; // 0-100 (smallholder marginal farmer = 80)
    weatherSensitivity: number; // 0-100 (rain within 12h = 95)
    spreadRisk: number; // 0-100 (spores in wind = 85)
    availability: number; // 0-100
    sustainability: number; // 0-100
  },
  weights: PriorityFormulaWeights
): PriorityBreakdown {
  const normAcres = Math.min(100, inputs.affectedAcres * 50);

  const weightedSum =
    weights.cropLossRisk * inputs.cropLossRisk +
    weights.treatmentUrgency * inputs.treatmentUrgency +
    weights.affectedAcres * normAcres +
    weights.farmerVulnerability * inputs.farmerVulnerability +
    weights.weatherSensitivity * inputs.weatherSensitivity +
    weights.spreadRisk * inputs.spreadRisk +
    weights.availability * inputs.availability +
    weights.sustainability * inputs.sustainability;

  const totalWeight = Object.values(weights).reduce((a, b) => a + b, 0);
  const normalizedFinal = Math.round(weightedSum / (totalWeight || 1));

  let category: 'Low' | 'Medium' | 'High' | 'Critical' = 'Medium';
  if (normalizedFinal >= 80) category = 'Critical';
  else if (normalizedFinal >= 65) category = 'High';
  else if (normalizedFinal < 40) category = 'Low';

  return {
    cropLossRiskScore: inputs.cropLossRisk,
    treatmentUrgencyScore: inputs.treatmentUrgency,
    affectedAcresScore: normAcres,
    farmerVulnerabilityScore: inputs.farmerVulnerability,
    weatherSensitivityScore: inputs.weatherSensitivity,
    spreadRiskScore: inputs.spreadRisk,
    availabilityScore: inputs.availability,
    sustainabilityScore: inputs.sustainability,
    finalPriorityScore: normalizedFinal,
    priorityCategory: category,
  };
}

export interface CompatibilityBreakdown {
  cropMatchScore: number;
  problemMatchScore: number;
  labelCompletenessScore: number;
  weatherSuitabilityScore: number;
  sellerVerificationScore: number;
  affordabilityScore: number;
  sustainabilityScore: number;
  finalScore: number;
  isSafetyBlocked: boolean;
  safetyBlockReasons: string[];
}

export function calculateProductCompatibility(
  product: Product,
  cropName: string,
  problemName: string,
  weather: WeatherSnapshot,
  weights: ProductCompatibilityWeights
): CompatibilityBreakdown {
  const safetyBlockReasons: string[] = [];

  // Check safety block criteria
  if (product.batch.isExpired) {
    safetyBlockReasons.push('Product batch has expired.');
  }
  if (!product.sellerVerified) {
    safetyBlockReasons.push('Seller is unverified on Nexus registry.');
  }
  if (!product.label.officialCIBRegistrationNumber || product.label.officialCIBRegistrationNumber.includes('BANNED')) {
    safetyBlockReasons.push('Missing or invalid government CIB&RC registration.');
  }
  if (product.isBlockedByTrustAgent) {
    safetyBlockReasons.push(product.blockReason || 'Blocked by Trust & Safety Guardian.');
  }

  const isCropMatch = product.label.targetCrops.some((c) =>
    c.toLowerCase().includes(cropName.toLowerCase())
  );
  if (!isCropMatch) {
    safetyBlockReasons.push(`Label does not authorize application on ${cropName}.`);
  }

  const cropMatchScore = isCropMatch ? 100 : 0;
  const problemMatchScore = product.label.targetPests.some((p) =>
    p.toLowerCase().includes(problemName.toLowerCase())
  )
    ? 100
    : 10;

  const labelCompletenessScore = product.label.harvestIntervalDays !== undefined && product.label.requiredPPE.length > 0 ? 100 : 40;

  // Weather suitability: if rain is expected within 12h, chemical spray is unsuitable (10), while bio-drench or waiting is better (70)
  const weatherSuitabilityScore = weather.precipitationChanceNext12h > 70
    ? product.category === 'bio_control' ? 60 : 15
    : 95;

  const sellerVerificationScore = product.sellerVerified ? 100 : 0;
  const affordabilityScore = product.priceInr <= 500 ? 100 : product.priceInr <= 800 ? 75 : 45;
  const sustainabilityScore = product.category === 'bio_control' || product.category === 'organic_fertilizer' ? 98 : 55;

  const isSafetyBlocked = safetyBlockReasons.length > 0;

  const weightedSum =
    weights.cropMatch * cropMatchScore +
    weights.problemMatch * problemMatchScore +
    weights.labelCompleteness * labelCompletenessScore +
    weights.weatherSuitability * weatherSuitabilityScore +
    weights.sellerVerification * sellerVerificationScore +
    weights.affordability * affordabilityScore +
    weights.sustainabilityScore * sustainabilityScore;

  const totalWeight = Object.values(weights).reduce((a, b) => a + b, 0);
  const rawFinal = Math.round(weightedSum / (totalWeight || 1));

  // Safety rule: Never allow compatibility score to override safety blocks
  const finalScore = isSafetyBlocked ? 0 : rawFinal;

  return {
    cropMatchScore,
    problemMatchScore,
    labelCompletenessScore,
    weatherSuitabilityScore,
    sellerVerificationScore,
    affordabilityScore,
    sustainabilityScore,
    finalScore,
    isSafetyBlocked,
    safetyBlockReasons,
  };
}
