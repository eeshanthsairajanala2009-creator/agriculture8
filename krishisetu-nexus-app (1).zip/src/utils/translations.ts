export interface TranslationBundle {
  appName: string;
  tagline: string;
  selectLanguage: string;
  farmer: string;
  officer: string;
  seller: string;
  fpo: string;
  admin: string;
  roleSwitcher: string;
  askAi: string;
  diagnose: string;
  weather: string;
  products: string;
  services: string;
  cart: string;
  tasks: string;
  soil: string;
  mandi: string;
  schemes: string;
  verification: string;
  audit: string;
  voiceAskPrompt: string;
  voiceQuestionPreset: string;
  sprayQuestion: string;
  sprayUnsafeAlert: string;
  safeSprayWindow: string;
  blockedProductWarning: string;
  verifiedLabelTitle: string;
  readAloud: string;
  stopAudio: string;
  beforeAfter: string;
  escalateToOfficer: string;
  approveAction: string;
  rejectAction: string;
  demoTour: string;
  demoTourDesc: string;
  offlineMode: string;
  onlineMode: string;
  sunlightMode: string;
  scanBarcode: string;
  authenticityVerified: string;
  authenticityWarning: string;
  costEstimator: string;
  sustainabilityScore: string;
  signIn: string;
  signOut: string;
  signInTitle: string;
}

export const TRANSLATIONS: Record<'en' | 'hi' | 'te', TranslationBundle> = {
  en: {
    appName: 'KrishiSetu Nexus',
    tagline: 'From farmer question to verified farm action.',
    selectLanguage: 'Choose Language / भाषा चुनें / భాషను ఎంచుకోండి',
    farmer: 'Farmer (Kisan)',
    officer: 'Agriculture Officer / Agronomist',
    seller: 'Verified Agri-Seller / Drone Provider',
    fpo: 'Cooperative / FPO Manager',
    admin: 'System Administrator',
    roleSwitcher: 'Current Persona',
    askAi: 'Ask Assistant',
    diagnose: 'Crop Doctor',
    weather: 'Weather & Spray Window',
    products: 'Verified Products',
    services: 'Book Services',
    cart: 'Cart & Checkout',
    tasks: 'Farm Tasks',
    soil: 'Soil Health & Docs',
    mandi: 'Mandi Prices',
    schemes: 'Govt Schemes',
    verification: 'Before & After Verify',
    audit: 'Privacy & Audit Log',
    voiceAskPrompt: 'Tap microphone and speak in English, Hindi, or Telugu',
    voiceQuestionPreset: '“Can I spray today? Rain is expected tomorrow.”',
    sprayQuestion: 'Can I spray today?',
    sprayUnsafeAlert: 'DELAY SPRAYING! Heavy rain (85%) expected within 12 hours.',
    safeSprayWindow: 'Rain forecast requires 24h dry interval. Postpone application.',
    blockedProductWarning: 'STRICT SAFETY BLOCK: Expired or unverified product prohibited from purchase.',
    verifiedLabelTitle: 'Government CIB&RC Verified Label Leaflet',
    readAloud: 'Read Aloud (Voice)',
    stopAudio: 'Stop Audio',
    beforeAfter: 'Before & After Verification',
    escalateToOfficer: 'Escalate to Agronomist',
    approveAction: 'Approve Recommendation',
    rejectAction: 'Reject / Correct Advice',
    demoTour: '5-Minute Seed Demo Walkthrough',
    demoTourDesc: 'One-click step-by-step tour of the 1-acre tomato fungal scenario',
    offlineMode: 'Offline Mode (Local Cache Active)',
    onlineMode: 'Connected (Live Server Sync)',
    sunlightMode: 'Outdoor Sunlight Mode',
    scanBarcode: 'Scan QR / Batch Code',
    authenticityVerified: 'Authentic Product Batch Verified with CIB&RC',
    authenticityWarning: 'Alert: Unverified, expired, or non-matching batch!',
    costEstimator: 'Transparent Acreage Cost Breakdown',
    sustainabilityScore: 'Eco-Impact & Chemical Reduction Index',
    signIn: 'Sign In',
    signOut: 'Sign Out',
    signInTitle: 'Sign In / Register',
  },
  hi: {
    appName: 'कृषि सेतु नेक्सस (KrishiSetu Nexus)',
    tagline: 'किसान के सवाल से सत्यापित खेत कार्रवाई तक।',
    selectLanguage: 'भाषा चुनें (Select Language)',
    farmer: 'किसान भाई (Farmer)',
    officer: 'कृषि अधिकारी / विशेषज्ञ (Agronomist)',
    seller: 'सत्यापित विक्रेता / ड्रोन प्रदाता (Seller)',
    fpo: 'सहकारी / एफपीओ प्रबंधक (FPO Manager)',
    admin: 'प्रणाली प्रशासक (Administrator)',
    roleSwitcher: 'सक्रिय भूमिका (Switch Role)',
    askAi: 'कृषि सहायक से पूछें',
    diagnose: 'फसल डॉक्टर',
    weather: 'मौसम व छिड़काव समय',
    products: 'सत्यापित दवाइयां व खाद',
    services: 'कृषि सेवाएं बुक करें',
    cart: 'खरीदारी टोकरी व भुगतान',
    tasks: 'खेत के जरूरी कार्य',
    soil: 'मिट्टी जांच व दस्तावेज',
    mandi: 'मंडी भाव व बिक्री',
    schemes: 'सरकारी योजनाएं व बीमा',
    verification: 'पहले और बाद का असर',
    audit: 'गोपनीयता व सुरक्षा ऑडिट',
    voiceAskPrompt: 'माइक दबाएं और हिंदी, अंग्रेजी या तेलुगु में बोलें',
    voiceQuestionPreset: '“क्या मैं आज छिड़काव कर सकता हूँ? कल बारिश होने वाली है।”',
    sprayQuestion: 'क्या मैं आज छिड़काव कर सकता हूँ?',
    sprayUnsafeAlert: 'छिड़काव रोकें! अगले 12 घंटों में 85% बारिश की संभावना है।',
    safeSprayWindow: 'दवाई धुलने से बचाने के लिए बारिश रुकने तक प्रतीक्षा करें।',
    blockedProductWarning: 'सुरक्षा चेतावनी: एक्सपायर्ड या असत्यापित उत्पाद खरीदना प्रतिबंधित है।',
    verifiedLabelTitle: 'केंद्रीय कीटनाशक बोर्ड (CIB&RC) द्वारा सत्यापित लेबल',
    readAloud: 'आवाज़ में सुनें (Read Aloud)',
    stopAudio: 'आवाज़ बंद करें',
    beforeAfter: 'पहले और बाद का अंतर जांचें',
    escalateToOfficer: 'कृषि विशेषज्ञ को भेजें',
    approveAction: 'सिफारिश स्वीकृत करें',
    rejectAction: 'संशोधित या अस्वीकृत करें',
    demoTour: '5-मिनट डेमो परिदृश्य चलाएं',
    demoTourDesc: '1 एकड़ टमाटर में अगेती झुलसा रोग का पूरा समाधान चरण-दर-चरण देखें',
    offlineMode: 'ऑफ़लाइन मोड (सुरक्षित डेटा)',
    onlineMode: 'इंटरनेट से जुड़ा हुआ (लाइव सिंक)',
    sunlightMode: 'धूप में स्पष्ट दिखे (उच्च कंट्रास्ट)',
    scanBarcode: 'दवाई का क्यूआर/बारकोड स्कैन करें',
    authenticityVerified: 'असली बैच व सरकारी सीआईबी पंजीकरण सत्यापित',
    authenticityWarning: 'सावधान: संदिग्ध, एक्सपायर्ड या फर्जी बैच!',
    costEstimator: 'लागत का स्पष्ट पारदर्शी हिसाब',
    sustainabilityScore: 'पर्यावरण व मिट्टी सुरक्षा सूचकांक',
    signIn: 'लॉग इन / साइन इन',
    signOut: 'साइन आउट',
    signInTitle: 'साइन इन / खाता खोलें',
  },
  te: {
    appName: 'కృషిసేతు నెక్సస్ (KrishiSetu Nexus)',
    tagline: 'రైతు ప్రశ్న నుండి ధృవీకరించబడిన వ్యవసాయ చర్య వరకు.',
    selectLanguage: 'భాషను ఎంచుకోండి (Select Language)',
    farmer: 'రైతు సోదరుడు (Farmer)',
    officer: 'వ్యవసాయ అధికారి / నిపుణుడు (Agronomist)',
    seller: 'ధృవీకరించబడిన డీలర్ / డ్రోన్ పైలట్ (Seller)',
    fpo: 'సహకార / ఎఫ్‌పీవో మేనేజర్ (FPO Manager)',
    admin: 'సిస్టమ్ నిర్వాహకుడు (Administrator)',
    roleSwitcher: 'పాత్రను మార్చండి (Switch Role)',
    askAi: 'AI సహాయకుడిని అడగండి',
    diagnose: 'పంట వైద్యుడు (Crop Doctor)',
    weather: 'వాతావరణం & పిచికారీ సమయం',
    products: 'ధృవీకరించబడిన ఎరువులు & మందులు',
    services: 'వ్యవసాయ సేవలను బుక్ చేయండి',
    cart: 'షాపింగ్ కార్ట్ & చెల్లింపు',
    tasks: 'పొలం పనుల క్యాలెండర్',
    soil: 'నేల పరీక్ష & పత్రాలు',
    mandi: 'మార్కెట్ ధరలు & అమ్మకాలు',
    schemes: 'ప్రభుత్వ పథకాలు & బీమా',
    verification: 'చికిత్స ముందు & తర్వాత ఫలితం',
    audit: 'గోప్యత & భద్రతా ఆడిట్',
    voiceAskPrompt: 'మైక్ నొక్కి తెలుగు, హిందీ లేదా ఇంగ్లీషులో మాట్లాడండి',
    voiceQuestionPreset: '“నేను ఈరోజు పిచికారీ చేయవచ్చా? రేపు వర్షం పడే అవకాశం ఉంది.”',
    sprayQuestion: 'నేను ఈరోజు పిచికారీ చేయవచ్చా?',
    sprayUnsafeAlert: 'పిచికారీని వాయిదా వేయండి! రాబోయే 12 గంటల్లో 85% వర్ష సూచన ఉంది.',
    safeSprayWindow: 'వర్షం వల్ల మందు కొట్టుకుపోకుండా ఉండటానికి పొడి వాతావరణం వచ్చేవరకు వేచి ఉండండి.',
    blockedProductWarning: 'భద్రతా హెచ్చరిక: గడువు ముగిసిన లేదా ధృవీకరించని ఉత్పత్తుల కొనుగోలు నిషేధించబడింది.',
    verifiedLabelTitle: 'కేంద్ర క్రిమిసంహారక బోర్డు (CIB&RC) ధృవీకరించిన లేబుల్',
    readAloud: 'వాయిస్ లో వినండి (Read Aloud)',
    stopAudio: 'ఆడియో ఆపండి',
    beforeAfter: 'ముందు & తర్వాత తేడాను సరిచూడండి',
    escalateToOfficer: 'వ్యవసాయ నిపుణుడికి పంపండి',
    approveAction: 'సిఫార్సును ఆమోదించండి',
    rejectAction: 'సవరించండి లేదా తిరస్కరించండి',
    demoTour: '5 నిమిషాల డెమో చూడండి',
    demoTourDesc: '1 ఎకరం టమోటా తోటలో ముందస్తు తెగులు నివారణను దశలవారీగా చూడండి',
    offlineMode: 'ఆఫ్‌లైన్ మోడ్ (స్థానిక డేటా)',
    onlineMode: 'ఆన్‌లైన్ (లైవ్ సింక్)',
    sunlightMode: 'ఎండలో స్పష్టంగా కనిపించే మోడ్',
    scanBarcode: 'QR / బార్‌కోడ్‌ను స్కాన్ చేయండి',
    authenticityVerified: 'అసలైన బ్యాచ్ మరియు ప్రభుత్వ CIB&RC నమోదు ధృవీకరించబడింది',
    authenticityWarning: 'హెచ్చరిక: గడువు ముగిసిన లేదా నకిలీ బ్యాచ్!',
    costEstimator: 'ఎకరానికి పారదర్శక ఖర్చు అంచనా',
    sustainabilityScore: 'పర్యావరణ & నేల రక్షణ సూచిక',
    signIn: 'సైన్ ఇన్ (Sign In)',
    signOut: 'సైన్ అవుట్ (Sign Out)',
    signInTitle: 'సైన్ ఇన్ / ఖాతా తెరవండి',
  },
};
