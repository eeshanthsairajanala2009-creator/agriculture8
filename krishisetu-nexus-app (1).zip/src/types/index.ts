/**
 * KrishiSetu Nexus - Core Domain Models & Schemas
 */

export type UserRole = 'farmer' | 'officer' | 'seller' | 'fpo' | 'admin';
export type LanguageCode = 'en' | 'hi' | 'kn' | 'te' | 'mr';

export interface User {
  id: string;
  name: string;
  phone: string;
  role: UserRole;
  language: LanguageCode;
  district: string;
  state: string;
  avatar?: string;
  fpoAffiliation?: string;
}

export interface ConsentRecord {
  id: string;
  userId: string;
  consentType: 'location' | 'crop_image' | 'voice_recording' | 'sensor_data' | 'seller_sharing';
  granted: boolean;
  timestamp: string;
  blurFacesEnabled: boolean;
  purpose: string;
}

export interface Farm {
  id: string;
  farmerId: string;
  name: string;
  totalAcres: number;
  latitude: number;
  longitude: number;
  soilType: 'Red Loam' | 'Black Sandy Loam' | 'Clayey' | 'Alluvial';
  irrigationSource: 'Drip System' | 'Borewell' | 'Canal' | 'Rainfed';
  organicCertified: boolean;
}

export interface Crop {
  id: string;
  farmId: string;
  cropName: string;
  variety: string;
  sowingDate: string;
  stage: 'Nursery' | 'Vegetative' | 'Flowering' | 'Fruit Formation' | 'Harvesting';
  plantedAcres: number;
  healthStatus: 'healthy' | 'at_risk' | 'diseased' | 'improving';
  expectedHarvestDate: string;
}

export interface CropDiseaseProfile {
  id: string;
  name: string;
  scientificName: string;
  hindiName: string;
  confidence: number;
  severity: 'low' | 'moderate' | 'high' | 'critical';
  visualEvidence: string[];
  color: string;
  spots: { cx: number; cy: number; r: number }[];
  description: string;
}

export interface SupportedCrop {
  id: string;
  name: string;
  icon: string;
  hindiName: string;
  teluguName: string;
  category: 'Vegetables' | 'Cereals' | 'Cash Crops' | 'Pulses' | 'Fruits' | 'Spices';
  popularVarieties: string[];
  defaultVariety: string;
  defaultStage: 'Nursery' | 'Vegetative' | 'Flowering' | 'Fruit Formation' | 'Harvesting';
  diseases: CropDiseaseProfile[];
  mandiPriceBenchmarkInr: number;
  typicalAcreYieldQuintals: number;
  advisorySummary: string;
  recommendedFungicides: string[];
}

export interface CropObservation {
  id: string;
  cropId: string;
  date: string;
  notes: string;
  imageUrl?: string;
  audioUrl?: string;
  voiceTranscript?: string;
  temperatureAtTime?: number;
  humidityAtTime?: number;
}

export interface Diagnosis {
  id: string;
  observationId: string;
  crop: string;
  diseaseOrPest: string;
  scientificName: string;
  hindiName?: string;
  confidence: number; // 0-100
  severity: 'low' | 'moderate' | 'high' | 'critical';
  visualEvidence: string[];
  recommendedNextObservation: string;
  requiresExpertEscalation: boolean;
  escalationReason?: string;
  escalationStatus?: 'pending' | 'officer_approved' | 'officer_corrected' | 'rejected';
  officerNotes?: string;
  aiCertaintyWarning: string;
  timestamp: string;
}

export interface WeatherSnapshot {
  timestamp: string;
  location: string;
  temperatureC: number;
  humidityPercent: number;
  windSpeedKmh: number;
  precipitationChanceNext12h: number;
  rainExpectedMm: number;
  dataSource: 'live' | 'cached' | 'simulated';
  sprayWindowCondition: 'Unsafe (Rain within 12h)' | 'Optimal' | 'Marginal (High Wind)';
  sprayAdvisory: string;
  irrigationRecommendation: string;
}

export interface SoilReport {
  id: string;
  farmId: string;
  sampleDate: string;
  labName: string;
  labRegistrationNumber: string;
  pH: number;
  pHCategory: 'Mildly Acidic' | 'Neutral' | 'Alkaline';
  nitrogenKgHa: number;
  nitrogenStatus: 'Low' | 'Medium' | 'Optimal';
  phosphorusKgHa: number;
  phosphorusStatus: 'Low' | 'Medium' | 'Optimal';
  potassiumKgHa: number;
  potassiumStatus: 'Low' | 'Medium' | 'Optimal';
  organicCarbonPercent: number;
  verifiedByAgronomist: boolean;
  recommendedNutrientAdvice: string;
}

export interface AgriculturalDocument {
  id: string;
  title: string;
  category: 'pesticide_label' | 'fertilizer_label' | 'soil_test' | 'scheme_policy' | 'insurance_claim';
  source: string;
  pageNumber: number;
  publicationDate: string;
  extractedSnippet: string;
  verifiedOfficialLink: string;
}

export interface ProductLabel {
  id: string;
  activeIngredient: string;
  chemicalGroup: string;
  targetPests: string[];
  targetCrops: string[];
  applicationRatePerAcre: string;
  waterVolumeLitersPerAcre: string;
  harvestIntervalDays: number; // Waiting period before harvest
  requiredPPE: string[];
  toxicologyColorCode: 'Green (Caution)' | 'Blue (Danger)' | 'Yellow (Poison)' | 'Red (Extreme Poison)';
  storageAndDisposal: string;
  officialCIBRegistrationNumber: string;
}

export interface ProductBatch {
  batchNumber: string;
  manufacturingDate: string;
  expiryDate: string;
  qrVerificationCode: string;
  isExpired: boolean;
  isAuthentic: boolean;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: 'fungicide' | 'insecticide' | 'bio_control' | 'organic_fertilizer' | 'micronutrient';
  formulation: string;
  packSize: string;
  priceInr: number;
  sellerId: string;
  sellerName: string;
  sellerVerified: boolean;
  inStock: boolean;
  stockUnits: number;
  compatibilityScore: number; // 0-100 calculated
  label: ProductLabel;
  batch: ProductBatch;
  rating: number;
  reviewsCount: number;
  isBlockedByTrustAgent: boolean;
  blockReason?: string;
  whyThisProduct: string;
  cheaperAlternativeId?: string;
}

export interface ServiceListing {
  id: string;
  providerId: string;
  providerName: string;
  providerVerified: boolean;
  serviceType: 'drone_spraying' | 'soil_testing' | 'agronomist_consultation' | 'tractor_rotavator' | 'transport';
  title: string;
  priceInr: number;
  priceUnit: 'per acre' | 'per sample' | 'per session' | 'per trip';
  travelChargeInr: number;
  distanceKm: number;
  availability: 'Available Today' | 'Next Day' | 'On Demand';
  rating: number;
  languagesSupported: string[];
  equipmentDetails: string;
  cancellationPolicy: string;
  requiredPreparation: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  pricePerUnit: number;
  totalPrice: number;
}

export interface Order {
  id: string;
  farmerId: string;
  items: OrderItem[];
  subtotalInr: number;
  deliveryFeeInr: number;
  fpoDiscountInr: number;
  totalInr: number;
  paymentMethod: 'UPI' | 'Cash on Delivery' | 'FPO Group Account';
  paymentStatus: 'paid' | 'pending' | 'escrowed';
  deliveryStatus: 'placed' | 'confirmed' | 'dispatched' | 'out_for_delivery' | 'delivered';
  createdAt: string;
  estimatedDeliveryDate: string;
  deliveryOtp: string;
  verifiedLabelAcknowledged: boolean;
}

export interface Booking {
  id: string;
  farmerId: string;
  serviceId: string;
  serviceTitle: string;
  providerName: string;
  serviceType: string;
  scheduledDate: string;
  status: 'requested' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  totalChargeInr: number;
  notes: string;
}

export interface Task {
  id: string;
  title: string;
  category: 'irrigation' | 'spraying' | 'scouting' | 'soil_testing' | 'harvesting';
  status: 'planned' | 'in_progress' | 'completed' | 'cancelled' | 'delayed_weather';
  dueDate: string;
  notes: string;
  weatherDependent: boolean;
  completedOffline: boolean;
}

export interface PestReport {
  id: string;
  district: string;
  village: string;
  crop: string;
  pestName: string;
  severity: 'low' | 'moderate' | 'high';
  reportsCount: number;
  latitude: number;
  longitude: number;
  lastUpdated: string;
}

export interface MarketPrice {
  mandiName: string;
  district: string;
  crop: string;
  variety: string;
  modalPricePerQuintalInr: number;
  minPricePerQuintalInr: number;
  maxPricePerQuintalInr: number;
  trend: 'up' | 'down' | 'stable';
  lastUpdated: string;
  dataSource: string;
}

export interface GovernmentScheme {
  id: string;
  name: string;
  shortCode: string;
  ministry: string;
  targetBenefit: string;
  eligibilityConditions: string[];
  requiredDocuments: string[];
  applicationPortalUrl: string;
  subsidyPercentage?: number;
  status: 'Active' | 'Enrolling Now';
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actorRole: UserRole;
  actorName: string;
  actionType: 'DIAGNOSIS_GENERATED' | 'OFFICER_APPROVAL' | 'PRODUCT_BLOCKED' | 'ORDER_PLACED' | 'BOOKING_CREATED' | 'DATA_DELETED' | 'CONSENT_MODIFIED';
  details: string;
  agentName: string;
}

export interface LivestockProfile {
  id: string;
  animalType: 'Cattle (Cow)' | 'Buffalo' | 'Goat' | 'Poultry';
  tagNumber: string;
  breed: string;
  ageYears: number;
  recentConcern?: string;
  status: 'healthy' | 'vet_escalation' | 'routine_monitoring';
}

export interface PriorityFormulaWeights {
  cropLossRisk: number; // default 0.25
  treatmentUrgency: number; // default 0.15
  affectedAcres: number; // default 0.10
  farmerVulnerability: number; // default 0.10
  weatherSensitivity: number; // default 0.10
  spreadRisk: number; // default 0.10
  availability: number; // default 0.10
  sustainability: number; // default 0.10
}

export interface ProductCompatibilityWeights {
  cropMatch: number; // 0.30
  problemMatch: number; // 0.25
  labelCompleteness: number; // 0.15
  weatherSuitability: number; // 0.10
  sellerVerification: number; // 0.10
  affordability: number; // 0.05
  sustainabilityScore: number; // 0.05
}
