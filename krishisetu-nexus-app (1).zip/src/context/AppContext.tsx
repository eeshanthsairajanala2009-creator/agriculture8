import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserRole,
  LanguageCode,
  Farm,
  Crop,
  Diagnosis,
  WeatherSnapshot,
  SoilReport,
  Product,
  ServiceListing,
  Order,
  Booking,
  Task,
  PestReport,
  MarketPrice,
  GovernmentScheme,
  AgriculturalDocument,
  LivestockProfile,
  AuditLog,
  PriorityFormulaWeights,
  ProductCompatibilityWeights,
  CartItem,
} from '../types';
import {
  DEMO_USERS,
  SEED_FARM,
  SEED_CROP,
  SEED_WEATHER,
  SEED_SOIL_REPORT,
  SEED_DIAGNOSIS,
  SEED_PRODUCTS,
  SEED_SERVICES,
  SEED_TASKS,
  SEED_ORDERS,
  SEED_BOOKINGS,
  SEED_MARKET_PRICES,
  SEED_GOVERNMENT_SCHEMES,
  SEED_DOCUMENTS,
  SEED_PEST_HOTSPOTS,
  SEED_LIVESTOCK,
  SEED_AUDIT_LOGS,
  DEFAULT_PRIORITY_WEIGHTS,
  DEFAULT_COMPATIBILITY_WEIGHTS,
} from '../data/seedData';
import { TRANSLATIONS } from '../utils/translations';
import { speakText, stopSpeaking } from '../utils/audio';

export type ScreenId =
  | 'welcome'
  | 'consent'
  | 'profile'
  | 'dashboard'
  | 'ask'
  | 'camera'
  | 'voice'
  | 'diagnosis'
  | 'weather'
  | 'irrigation'
  | 'treatment'
  | 'products'
  | 'product_details'
  | 'authenticity'
  | 'cart'
  | 'soil'
  | 'soil_labs'
  | 'services'
  | 'machinery'
  | 'sustainability'
  | 'mandi'
  | 'schemes'
  | 'pest_map'
  | 'orders'
  | 'tasks'
  | 'verification'
  | 'officer_escalation'
  | 'fpo_dashboard'
  | 'seller_dashboard'
  | 'audit';

interface AppContextType {
  // Authentication & Current user
  isAuthenticated: boolean;
  isSignInModalOpen: boolean;
  setIsSignInModalOpen: (open: boolean) => void;
  signIn: (userData?: Partial<User>, role?: UserRole) => void;
  signOut: () => void;
  signUp: (userData: { name: string; phone: string; role: UserRole; district: string; state: string; cropName?: string }) => void;
  currentUser: User;
  currentRole: UserRole;
  switchRole: (role: UserRole) => void;

  // Language & UI
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (typeof TRANSLATIONS)['en'];
  activeScreen: ScreenId;
  setActiveScreen: (screen: ScreenId) => void;
  sunlightMode: boolean;
  setSunlightMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  isOffline: boolean;
  setIsOffline: (val: boolean | ((prev: boolean) => boolean)) => void;
  offlineQueueCount: number;
  triggerOfflineSync: () => void;

  // Audio speech
  isSpeaking: boolean;
  playSpeech: (text: string) => void;
  stopSpeech: () => void;

  // Domain data
  farm: Farm;
  setFarm: React.Dispatch<React.SetStateAction<Farm>>;
  crop: Crop;
  setCrop: React.Dispatch<React.SetStateAction<Crop>>;
  weather: WeatherSnapshot;
  soilReport: SoilReport;
  diagnosis: Diagnosis;
  setDiagnosis: React.Dispatch<React.SetStateAction<Diagnosis>>;
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  selectedProduct: Product;
  setSelectedProduct: (p: Product) => void;
  services: ServiceListing[];
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
  orders: Order[];
  bookings: Booking[];
  pestHotspots: PestReport[];
  marketPrices: MarketPrice[];
  governmentSchemes: GovernmentScheme[];
  documents: AgriculturalDocument[];
  livestock: LivestockProfile[];
  auditLogs: AuditLog[];
  addAuditLog: (log: Omit<AuditLog, 'id' | 'timestamp'>) => void;

  // Cart & Ordering
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => boolean;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  checkoutCart: (paymentMethod: 'UPI' | 'Cash on Delivery' | 'FPO Group Account') => Order;

  // Bookings
  createBooking: (service: ServiceListing, scheduledDate: string, notes: string) => Booking;

  // Weights configuration
  priorityWeights: PriorityFormulaWeights;
  setPriorityWeights: React.Dispatch<React.SetStateAction<PriorityFormulaWeights>>;
  compatibilityWeights: ProductCompatibilityWeights;
  setCompatibilityWeights: React.Dispatch<React.SetStateAction<ProductCompatibilityWeights>>;

  // Escalation & Officer actions
  approveEscalation: (diagnosisId: string, notes: string) => void;
  rejectEscalation: (diagnosisId: string, notes: string) => void;

  // Seed scenario demo stepper
  demoStep: number;
  setDemoStep: (step: number) => void;
  runDemoStep: (stepIndex: number) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const savedAuth = localStorage.getItem('krishisetu_auth');
      return savedAuth !== 'false';
    }
    return true;
  });
  const [isSignInModalOpen, setIsSignInModalOpen] = useState<boolean>(false);
  const [currentRole, setCurrentRole] = useState<UserRole>('farmer');
  const [currentUser, setCurrentUser] = useState<User>(() => {
    if (typeof window !== 'undefined') {
      try {
        const savedUser = localStorage.getItem('krishisetu_user');
        if (savedUser) return JSON.parse(savedUser);
      } catch (e) {
        console.warn('Failed to parse saved user:', e);
      }
    }
    return DEMO_USERS.farmer;
  });
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('krishisetu_language');
      if (saved === 'en' || saved === 'hi' || saved === 'te') {
        return saved as LanguageCode;
      }
    }
    return 'en';
  });

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('krishisetu_language', lang);
        document.documentElement.lang = lang;
      } catch (err) {
        console.warn('Failed to save language in localStorage:', err);
      }
    }
  };

  const [activeScreen, setActiveScreen] = useState<ScreenId>('dashboard');
  const [sunlightMode, setSunlightMode] = useState<boolean>(false);
  const [isOffline, setIsOffline] = useState<boolean>(false);
  const [offlineQueueCount, setOfflineQueueCount] = useState<number>(0);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Domain states
  const [farm, setFarm] = useState<Farm>(SEED_FARM);
  const [crop, setCrop] = useState<Crop>(SEED_CROP);
  const [weather] = useState<WeatherSnapshot>(SEED_WEATHER);
  const [soilReport] = useState<SoilReport>(SEED_SOIL_REPORT);
  const [diagnosis, setDiagnosis] = useState<Diagnosis>(SEED_DIAGNOSIS);
  const [products, setProducts] = useState<Product[]>(SEED_PRODUCTS);
  const [selectedProduct, setSelectedProduct] = useState<Product>(SEED_PRODUCTS[0]);
  const [services] = useState<ServiceListing[]>(SEED_SERVICES);
  const [tasks, setTasks] = useState<Task[]>(SEED_TASKS);
  const [orders, setOrders] = useState<Order[]>(SEED_ORDERS);
  const [bookings, setBookings] = useState<Booking[]>(SEED_BOOKINGS);
  const [pestHotspots] = useState<PestReport[]>(SEED_PEST_HOTSPOTS);
  const [marketPrices] = useState<MarketPrice[]>(SEED_MARKET_PRICES);
  const [governmentSchemes] = useState<GovernmentScheme[]>(SEED_GOVERNMENT_SCHEMES);
  const [documents] = useState<AgriculturalDocument[]>(SEED_DOCUMENTS);
  const [livestock] = useState<LivestockProfile[]>(SEED_LIVESTOCK);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(SEED_AUDIT_LOGS);

  // Cart
  const [cart, setCart] = useState<CartItem[]>([]);

  // Weights
  const [priorityWeights, setPriorityWeights] = useState<PriorityFormulaWeights>(DEFAULT_PRIORITY_WEIGHTS);
  const [compatibilityWeights, setCompatibilityWeights] = useState<ProductCompatibilityWeights>(DEFAULT_COMPATIBILITY_WEIGHTS);

  // Demo step
  const [demoStep, setDemoStep] = useState<number>(0);

  // Sign in handler
  const signIn = (userOverrides?: Partial<User>, role?: UserRole) => {
    const targetRole = role || userOverrides?.role || 'farmer';
    const baseUser = DEMO_USERS[targetRole] || DEMO_USERS.farmer;
    const resolvedUser: User = {
      ...baseUser,
      ...userOverrides,
      role: targetRole,
    };

    setCurrentRole(targetRole);
    setCurrentUser(resolvedUser);
    setIsAuthenticated(true);
    setIsSignInModalOpen(false);

    try {
      localStorage.setItem('krishisetu_auth', 'true');
      localStorage.setItem('krishisetu_user', JSON.stringify(resolvedUser));
    } catch (e) {
      console.warn('Failed to save auth state:', e);
    }

    addAuditLog({
      actorRole: targetRole,
      actorName: resolvedUser.name,
      actionType: 'CONSENT_MODIFIED',
      details: `User successfully authenticated (${resolvedUser.name}, ${targetRole.toUpperCase()})`,
      agentName: 'Trust and Safety Agent',
    });
  };

  // Sign out handler
  const signOut = () => {
    setIsAuthenticated(false);
    try {
      localStorage.setItem('krishisetu_auth', 'false');
      localStorage.removeItem('krishisetu_user');
    } catch (e) {
      console.warn('Failed to clear auth state:', e);
    }

    addAuditLog({
      actorRole: currentRole,
      actorName: currentUser.name,
      actionType: 'CONSENT_MODIFIED',
      details: `User signed out from session`,
      agentName: 'Trust and Safety Agent',
    });
  };

  // Sign up handler
  const signUp = (userData: {
    name: string;
    phone: string;
    role: UserRole;
    district: string;
    state: string;
    cropName?: string;
  }) => {
    const newUser: User = {
      id: `usr_${Date.now()}`,
      name: userData.name,
      phone: userData.phone,
      role: userData.role,
      language: language,
      district: userData.district,
      state: userData.state,
      fpoAffiliation: userData.role === 'farmer' ? 'Kolar Blossom FPO (New Member)' : undefined,
    };

    signIn(newUser, userData.role);

    if (userData.cropName) {
      setCrop((prev) => ({
        ...prev,
        cropName: userData.cropName || prev.cropName,
      }));
    }
  };

  // Handle role switch
  const switchRole = (role: UserRole) => {
    setCurrentRole(role);
    setCurrentUser(DEMO_USERS[role] || DEMO_USERS.farmer);
    if (role === 'officer') setActiveScreen('officer_escalation');
    else if (role === 'fpo') setActiveScreen('fpo_dashboard');
    else if (role === 'seller') setActiveScreen('seller_dashboard');
    else if (role === 'admin') setActiveScreen('audit');
    else setActiveScreen('dashboard');

    addAuditLog({
      actorRole: role,
      actorName: DEMO_USERS[role]?.name || 'User',
      actionType: 'CONSENT_MODIFIED',
      details: `Switched active persona to ${role.toUpperCase()}`,
      agentName: 'Trust and Safety Agent',
    });
  };

  // Add audit log helper
  const addAuditLog = (logData: Omit<AuditLog, 'id' | 'timestamp'>) => {
    const newLog: AuditLog = {
      ...logData,
      id: `aud_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' IST',
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Offline sync trigger
  const triggerOfflineSync = () => {
    setOfflineQueueCount(0);
    setIsOffline(false);
    addAuditLog({
      actorRole: currentRole,
      actorName: currentUser.name,
      actionType: 'CONSENT_MODIFIED',
      details: 'Synchronized offline cached records with cloud node',
      agentName: 'Field Operations Agent',
    });
  };

  // Speech helpers
  const playSpeech = (text: string) => {
    setIsSpeaking(true);
    const speechLang = (language as 'en' | 'hi' | 'te') || 'en';
    speakText(text, speechLang, () => {
      setIsSpeaking(false);
    });
  };

  const stopSpeech = () => {
    stopSpeaking();
    setIsSpeaking(false);
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1): boolean => {
    if (product.isBlockedByTrustAgent || product.batch.isExpired || !product.sellerVerified) {
      alert(`Trust and Safety Agent blocked this product:\n${product.blockReason || 'Unsafe/Expired/Unverified'}`);
      addAuditLog({
        actorRole: currentRole,
        actorName: currentUser.name,
        actionType: 'PRODUCT_BLOCKED',
        details: `Blocked attempt to add ${product.name} to cart. Reason: ${product.blockReason}`,
        agentName: 'Trust and Safety Agent',
      });
      return false;
    }

    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { product, quantity }];
    });

    addAuditLog({
      actorRole: currentRole,
      actorName: currentUser.name,
      actionType: 'ORDER_PLACED',
      details: `Added ${product.name} (x${quantity}) to farmer cart`,
      agentName: 'Product Marketplace Agent',
    });
    return true;
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => setCart([]);

  const checkoutCart = (paymentMethod: 'UPI' | 'Cash on Delivery' | 'FPO Group Account'): Order => {
    const subtotal = cart.reduce((sum, item) => sum + item.product.priceInr * item.quantity, 0);
    const fpoDiscount = currentUser.fpoAffiliation ? Math.round(subtotal * 0.08) : 0;
    const deliveryFee = 40;
    const total = Math.max(0, subtotal + deliveryFee - fpoDiscount);

    const newOrder: Order = {
      id: `ORD-NEXUS-${Date.now().toString().slice(-5)}`,
      farmerId: currentUser.id,
      items: cart.map((c) => ({
        productId: c.product.id,
        productName: c.product.name,
        quantity: c.quantity,
        pricePerUnit: c.product.priceInr,
        totalPrice: c.product.priceInr * c.quantity,
      })),
      subtotalInr: subtotal,
      deliveryFeeInr: deliveryFee,
      fpoDiscountInr: fpoDiscount,
      totalInr: total,
      paymentMethod,
      paymentStatus: paymentMethod === 'Cash on Delivery' ? 'pending' : 'paid',
      deliveryStatus: 'confirmed',
      createdAt: new Date().toLocaleTimeString('en-IN') + ' IST',
      estimatedDeliveryDate: 'Tomorrow by 11:00 AM',
      deliveryOtp: `${Math.floor(1000 + Math.random() * 9000)}`,
      verifiedLabelAcknowledged: true,
    };

    setOrders((prev) => [newOrder, ...prev]);
    setCart([]);

    addAuditLog({
      actorRole: currentRole,
      actorName: currentUser.name,
      actionType: 'ORDER_PLACED',
      details: `Created verified order #${newOrder.id} for ₹${total} via ${paymentMethod}`,
      agentName: 'Order and Payment Agent',
    });

    return newOrder;
  };

  const createBooking = (service: ServiceListing, scheduledDate: string, notes: string): Booking => {
    const newBooking: Booking = {
      id: `BK-NEXUS-${Date.now().toString().slice(-4)}`,
      farmerId: currentUser.id,
      serviceId: service.id,
      serviceTitle: service.title,
      providerName: service.providerName,
      serviceType: service.serviceType,
      scheduledDate,
      status: 'confirmed',
      totalChargeInr: service.priceInr + service.travelChargeInr,
      notes,
    };

    setBookings((prev) => [newBooking, ...prev]);

    addAuditLog({
      actorRole: currentRole,
      actorName: currentUser.name,
      actionType: 'BOOKING_CREATED',
      details: `Booked service ${service.title} with ${service.providerName} for ₹${newBooking.totalChargeInr}`,
      agentName: 'Service Marketplace Agent',
    });

    return newBooking;
  };

  const approveEscalation = (diagnosisId: string, notes: string) => {
    setDiagnosis((prev) => ({
      ...prev,
      escalationStatus: 'officer_approved',
      officerNotes: notes,
    }));
    addAuditLog({
      actorRole: 'officer',
      actorName: DEMO_USERS.officer.name,
      actionType: 'OFFICER_APPROVAL',
      details: `Officer Dr. Anita Rao approved treatment plan with note: "${notes}"`,
      agentName: 'Trust and Safety Agent',
    });
  };

  const rejectEscalation = (diagnosisId: string, notes: string) => {
    setDiagnosis((prev) => ({
      ...prev,
      escalationStatus: 'officer_corrected',
      officerNotes: notes,
    }));
    addAuditLog({
      actorRole: 'officer',
      actorName: DEMO_USERS.officer.name,
      actionType: 'OFFICER_APPROVAL',
      details: `Officer corrected treatment plan: "${notes}"`,
      agentName: 'Trust and Safety Agent',
    });
  };

  // 5-Minute Demo Step Runner
  const runDemoStep = (stepIndex: number) => {
    setDemoStep(stepIndex);
    switch (stepIndex) {
      case 1:
        // Voice inquiry step
        setActiveScreen('ask');
        break;
      case 2:
        // Crop Doctor Diagnosis
        setActiveScreen('diagnosis');
        break;
      case 3:
        // Weather delay warning
        setActiveScreen('weather');
        break;
      case 4:
        // Treatment comparison
        setActiveScreen('treatment');
        break;
      case 5:
        // Product marketplace with blocked expired product
        setActiveScreen('products');
        break;
      case 6:
        // Service marketplace (drone spraying)
        setActiveScreen('services');
        break;
      case 7:
        // Tasks and field operations
        setActiveScreen('tasks');
        break;
      case 8:
        // Before and After verification
        setActiveScreen('verification');
        break;
      case 9:
        // Officer Escalation
        switchRole('officer');
        break;
      case 10:
        // FPO Collective Hub
        switchRole('fpo');
        break;
      case 11:
        // Trust and Audit logs
        setActiveScreen('audit');
        break;
      default:
        setActiveScreen('dashboard');
        break;
    }
  };

  // Sunlight mode effect
  useEffect(() => {
    if (sunlightMode) {
      document.body.classList.add('sunlight-mode');
    } else {
      document.body.classList.remove('sunlight-mode');
    }
  }, [sunlightMode]);

  // Document language & regional script class effect
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.lang = language;
      document.body.classList.remove('lang-hi', 'lang-te', 'lang-en');
      document.body.classList.add(`lang-${language}`);
    }
  }, [language]);

  const t = TRANSLATIONS[language as 'en' | 'hi' | 'te'] || TRANSLATIONS.en;

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        isSignInModalOpen,
        setIsSignInModalOpen,
        signIn,
        signOut,
        signUp,
        currentUser,
        currentRole,
        switchRole,
        language,
        setLanguage,
        t,
        activeScreen,
        setActiveScreen,
        sunlightMode,
        setSunlightMode,
        isOffline,
        setIsOffline,
        offlineQueueCount,
        triggerOfflineSync,
        isSpeaking,
        playSpeech,
        stopSpeech,
        farm,
        setFarm,
        crop,
        setCrop,
        weather,
        soilReport,
        diagnosis,
        setDiagnosis,
        products,
        setProducts,
        selectedProduct,
        setSelectedProduct,
        services,
        tasks,
        setTasks,
        orders,
        bookings,
        pestHotspots,
        marketPrices,
        governmentSchemes,
        documents,
        livestock,
        auditLogs,
        addAuditLog,
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        checkoutCart,
        createBooking,
        priorityWeights,
        setPriorityWeights,
        compatibilityWeights,
        setCompatibilityWeights,
        approveEscalation,
        rejectEscalation,
        demoStep,
        setDemoStep,
        runDemoStep,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
